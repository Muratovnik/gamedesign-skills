# Six-pair comparison evidence

Start with REPORT.md, then model-runs/run-index.json and evaluator/rubrics.md.
The 235 files named in evidence-manifest.json are preserved byte-for-byte from
the completed experiment. This archive adds only this index and source notices.
Its source snapshots and installed dependencies are not duplicated. Reproduction
requires the exact source revisions/manifests and external dependency versions
identified in REPORT.md. Absolute paths in original receipts describe the
original experiment; they are evidence, not portable installation commands.

## Source excerpts in raw operation records

The command logger preserves stdout, including method and API source reads.
These are recorded, unmodified reads, not a second maintained runtime source.

- Assay 0.17.2, commit 94c517b0aac9ba2575086bf9aead1cc828aadb0d:
  method text and metadata appear in workspaces/*/.trace/operations.jsonl.
  Copyright (c) Nikolai Muratov and contributors; full MIT license is in
  COPYING/Assay-MIT.txt. https://github.com/Muratovnik/assay
- inkjs 2.4.0, published gitHead edccead8700e9f21be9825d87d8645d8c82a9936:
  03-a operation7 reads README, Compiler declarations and Story/StoryState
  declarations/implementation excerpts. Copyright 2017 inkle Ltd. and inkjs
  contributors. Full MIT license and pinned AUTHORS are in COPYING/.
  https://github.com/y-lohse/inkjs/tree/edccead8700e9f21be9825d87d8645d8c82a9936
- glTF-Validator 2.0.0-dev.3.10, commit bcd52cc4ba5f333b2999a58f67cc05ddf28b4fb1:
  04-a operations5-6 and 04-b operation5 read README/package metadata and
  the JavaScript entry point. Copyright 2016-2019 The Khronos Group Inc.;
  Apache-2.0 license and all bundled NOTICES are in COPYING/.
  https://github.com/KhronosGroup/glTF-Validator/tree/bcd52cc4ba5f333b2999a58f67cc05ddf28b4fb1
- Game Design source read in the same logs and the original synthetic task
  artifacts use the project's MIT terms, retained in COPYING/Game-Design-MIT.txt.

The technical libraries were externally installed. NumPy/SciPy implementations,
native client binaries, credentials and a complete native conversation trace are
not part of this archive. Original failures and evaluator corrections are kept.
