from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[1]
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def audit(run_id,family,arm):
 w=ROOT/'workspaces'/run_id
 trace=w/'.trace/operations.jsonl'
 ops=[json.loads(line) for line in trace.read_text().splitlines()]
 expected={}
 for source in [arm,'assay']:
  manifest=json.loads((ROOT/'sources'/source/'manifest.json').read_text())
  expected.update({rel:h for rel,h in manifest['copied_skill_files'].items() if '/' in rel})  # Workspaces copy complete skill directories, not the collection-root README.
 source_changes=[rel for rel,h in expected.items() if not (w/'.agents/skills'/rel).is_file() or digest(w/'.agents/skills'/rel)!=h]
 packet=ROOT/'packets'/family
 input_changes=[]
 for p in packet.rglob('*'):
  if p.is_file():
   rel=p.relative_to(packet); delivered=w/('TASK.md' if str(rel)=='task.md' else str(rel))
   if not delivered.is_file() or digest(p)!=digest(delivered): input_changes.append(str(rel))
 paths=sorted(set(re.findall(r'\.agents/skills/[A-Za-z0-9_./-]+','\n'.join(o['stdin_script'] for o in ops))))
 return dict(input_preserved=not input_changes,input_changes=input_changes,source_changes=source_changes,operations=len(ops),operation_wall_seconds=sum(o['wall_seconds'] for o in ops),operation_started_at_utc=ops[0]['started_at_utc'],operation_finished_at_utc=ops[-1]['finished_at_utc'],logger_revisions=[dict(operation=i+1,sha256=o['logger_sha256']) for i,o in enumerate(ops)],stderr_events=[dict(operation=i+1,exit_code=o['exit_code'],stderr=o['stderr']) for i,o in enumerate(ops) if o['stderr'] or o['exit_code']!=0],artifact_sha256={str(p.relative_to(w)):digest(p) for p in sorted((w/'out').rglob('*')) if p.is_file()},trace_sha256=digest(trace),source_path_references_in_logged_scripts=paths,common_context_sha256={n:digest(w/n) for n in ['AGENTS.md','ENVIRONMENT.md','TASK.md']})
