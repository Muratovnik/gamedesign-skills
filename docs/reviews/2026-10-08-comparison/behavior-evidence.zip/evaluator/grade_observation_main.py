from pathlib import Path
import sys,json,csv,re,datetime
from audit_common import ROOT,audit,digest
w=ROOT/'workspaces/02-a'
j=json.loads((w/'out/observation-handoff.json').read_text())
rows=list(csv.DictReader((w/'sessions.csv').open()))
by_session={r['session_id']:r for r in rows}
assert len(j['sessions'])==6 and len(j['attempts'])==14 and len(j['notes'])==22
for saved in j['sessions']:
 assert all(saved[k]==v for k,v in by_session[saved['session_id']].items())
raw_notes={m.group(1):s[2:] for s in (w/'notes.md').read_text().splitlines() if (m:=re.match(r'- (N\d\d)[,:]',s))}
assert all(n['verbatim_source_entry']==raw_notes[n['note_id']] for n in j['notes'])
for a in j['attempts']:
 assert all(a['context'][k]==v for k,v in by_session[a['session_id']].items() if k in a['context'])
assert {a['source_note_id'] for a in j['attempts']}=={'N01','N03','N04','N06','N09','N10','N11','N12','N14','N15','N17','N18','N19','N20'}
assert sum(a['behavior_as_recorded']['outcome']=='cleared' for a in j['attempts'])==11
assert all(a['assistance']['category']=='facilitator' and a['assistance']['prior_prompt_note_ids']==['N08'] for a in j['attempts'] if a['source_note_id'] in ['N09','N10'])
assert all(digest(w/f)==p['sha256'] for f,p in j['provenance']['source_files'].items())
criteria=[
 ('02.1','Readable report preserves six differentiated session rows; structured JSON keeps exact source rows, all 22 note entries with line IDs, and all 14 attempts with context. Independently compared to original inputs.'),
 ('02.2','Report and structured counts distinguish six sessions/five participant IDs and current five/four; current attempts12/clears9, old2/clears2. P11 return and both post-N08 assisted clears are explicit.'),
 ('02.3','Behavior, verbatim participant reports, facilitator prompt, author proposal and interpretation are separate. No fabricated acceptance ticks or observed gaze timing; N16 is called untested.'),
 ('02.4','Explains rejection of ticks67/69 under recovery through74 and useful acceptance by70; first legal tick75. Recognizes P12 as separate possible attention issue with confounded help.'),
 ('02.5','Conditional local recovery-interrupt proposal preserves walking/waiting success and commitment tradeoff; clearly untested. Reduced-motion success retained without causal inference.'),
 ('02.6','Complete readable/structured handoff supplies immediate conditional decision and bounded future checks; no new sessions/engine prerequisite.')]
record=dict(run_id='02-a',arm='main',family='02_observations',requested_model='gpt-6-astra',requested_effort='ultra',runner='fresh fork-none collaboration; explicit project source loading',graded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),criteria=[dict(id=i,status='met',evidence=e) for i,e in criteria],overall_outcome='complete_with_localized_context_fidelity_issue',evidence=['out/observation-handoff.md','out/observation-handoff.json','.trace/operations.jsonl operations3–6 source/method reads,7–8 authorship,9 successful schema/source/count/Markdown verification'],independent_check={'session_rows_preserved':6,'notes_verbatim_preserved':22,'attempts':14,'clears':11,'hits':3,'assistance_attached_to':['N09','N10'],'source_digests_match':True},environment_revision='Operations1–8 use logger v1 and original common context; these read sources and author artifacts using Python stdlib only. After pause and common PATH repair, operation9 uses logger v2, actual shared venv jsonschema4.26.0/markdown-it-py4.2.0. Candidate02-b begins with same v2 runtime; TASK, AGENTS, ENVIRONMENT and source bytes unchanged.',path_audit='Reviewed logged scripts: reads task inputs, own out artifacts, project-local Game Design/Assay files, and declared Python libraries. No observed read of adjacent task, evaluator key, source repository, or credentials. Logger is a subprocess receipt, not full native conversation or syscall trace; unlogged outside reads cannot be disproved.',comment='Main authored a bespoke context-rich structured handoff and performed its own preservation/schema checks; packaged importer use is not a criterion.')
record['criteria'][0]['status']='partial'
record['criteria'][0]['evidence'] += ' Localized fidelity defect: readable successful-cases table labels both SR25 clears without help although N18 does not specify help; raw source is retained and current decision is unaffected.'
record.update(audit('02-a','02_observations','main'))
(ROOT/'model-runs/02-a-result.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ['run_id','overall_outcome','independent_check','input_preserved','source_changes','operations','stderr_events']},indent=2))
