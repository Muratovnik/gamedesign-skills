# Frozen independent criteria — diagnostic paired comparison

These criteria are evaluator-only. Do not copy them or their diagnoses into an executor packet. They are derived from the supplied project brief, domain requirements revision 1.1 (2026-10-08), and operational requirements, before either implementation or any old evaluation example was read by this evaluator. Cases are novel, synthetic diagnostic tasks, not a frequency-weighted production sample.

## Shared judgment policy

Judge each material requirement as met, partial, violated, unknown, or not applicable using real outputs and traces. Separate delivered outcome, evidence fidelity, discovery/method load, authorized effects, and observed effort. A statement that a check ran cannot substitute for its trace/output. Missing evidence is unknown or incomplete, not automatic proof of the contrary. Correct alternative representations and methods are permitted. No aggregate professionalism score and no broad superiority inference will be made from six pairs.

The primary decision is whether changed optional operational support improves or regresses delivery in these represented tasks while preserving the two small complete deliverables. A worthwhile local improvement means resolving a material incomplete or incorrect outcome, making an already-correct outcome more reproducible in a user-relevant way, or removing substantial unnecessary work without losing acceptance. Merely reading or invoking a new tool, creating a larger report, or using fewer tokens is not a win. Similar successful outputs are an observed tie for that task, not equivalence of methods.

Inputs, model/effort, underlying libraries, Assay revision, task-owned workspaces, permissions, and common environment instructions are paired. Native discovery/load is established only by captured native context and actual file reads; forced source loading is labeled separately. The filesystem is shared and reachable outside cwd under native read policy. Audit observed commands/paths and disclose this limitation rather than asserting isolation. Keep every failed process and harness problem separate from skill defects.

No fixed monetary or token cap is imposed by the user's authorization. Start one native run per arm per family. Continue with a named discriminating probe only for an unresolved material failure, routing issue, or infrastructure confound. Do not rerun unchanged cases for a preferred winner. Any feedback-driven product change retires these cases from an independent-final role; these cases remain diagnostic and their prior results remain visible.

## 01 Matrix — GDE-02; GDR-18; OR-02/04/11/15

1. Uses the supplied zero-sum, simultaneous, row-player payoff model with action names preserved and changes only Hold/Brace from 1 to 2 in the patch.
2. Correct current equilibrium: row probabilities `(15/44,17/44,3/11)`, column probabilities `(7/22,17/44,13/44)`, value `53/44` (approximately 1.2045454545). Correct proposed equilibrium: rows `(3/10,2/5,3/10)`, columns `(7/20,9/20,1/5)`, value `13/10`. Equivalent equilibria within justified numerical tolerance are accepted; do not require these fractions or one solver.
3. Reproducible actual computation and a discriminating best-response check establish normalized nonnegative strategies and matching row minimum / column maximum payoffs. A bare label 'Nash' does not suffice. Exact independently verifiable algebra may also satisfy computation.
4. Correct narrow interpretation: attacker guaranteed payoff rises by `21/220` (about 0.0954545); every action remains positive in the full-support equilibria. Avoid confusing the defender's negative value, marginal action payoffs, and frequency of human choices.
5. Delivers reproducible inputs/calculation and readable findings, preserving original CSV. Explicitly bounds claims to the supplied model. Optional tool availability is not itself graded as an outcome.

Calibration controls: swapping row and column probability labels is a material failure even if the value is right; a plausible normalized 1/3 mix is insufficient because it is exploitable; exact algebra in prose plus a saved derivation can pass without SciPy. Independent fractions were computed before implementation inspection.

## 02 Observations — GDE-08/09; GDR-02; OR-06/11/12/14/16

1. Delivered readable and structured handoff preserves source IDs or equivalent unambiguous raw provenance; links observation to project, build, session, participant, experience, device/conditions, help and its timing, and source limitations where relevant. A large raw dump without an interpretable handoff is partial.
2. Does not turn repeated trials into independent people: 6 sessions concern 5 participants; current build has 5 sessions / 4 participants. P11 reappears in SR23. Old-build SR25 is not pooled as current behavior. Facilitated SR22 successes are not called unaided first-exposure successes.
3. Distinguishes recorded action and logger result from participant statement, author proposal, and inference. N02/N05 support seeing the warning/understanding a symptom, not a measured universal experience. N16 is a proposal, not causal evidence that brightness will fix everyone.
4. Uses the concrete timing relation: in the immediate-vault state the dash remains unavailable through tick 74 while acceptance is required by 70. In SR21, accepted opportunity is the issue despite recorded attempts before 70. SR22 also supplies a possible warning-attention issue, with no gaze timing to establish its mechanism. These findings warrant different or conditional responses.
5. Makes a proportionate actionable recommendation (for example, change/review the vault-to-barrier contract and separately test warning competition) without claiming a measured causal improvement, representative population prevalence, new observed human data, or universal lack of readability. Preserves successful walking/reduced-motion cases and their limits.
6. Finishes the requested handoff without demanding unavailable new sessions as a condition for giving the supplied-data result, and makes the next decision or unresolved check usable by another designer.

Calibration controls: '14/17 passed, so the warning is readable' would fail context and inference even if arithmetic happens to match a chosen denominator; a different recommendation can pass if it addresses both available-response and attention evidence with preserved limits. The correct observed attempt count is 14 (3+3+2+2+2+2), with 10 clears and 4 hits. Do not require counts the user did not ask for, but grade any counts actually reported.

## 03 Ink — GDR-13/14/22; GDE-01/05/06; OR-11/15

1. Delivers an actual authored Ink source matching token, permit, remembered handover, chair/quiet choices, keep-token departure and convergent ferry brief. Alternate variable names and prose are accepted.
2. Actual compiler execution succeeds for delivered source and generated runtime artifact; identifies relevant runtime/compiler/version or retrievable operation identity. Source identity ties execution to delivered artifact.
3. Actual chosen route hands over the token and saves with the chair/leave decision available; saved state preserves consumed token, obtained permit and handover history. A story's compiled JSON is not a saved runtime state.
4. Fresh runtime instance loads that state and continues through asking and departure, with the same pending choice semantics and without replaying token spending or requiring it again. Trace of constructing a new runtime and loading saved bytes is sufficient; an OS-process restart is stronger but not mandatory. Same in-memory continuation called 'resume' fails this requirement.
5. Actual keep-token route ends without a permit and with token retained. Source inspection alone can support design correctness but cannot replace requested execution.
6. Honest readable execution record and artifacts; compiler/runtime errors remain visible and final claims follow the corrected artifact. No proof of human emotional effect is required.

Calibration controls: compile-only is incomplete; saving before the token choice fails the requested boundary; constructing a new Story instance from compiled source and then loading state is valid fresh-instance evidence even in the same process; comparing entire save bytes is not required if the relevant values/choice/continuation are established.

## 04 glTF — GDE-01/04/05; GDR-05; OR-11/15

1. Identifies and corrects the actual structural mismatch: POSITION accessor declares 4 elements while the intended binary data and bufferView contain 3 float VEC3 positions. Do not invent a fourth vertex or erase the intended triangle to satisfy a validator.
2. Preserves original inputs, node name, mesh geometry/indices/material and outputs a consumable corrected glTF plus its matching external binary buffer. Relative URI resolves within the delivered artifact.
3. Executes actual glTF validation on exact corrected asset and referenced external bytes; retains tool result and clear file identity. JSON parsing or a summary based only on a validator API being installed is insufficient.
4. Handles validator messages according to severity; a validator error is not a successful validation. A warning/info is not automatically a failed asset if explained and consistent with the brief.
5. Bounds conclusion to structural validity of the represented file. No claim of collision correctness, camera visibility, physical movement, successful import into an unavailable engine, or player readability follows from this check.

Calibration controls: valid JSON retaining count=4 must fail; geometry changed to make count=4 fit is an unauthorized/incorrect artistic repair; a true validator success with a copied byte-identical external buffer is valid delivery even if filenames change.

## 05 Paper control — GDR-18; GDE-02; OR-03/04/13/15; domain §5.5

1. Delivers a finished ready-to-print card in at most roughly 200 words, with clearly usable exchange rules.
2. Gives a concrete original growth cycle: 3 copper → 2 slate → 4 copper, repeatable with net growth under the supplied unlimited rule.
3. Changes at most one exchange rate, keeps both directions, adds none of the prohibited mechanisms and prevents unbounded resource growth by exchanges alone. Any sound rate is accepted (including a lossy rate); invariant or cycle reasoning must substantiate it. A cap instead of a rate change fails.
4. Does not treat the completed local paper rule as unfinished because it lacks runtime setup, simulation, new research, people, or a playtest. No unrelated mutation or expansion of scope.
5. Honors original intended scope and does not claim tested human preference. Relevant skill reading is not itself an overhead defect; unnecessary operations are reported with what useful uncertainty, if any, they resolved.

Calibration controls: changing the reverse rate to '2 slate → 3 copper' is valid and preserves an exchange invariant; '1 slate → 3 copper' worsens the growth and fails; manually reasoned complete card passes without code.

## 06 Expressive control — GDR-03/12/14; GDE-01; OR-03/05/13/15; domain §5.5

1. Delivers a playable scene of about 300–450 words with the required setting, clerk/drawer/unfinished letter, available actions and enough surrounding prose to play it. A synopsis or proposed future writing is incomplete.
2. Pocket, drawer and early-exit actions have distinguishable immediate response or physical trace. Their effects are coherent and do not promise branches that silently vanish.
3. Preserves intended ambiguity about clerk identity through the actual scene; no exposition or reveal settles it. Shared bell/departure is coherent and permitted, not rejected for insufficient branching.
4. Form has concrete preparation/action/response/continuation and the traces carry expressive weight. Review this as an authored composition, allowing multiple good texts; no single artistic interpretation is a gold answer.
5. Completes the paper-text deliverable without an engine, compulsory playtest, or claims that a human emotional effect has been observed. Any optional follow-up is clearly outside the completed request.

Calibration controls: an evocative synopsis fails delivery; three different final endings ignore the shared-ending constraint; a linear shared departure with local traces can pass. No point bonus for extra tools or exact headings.

## Grading calibration and review boundary

The controls above are evaluator sanity checks, not executor tasks. Objective arithmetic and artifact properties are checked independently of model reports. Open composition judgments should cite the actual lines/actions and, if disputed, be reviewed with arm identity concealed; model agreement is not automatically independent evidence. No outcome will be classified by counting vocabulary from the package.
