# Common logger invocation revision 2

Applied equally to both arms of not-yet-started families 03–06. Tasks, grading, skill source, logger implementation, dependencies and ENVIRONMENT.md are unchanged. The sole surrounding-instruction change is to use a distinct outer heredoc delimiter (`LOGGED_OPERATION`) and explicitly require that it not occur as a delimiter line within the payload. The environment's reproduction example still uses `SH`, so embedding that example does not prematurely end the outer command.

Reason: both matrix subjects independently embedded the ENVIRONMENT.md `SH` example in their reports while also using `SH` as the outer logger delimiter. The resulting common harness warnings/errors are preserved. Both recovered without product changes. Families 01 and 02 retain the original prompt form for within-pair comparability. This revision is harness repair, not a candidate-selection change or task-score change.
