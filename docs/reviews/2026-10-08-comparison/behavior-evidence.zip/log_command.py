"""Record the actual subprocess boundary for a task-local shell operation."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

workspace = Path(__file__).resolve().parents[1]
script = sys.stdin.read()
if not script.strip():
    raise SystemExit("Supply a shell script on standard input.")
trace = workspace / ".trace"
trace.mkdir(exist_ok=True)
environment = dict(os.environ)
environment["PATH"] = str((workspace / ".runtime/python-bin").resolve()) + ":" + str(Path(os.environ["CODEX_PRIMARY_RUNTIME_NODE"]).parent) + ":" + os.environ["PATH"]
environment["NODE_PATH"] = str(workspace / ".runtime/node_modules")
started = time.monotonic()
record = {
    "type": "subprocess_operation",
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "cwd": str(workspace),
    "argv": ["/bin/bash", "--noprofile", "--norc"],
    "stdin_script": script,
    "stdin_sha256": hashlib.sha256(script.encode()).hexdigest(),
    "logger_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "environment_overrides": {key: environment[key] for key in ("PATH", "NODE_PATH")},
}
result = subprocess.run(record["argv"], input=script, cwd=workspace, env=environment, text=True, capture_output=True, errors="backslashreplace")
record.update({
    "finished_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "wall_seconds": time.monotonic() - started,
    "exit_code": result.returncode,
    "stdout": result.stdout,
    "stderr": result.stderr,
})
with (trace / "operations.jsonl").open("a") as output:
    output.write(json.dumps(record, ensure_ascii=False) + "\n")
sys.stdout.write(result.stdout)
sys.stderr.write(result.stderr)
raise SystemExit(result.returncode)
