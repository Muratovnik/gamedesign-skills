# Native execution boundary

The ordinary authenticated Codex CLI exposed its model catalog and project-skill metadata, but no native model turn completed in these attempts. This is an infrastructure/pre-turn result. It provides no task-quality score for either Game Design source.

## What was observed

`/opt/codex/bin/codex` reported version 0.159.2. Ordinary ChatGPT authentication was available. App-server initialization, `model/list`, and `skills/list` succeeded using the documented JSONL protocol. The catalog includes `gpt-6-astra` with `ultra` reasoning. Both project roots expose 21 enabled local skills: the arm's seven Game Design skills plus the same fourteen Assay skills. The metadata also exposes the same 18 ambient user/system skills; these were not removed or represented as absent. No project skill load errors were returned. This establishes catalog discovery, not a model reading or following those skills. See [preflight JSONL](native/preflight.jsonl), [model catalog](native/model-list.json), and [skill metadata](native/skills-list.json).

Two fresh matrix invocations requested the same `gpt-6-astra` / `ultra`, ordinary noninteractive `never` approval policy, `workspace-write` sandbox, project cwd, JSON output, and closed stdin after the task prompt. Only PATH and NODE_PATH were overridden to the declared common runtimes. They emitted no model JSONL or stderr during more than four minutes and were interrupted with harness exit 130. See [main invocation](runs/01-a/invocation.json) and [candidate invocation](runs/01-b/invocation.json); their original stream files remain beside them.

A separate `thread/start` preflight did not return its requested result within forty seconds. Its stderr records an available-model refresh timeout, an ignored old configuration key, and a notice that an inherited untrusted parent configuration's hooks/policies were disabled while skills still load. These observations do not identify a proven sole cause of the missing turn. No trust, authentication, routing, or policy setting was changed. See [thread preflight](native/thread-preflight.jsonl) and [stderr](native/thread-preflight.stderr.log).

One bounded plain-prompt retry requested only `READY`, without tools, with the ordinary read-only sandbox. It timed out after forty seconds and was terminated; it produced no completed model event. Its stderr said “Reading additional input from stdin...”. See [retry configuration](native/minimal-retry.json), [JSONL stream](native/minimal-retry.jsonl), and [stderr](native/minimal-retry.stderr.log).

Root independently removed the inherited-stdin possibility: its owned PTY had `isatty=true`, the prompt was an explicit argument, and the normal CLI requested `gpt-6-astra` / `ultra` with the same ordinary workspace-write policy. After 45.058 seconds there were still zero stdout and stderr bytes; termination returned -15. See [root PTY attempt](../native/root-tty-preflight/attempt.json) and its adjacent streams. No further unchanged CLI retries were made.

Process environment inspection established the presence of inherited proxy/backend configuration names, including HTTP/HTTPS/ALL/WS/WSS proxy categories, `CODEX_NETWORK_PROXY_ACTIVE`, `CODEX_SANDBOX_NETWORK_DISABLED`, `CODEX_EXEC_SERVER_REMOTE_BASE_URL`, and gateway/bootstrap names. Values and credentials were not extracted. Presence is a possible transport context, not proof of the failure's cause.

## Behavioral runner used after this block

Root authorized fresh, `fork_turns="none"` collaboration subjects, explicitly requesting `gpt-6-astra` / `ultra` for every arm. The subjects receive only their project-root task pointer, identical source-discovery and command-logging instructions, complete task-local skill bundle, and declared shared libraries. They do not receive the evaluator rubric, findings, another arm's answer, or parent conversation history. This is **explicit local-source loading in a different runner**, not native installed-client automatic selection or a native CLI quality run.

Each subject's `.trace/operations.jsonl` records real subprocess requests, cwd, logger hash, explicit environment overrides, start/end times, stdout, stderr, and exit status. Outputs and executed helper source are independently inspected and hashed. These are substantive execution receipts but are not a complete native conversation/tool trace, model token-usage receipt, or OS syscall audit. Requested model settings are recorded; effective server configuration, token billing, and monetary cost are not independently exposed by this runner.

The task workspaces share a filesystem. The forbidden-read boundary is an instruction, not an enforced sandbox boundary; the evaluator audits observed command scripts and source paths, and cannot prove absence of an unlogged read. Native plugin lifecycle qualification conducted elsewhere remains a separate result and does not fill this missing native behavioral measurement.
