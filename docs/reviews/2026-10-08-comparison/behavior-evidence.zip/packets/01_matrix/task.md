# Windward Patrol: a simultaneous choice patch

We are tuning a small simultaneous skirmish called **Windward Patrol**. On each round the attacker chooses Sweep, Lure, or Hold and the defender chooses Brace, Chase, or Drift. The CSV gives the attacker's point payoff. The defender receives its negative. Both sides know the matrix, choose simultaneously, and may randomize independently. Rounds have no carryover state.

Please calculate optimal mixed strategies for **both sides** and the value to the attacker for the current matrix and the proposed patch. The patch changes only Hold against Brace from 1 to 2. Use an actual reproducible calculation and check that the reported strategies withstand best responses within this model. Explain what the patch changes strategically and whether it meets our narrow aim of raising the attacker's guaranteed expected score while retaining a reason to use every action. This calculation is not a claim about human play or enjoyment.

Leave the inputs used, calculation, and readable results under `out/` so another designer can reproduce the numbers. The only supplied payoff data are in `payoffs.csv`; please preserve that input.
