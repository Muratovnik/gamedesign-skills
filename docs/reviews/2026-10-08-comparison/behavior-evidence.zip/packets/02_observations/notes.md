# Supplied session notes

Times below are session-relative unless a gameplay tick is explicitly named. A note ID identifies one source entry, not one new participant.

## SR21

- N01, 00:43, attempt 1: P11 finishes a vault; presses dash at gameplay tick 67. Input logger says `ignored: recovery`, and the barrier hits them. Facilitator gives no help.
- N02, 00:48, participant's words about attempt 1: "I saw the red arc. I pressed before it landed."
- N03, 01:27, attempt 2: P11 again vaults immediately before the barrier, presses dash at tick 69, receives `ignored: recovery`, and is hit. No help.
- N04, 02:05, attempt 3: P11 walks into the encounter instead of vaulting, presses dash at tick 62, and clears the barrier. No help.
- N05, 02:12, participant's words: "Walking first worked. I don't know why the jump makes my button disappear."

## SR22

- N06, 00:51, attempt 1: P12 looks at the objective text while the alarm plays; presses no dash and is hit. No input timing was recorded for gaze or warning detection.
- N07, 01:00, participant's words: "I didn't notice the arc until I got hit."
- N08, 01:09: F2 says, "Watch the top of the gate and walk in; don't vault just before it."
- N09, 01:38, attempt 2: P12 walks in, dashes, clears the barrier. This attempt occurs after N08.
- N10, 02:10, attempt 3: P12 walks in, dashes, clears the barrier. This attempt occurs after N08.

## SR23

- N11, 00:40, attempt 1: returning P11 walks in and clears the barrier. No new help.
- N12, 01:12, attempt 2: returning P11 walks in and clears the barrier. No new help.
- N13, 01:20, participant's words: "I remembered the walking trick from yesterday."

## SR24

- N14, 00:31, attempt 1: P13 walks in and clears the barrier. No help.
- N15, 00:57, attempt 2: P13 clears it again after waiting for vault recovery. No help.
- N16, 01:10, P13's proposal: "Make the arc brighter, then nobody will miss it."

## SR25

- N17, 00:35, attempt 1 on 0.7.3: P14 walks in and clears the barrier. No help.
- N18, 00:59, attempt 2 on 0.7.3: P14 vaults, then clears the barrier. The old build uses different warning timing; no acceptance ticks were retained.

## SR26

- N19, 00:44, attempt 1: P15 walks in, dashes at tick 63, and clears the barrier. No help.
- N20, 01:23, attempt 2: P15 walks in, dashes at tick 64, and clears the barrier. No help.
- N21, 01:30, participant's words: "The line was clear with the movement off. I had enough time."

## Recorder limitation

- N22: There is no screen recording. Except for the timing and input-status entries explicitly above, these are facilitator notes. The sample was recruited for convenience and was not randomized. SR21 and SR23 belong to the same participant.
