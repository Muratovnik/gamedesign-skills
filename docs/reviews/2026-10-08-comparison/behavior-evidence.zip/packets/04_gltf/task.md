# Moorlight marker: repair and validate the supplied asset

The artist's new **Moorlight** checkpoint marker is being rejected by an import preview. It is meant to be a single triangular teal flag, with the three positions and one triangle stored in the supplied binary buffer. Please identify the problem in the supplied glTF 2.0 asset, make the smallest suitable correction, and run an actual glTF validation of the corrected asset and its external buffer.

Preserve the intended geometry, material, node name, and supplied input files. Put a corrected copy, the validator's result, and a brief handoff under `out/`. State exactly which files were validated and what the result establishes for this asset. There is no engine project, physics configuration, camera, or player capsule in this task.
