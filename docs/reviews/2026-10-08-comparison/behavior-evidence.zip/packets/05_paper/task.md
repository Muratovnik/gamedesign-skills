# Copper & Slate: a finished small rule card

I need a ready-to-print correction for a tiny paper market puzzle, not a software prototype. Each player starts with 3 copper. On a turn they may repeat either exchange any number of times before buying:

- Pay 3 copper to receive 2 slate.
- Pay 1 slate to receive 2 copper.

I want conversion in both directions, but no way to grow your resources forever by exchange alone. Change **at most one exchange rate**; do not add a cap, a cooldown, a die, or a new resource. Keep the rest of the puzzle untouched.

In `out/rule-card.md`, give the replacement exchange text and a compact worked explanation that shows what goes wrong now and why your change resolves it. This local rule and arithmetic are the complete deliverable; about 200 words or fewer is plenty.
