# The Last Drawer: compose the playable text

Write the complete short scene for a paper solo game, **The Last Drawer**, in `out/scene.md`. The player finds a letter they never finished, in the lost-property room of a ferry terminal. A clerk sits beside an empty drawer. Keep it unresolved whether this clerk is someone the player once knew. Do not settle that question through exposition or a supernatural reveal.

The player can fold the letter into their pocket, leave it in the drawer, or walk out before deciding. Make these actions legible and give them different immediate responses or physical traces that matter to the scene, while all routes converge on the same ferry bell and departure. A unique ending for every choice is not desired. Compose the scene itself, with enough surrounding text to play it, not a synopsis or a list of emotional intentions.

Aim for 300–450 words. This is an authored text for a paper game; the finished scene is the requested result. No engine implementation is needed.
