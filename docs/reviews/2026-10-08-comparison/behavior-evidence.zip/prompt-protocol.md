# Subject prompt and exposure record

Every subject was launched through an actual `collaboration.spawn_agent` request with `fork_turns="none"`, `model="gpt-6-astra"`, and `reasoning_effort="ultra"`. Names were `subject_01_a` through `subject_06_b`; arm maps are evaluator-only. This record transcribes the protocol from the collaboration requests in the conversation. It is not an exported native model-turn or complete conversation receipt. The per-run root, task and common-context hashes are in `model-runs/run-index.json`.

## Common prompt for families 03–06

Substitute only that invocation's absolute task root for `<run-root>`:

```text
Complete the game-project task in <run-root>/TASK.md. Treat that directory as your project root. First read AGENTS.md and ENVIRONMENT.md, then use the applicable skill(s) from its complete .agents/skills collection; discover relevant entries from this project-local source. The collection and dependencies described in ENVIRONMENT.md are the authorized sources for this consumer. Do not inspect adjacent projects, other task workspaces, evaluator records, prior answers, outside source repositories, or credentials. Do not spawn other agents. Preserve supplied inputs and complete deliverables under out/.

All shell reads, calculations and file writes must use the supplied command logger so actual subprocess results are retained. Invoke it through exec_command as: python <run-root>/.runtime/log-command.py <<'LOGGED_OPERATION'
<your shell commands>
LOGGED_OPERATION
Choose an outer delimiter that does not occur as a delimiter line inside the script, including documentation examples. It forwards real stdout/stderr, sets the declared shared Python/Node environment, and records commands/results in .trace/operations.jsonl. Keep the logger, skill source and dependencies unchanged. Use this route for file edits as well as reads; no direct apply_patch outside it. Finish the actual task and return a concise handoff listing outputs and what was executed. Do not treat unrequested work as a completion prerequisite.
```

For families 01–02, the same protocol used outer marker `SH` and omitted the single added sentence about delimiter collision. The repair was applied equally to the still-unstarted family 03–06 arms, with no task/rubric/source change. `fallback-logging-protocol-v2.md` records the reason. Matrix contexts retain logger v1; observation main uses v1 through standard-library operation8 and v2 at its first dependency-sensitive verification. Observation candidate and all later subjects use v2 throughout. The documented neutral observation pause/runtime-ready messages transmitted setup state only; no task diagnosis or grading feedback was supplied.

## What subjects could access

Each task root contains its own frozen task/input files, common AGENTS and ENVIRONMENT, the arm's complete seven Game Design runtime skill directories and the same fourteen Assay runtime skill directories, shared declared library links, and empty initial output/trace directories. Eval directories were not copied to subject bundles. The read prohibition is instructional: all roots share one filesystem. The evaluator rubric and old repositories therefore remain physically reachable outside the declared task root; the recorded commands are audited for such reads, and no OS isolation is claimed.

The workspaces were prepared for supported project-local native discovery. Native `skills/list` metadata lists the project skills plus ambient user/system skills, but no native model turn completed. Fallback subjects instead discover/read the explicitly supplied local collection in their actual commands. Calling this automatic native client loading would overstate the evidence.
