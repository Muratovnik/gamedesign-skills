"""Task-owned invocation receipt capture for the existing Codex CLI."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
run_id = sys.argv[1]
mapping = json.loads((ROOT / "evaluator/arm-map.json").read_text())[run_id]
workspace = Path(mapping["workspace"])
record = ROOT / "runs" / run_id
record.mkdir(parents=True, exist_ok=False)
prompt = (workspace / "TASK.md").read_text() + "\nAvailable local dependencies are described in ENVIRONMENT.md.\n"
(record / "prompt.md").write_text(prompt)
command = [
    "/opt/codex/bin/codex", "--no-daemon", "-a", "never", "exec",
    "--model", "gpt-6-astra",
    "-c", 'model_reasoning_effort="ultra"',
    "--sandbox", "workspace-write", "--json", "--color", "never",
    "--cd", str(workspace),
    "--output-last-message", str(record / "final.md"), "-",
]
environment = dict(os.environ)
environment["PATH"] = str(ROOT / "shared/python/bin") + ":" + str(Path(os.environ["CODEX_PRIMARY_RUNTIME_NODE"]).parent) + ":" + os.environ["PATH"]
environment["NODE_PATH"] = str(ROOT / "shared/node_modules")
receipt = {
    "run_id": run_id,
    "condition": mapping,
    "command": command,
    "requested_model": "gpt-6-astra",
    "requested_effort": "ultra",
    "approval_policy": "never (noninteractive refusal, sandbox and inherited rules retained)",
    "sandbox": "workspace-write",
    "fresh_context": True,
    "filesystem_isolated": False,
    "environment_overrides": {k: environment[k] for k in ("PATH", "NODE_PATH")},
    "runtime_bundle": os.environ.get("CODEX_PRIMARY_RUNTIME_BUNDLE_VERSION"),
    "prompt_sha256": hashlib.sha256(prompt.encode()).hexdigest(),
    "skill_snapshot_manifest_sha256": hashlib.sha256((ROOT / "sources" / mapping["arm"] / "manifest.json").read_bytes()).hexdigest(),
    "assay_snapshot_manifest_sha256": hashlib.sha256((ROOT / "sources/assay/manifest.json").read_bytes()).hexdigest(),
    "started_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "cost_boundary": "CLI run wall time and returned usage; billed monetary cost/subscription quota unavailable",
}
(record / "invocation.json").write_text(json.dumps(receipt, indent=2) + "\n")
started = time.monotonic()
with (record / "native-events.jsonl").open("w") as output, (record / "stderr.log").open("w") as errors:
    process = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=output, stderr=errors, text=True, env=environment)
    receipt["pid"] = process.pid
    (record / "invocation.json").write_text(json.dumps(receipt, indent=2) + "\n")
    process.communicate(prompt)
receipt["exit_code"] = process.returncode
receipt["wall_seconds"] = time.monotonic() - started
receipt["finished_at_utc"] = datetime.datetime.now(datetime.timezone.utc).isoformat()
events = []
for line in (record / "native-events.jsonl").read_text().splitlines():
    try:
        events.append(json.loads(line))
    except json.JSONDecodeError:
        receipt.setdefault("non_json_output_lines", []).append(line)
thread_ids = [event["thread_id"] for event in events if event.get("type") == "thread.started"]
receipt["thread_ids"] = thread_ids
receipt["usage_events"] = [event for event in events if event.get("type") in ("turn.completed", "turn.failed", "error")]
for thread_id in thread_ids:
    # Search only file names for this run's known identifier; never inspect other sessions.
    candidates = list((Path.home() / ".codex/sessions").rglob(f"*{thread_id}*.jsonl"))
    receipt.setdefault("own_rollout_paths", []).extend(map(str, candidates))
    for index, source in enumerate(candidates):
        shutil.copy2(source, record / f"rollout-{index}.jsonl")
receipt["output_files"] = {
    str(path.relative_to(workspace)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted((workspace / "out").rglob("*"))
    if path.is_file()
}
(record / "invocation.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps({"run_id": run_id, "exit_code": process.returncode, "wall_seconds": receipt["wall_seconds"], "thread_ids": thread_ids, "outputs": list(receipt["output_files"])}), flush=True)
