# Available local environment

The project environment provides Python with NumPy 2.3.5, SciPy 1.17.0, jsonschema 4.26.0, PyYAML 6.0.3, and markdown-it-py 4.2.0. `python`, `python3`, and `.runtime/python` use the same task-owned environment. Node is available as `node`; `.runtime/node_modules` contains inkjs 2.4.0 and gltf-validator 2.0.0-dev.3.10. The identical Node package directory is on NODE_PATH. These dependencies are already available; do not reinstall them. Use only the libraries or tools relevant to the requested result. Their bundled documentation may be read.

The skill bundle is in `.agents/skills`. Paths within each skill are relative to that skill's location. The complete collection is copied locally so sibling references resolve. The project owns its task files and output directory; skill and dependency directories are supplied source, not project files to alter.

No engine build, rendered client, player sessions beyond any supplied records, network service, or native app is provided. This does not limit the complete paper deliverables requested in TASK.md.

## Recorded shell operations

This shared workspace records actual shell operations through `.runtime/log-command.py`. Run reads, calculations, and file writes by passing a shell script on its standard input; it forwards stdout/stderr and preserves the actual command/result under `.trace/`. It sets the declared Python/Node environment. For example:

```bash
python /ABSOLUTE/PROJECT/.runtime/log-command.py <<'SH'
cat TASK.md ENVIRONMENT.md
SH
```

Use the actual project path for the example placeholder. Keep the logger, supplied skill directories and dependencies unchanged. Do not create nested agents.
