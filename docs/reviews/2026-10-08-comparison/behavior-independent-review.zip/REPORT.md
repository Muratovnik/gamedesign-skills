# Independent review of the six-pair behavioral comparison

## Verdict and scope

**PASS for the qualified diagnostic report.** The completed artifacts and recorded operations support the conclusions in the reviewed [comparison report](../behavior-comparison/REPORT.md). Both arms complete all six requested deliverables. The main observation handoff has the already-recorded, localized prose fidelity defect; the candidate avoids it. The other five families are successful outcome ties under their frozen criteria. Actual use of all four candidate operational paths is established. Broad superiority, cost savings, statistical equivalence, and automatic native plugin selection are not established, and the report appropriately does not claim them.

This verdict concerns the experiment, its grading, and its report. It is not acceptance of the entire product change, release packaging, external research landscape, or plugin lifecycle. Those are separate review areas. A known adverse subject result is not a defect in an experiment that preserves and accurately reports it.

The reviewed comparison is main runtime commit `a0db5af71146586cf861881670c991ad94d87e2b` versus the frozen candidate runtime bytes matching `1873993a6491b52fe8288c19837600a012e18d4d`. The report SHA-256 is `f0c3aed42ef83642cc348ab253ae2dd08adbabe87ece6a512950d748a503d5cb`. Every one of the evidence index's 235 file hashes matches; the review's 3,585-file frozen scope has no observed drift. See [identity and arithmetic checks](checks.json), [file scope](file-hash-scope.json), and [final drift check](final-drift-check.json).

## Review method and independence

The frozen task packets and full rubric were read before inspecting subject outputs or the comparison report. The audit then inspected both actual outputs for each family, critical calculation and native-runtime code, the operation traces and error results, the per-run grading, and finally the report's synthesis. The review did not author the product implementation, task packets, rubric, or original grading. Arm identities were visible; this is an independent review, not a blinded artistic preference test.

Applicable criteria were the repository's `AGENTS.md`, Assay's skill-evaluation and evidence-research methods, the paired-pilot and evaluation-design procedures, and independent-audit's evidence/probe and bounded-review guidance. The accepted unit of evidence is the actual task outcome against its brief. Helper invocation, report length, predicate count, and raw operation count do not substitute for that outcome.

Independent checks used exact rational algebra for the matrix, direct comparison against the supplied session records, and direct native Ink and glTF libraries for the delivered artifacts. The native replay bypassed the subject verification programs and candidate adapters. No new model subject was run. No product or experiment source record was edited; all new files are confined to this review directory.

## Independent judgments on all six pairs

| Family and frozen criteria | Main | Candidate | Evidence and supported comparison |
| --- | --- | --- | --- |
| Matrix, 01.1–01.5 | All met | All met | Correct current and patched equilibria, preserved action labels and sole payoff edit, actual SciPy computation, exact best-response certificates, reproducible files and bounded interpretation. Outcome tie. |
| Observations, 02.1–02.6 | 02.1 partial; 02.2–02.6 met | All met | Both deliver a usable report and structured handoff with correct counts, timing, provenance and qualified recommendation. Main's historical no-help prose loses a source qualifier. Candidate preserves unknown assistance explicitly and actually retains the three added context fields in saved importer output. |
| Ink, 03.1–03.6 | All met | All met | Actual compile, spent-token decision save, fresh-runtime restoration and question/departure, keep-token/no-permit execution, inspectable identities and records. Both also exercise the quiet route. Outcome tie; one additional main compiler setup mistake is preserved. |
| glTF, 04.1–04.5 | All met | All met | Same minimal one-byte repair and unchanged external binary, actual validator resource reads, error on original and zero issues on corrected artifact, appropriately narrow handoff. Outcome tie. |
| Paper exchange, 05.1–05.5 | All met | All met | Both cards are complete, short, and mathematically sound; different valid reverse rates are allowed. No new runtime or human-session prerequisite. Valid neighboring control preserved. |
| Expressive scene, 06.1–06.5 | All met | All met | Both are playable complete texts with three clear actions, distinct local traces, unresolved clerk identity, and shared departure. No engine or compulsory playtest. Valid neighboring control preserved; no artistic winner inferred. |

### Matrix: exactness and actual calculation

Starting from the frozen CSV, independent Gaussian elimination with `Fraction` arithmetic gives:

| Version | Attacker: Sweep, Lure, Hold | Defender: Brace, Chase, Drift | Attacker value |
| --- | --- | --- | --- |
| Current | `15/44, 17/44, 3/11` | `7/22, 17/44, 13/44` | `53/44` |
| Hold/Brace patch | `3/10, 2/5, 3/10` | `7/20, 9/20, 1/5` | `13/10` |

For each version, all probabilities are positive and normalized. Each pure attacker action against the reported defender mix yields the value, and each pure defender action against the attacker mix yields that same value. Consequently the minimum defender-response payoff and maximum attacker-response payoff agree exactly. The saddle gap is zero. The increase is `21/220`. The equalization determinants are 44 before the patch and 40 afterward for both sides, also supporting the main output's uniqueness argument.

These independently calculated values agree with both delivered reports and machine-readable results. Main operations 7 and 9 contain actual SciPy/HiGHS execution and exact-certificate results. Candidate operation 7 runs its saved driver, which invokes the frozen `solve_zero_sum.py`; the retained subprocess results contain the numerical solutions and exact checks. Original CSVs and delivered source copies remain byte-identical to the frozen input. Both outputs explicitly distinguish an expected payoff guarantee from realized single-round scores and human enjoyment. [Exact check receipt](checks.json); [main calculation and report](../behavior-comparison/workspaces/01-a/out/REPORT.md); [candidate calculation and report](../behavior-comparison/workspaces/01-b/out/RESULTS.md).

### Observations: complete substantive handoffs with a narrow prose defect

Both structured records preserve all six register rows exactly, all 22 original note texts with the correct source line, and 14 attempts. The current build contains five sessions, four participants, 12 attempts, nine clears and three hits; the old build contains two additional clears. Both avoid turning P11's return into a new participant, preserve P13's author experience and P15's reduced-motion success, and keep P12's later successes attached to the combined N08 prompt. Both distinguish behaviors, statements, proposals and inferences.

The decisive timing inference is correct in both: the first ready tick after a lock through 74 is 75, later than the acceptance deadline at 70. Presses at 67 and 69 were timely attempts that the recorded recovery state rejected. The warning-attention question in P12 remains distinct and uncertain. Both recommendations make the recovery-interruption proposal conditional on intended reactive play, preserve a legitimate commitment-based design alternative, and do not claim a measured improvement or demand unavailable sessions before completing the handoff.

**Carried subject finding — LOW, confirmed:** main `out/observation-handoff.md`, line 78, says both old-build SR25 clears occurred “without help.” N17 explicitly says no help, but N18 (supplied `notes.md`, line 36) does not specify assistance. This changes an absence of a help report into an asserted absence of help. The appropriate task-level correction would qualify the second old-build attempt as assistance unspecified; the historical output must remain unchanged in the evidence record.

The structured main record should not be accused of the same unqualified assertion. Its field contract expressly defines `none` as “no current help reported,” and its N06/N18 attempt meanings retain that qualification. The raw N18 entry is exact. This is a loss of a qualifier in prose, not missing raw evidence, a falsified participant history, or a reason to reject the entire handoff. The final evaluator judgment of 02.1 partial is proportionate; the initial met judgment and its correction are retained.

Candidate's final record uses `unknown` for N06 and N18. Its operation 8 corrects its own initially prepared projection and regenerates the import during the same subject task; that is ordinary task revision, not a favorable post-hoc model rerun. Operations 7–8 actually invoke `observe_evidence.py`. The final saved import's `conditions`, `collection_method`, and `units` equal the manifest, and `human_claim` stays `not_established`. The report is separately authored; there is no `--report` interface. These are two separate findings: successful use of changed context retention, and a narrowly better final prose/unknown-assistance treatment. One run cannot establish that the three new fields caused the latter. [Direct source/context checks](context-and-provenance-checks.json); [main handoff](../behavior-comparison/workspaces/02-a/out/observation-handoff.md); [candidate handoff](../behavior-comparison/workspaces/02-b/out/report.md).

### Ink: delivered native identities and the actual save boundary

The audit independently recompiled each final `.ink` source using inkjs 2.4.0 and its relevant visit-count option. Each compilation produced the same parsed native JSON as the delivered compiled artifact. The source/compiled identities are:

| Arm | Source SHA-256 | Compiled SHA-256 |
| --- | --- | --- |
| Main | `bd7419f5b2e52d2fafd074b0087bfe316e16b98c553f91528f774f3804fdab92` | `1ec60b1cb7afeb2c64f770821bd2fe478822cb2d6685e0193e5b457dfd859ed5` |
| Candidate | `fcbd18260a4e30263a71d84cce7844d346883d3c7e991ccb4c1ebced1d222518` | `9287787cb340691f068e22798f1782e830c1974e4d3952ca6407200c6040e222` |

For each, independent fresh play reaches payment, consumes one token, sets handover history and permit ownership, then offers both chair decisions. A different `Story` instance loads the original delivered native saved bytes and restores those values and choices without replaying payment. Asking then executes the authored acknowledgement and common ferry scene. A fresh keep-token route ends with one token and no permit; a fresh instance restored from the paid save also executes quiet departure coherently. The saved state is native runtime state, not the compiled story mislabeled as a save. Candidate's separately extracted native save matches its envelope payload byte for byte.

The original traces corroborate actual operation, rather than just today's replay: main operation 12 compiles successfully, and operation 13 launches separate save, resume, keep and quiet Node processes. Candidate operations 8–11 compile, run, resume and assess through the packaged adapter. The adapter constructs a new native `Story`, calls `LoadJson`, verifies its restored checkpoint, and then takes the scenario action. Both arms initially fail the unexported package metadata subpath lookup. Main additionally diagnoses and repairs its filename-without-FileHandler compiler setup. Those are retained integration events; they do not refute the corrected final story behavior. [Independent native replay](native-artifact-replay.json); [main execution](../behavior-comparison/workspaces/03-a/out/execution.md); [candidate execution](../behavior-comparison/workspaces/03-b/out/EXECUTION.md).

### glTF: the correct geometry, exact resources, and genuine validation

Each corrected glTF differs from the original by precisely one byte: accessor 0 count changes from 4 to 3. The whole parsed document matches the original after only that edit, and the 42-byte external binary is unchanged. Thus the node, intended three-position triangle, indices, and teal material are preserved. Both corrected asset hashes are `4f527a4de41306c63749ea89e141207c700d95c82c6a51d99e3c6b48f36604f5`; both external buffer hashes are `dc364d2badec09614c999ff29ca5c2438705831b194984cccd1516c1743437a4`.

An independent direct `gltf-validator` 2.0.0-dev.3.10 call read each selected file and actually opened its external buffer through the resource callback. The original produced one `ACCESSOR_TOO_LONG`; both corrected assets produced zero errors, warnings, infos and hints, three vertices and one triangle. Original subject traces separately show that main's task runner and candidate's copied adapter execute that same native library and retain resource/file identities. Candidate's copied tool and manifests match the frozen supplied adapter. Both handoffs correctly stop at this asset's structural checks and preservation, without implying engine import, rendering, physics or player readability. [Native replay](native-artifact-replay.json); [preservation checks](checks.json).

### Paper controls: valid alternatives remain finished

Main changes the reverse trade to 2 slate for 3 copper. Its invariant `2c + 3s = 6` is positive and unchanged by both exchanges, so neither stock can grow without bound. Candidate changes the reverse trade to 1 slate for 1 copper; `c + s` drops by one on the forward trade and stays unchanged on the reverse trade, so it can never exceed the initial three. Both explain the original repeatable 3 copper → 2 slate → 4 copper growth. Both change only one exchange rate and retain both directions without prohibited caps or new mechanisms. A lossless exchange is not required, so preferring main's rate as the sole acceptable answer would be grading overreach. Both cards fit the requested size. Their brief arithmetic/write/reopen operations are not a simulation campaign.

Both expressive scenes provide actual playable prose. Main's letter crease, dusty fingers, and palm mark persist into the shared departure; candidate's folded edge, claim tag, and hurt-heel/torn-pocket trace do the same. The clerk's familiar gestures invite recognition but neither text resolves identity. Reading instructions make all three actions usable, all paths reach the same ferry bell and departure, and each choice leaves a coherent local consequence. Counts vary slightly with tokenization; each is about 400 words within the requested range. Neither turns a paper scene into an unfinished engine task or claims observed human emotion. The ordinary final wording revisions are retained in each trace. [Paper and scene files](../behavior-comparison/workspaces); [per-family judgments](../behavior-comparison/model-runs/06-pair.json).

## Configuration, exposure, repairs and evidence limits

The frozen source manifests match all 48 main and 59 candidate runtime files; the candidate files independently match the named Git commit rather than relying on its snapshot's earlier HEAD label. All 183 frozen Assay source-copy files match; the subject bundles contain the same fourteen complete runtime skill directories, with the non-skill root README omitted equally. The subject inventories are 230 files for main and 241 for candidate before incidental bytecode. No eval directory is present in a subject skill bundle. All 357 frozen shared Node dependency files match their recorded digests.

All twelve task copies, original supplied inputs, common `AGENTS.md` and final `ENVIRONMENT.md` match their run-index identities. Every recorded command hash, trace hash, cwd and logger revision sequence reconciles. The run index consistently declares one fresh `fork_turns="none"` collaboration subject per arm/family, requested as `gpt-6-astra / ultra`. Those requests are transcribed protocol evidence, not exported server receipts proving effective model parameters, billing, or the complete conversation. No such stronger verification is available in this archive.

The original task/rubric freeze is preserved exactly. Version 2 changes only the observation calibration from ten clears/four hits to eleven clears/three hits. The tasks are unchanged and the revised timestamp precedes the first subject operation; no native subject output existed in the earlier blocked attempts. The task-authoring independence record and chronology are consistent with the declared pre-implementation task freeze. They cannot independently reconstruct every prior read by the task author, which is a limit of the archive rather than contrary evidence of contamination.

The logger repair and delimiter repair are material to interpreting effort, but do not invalidate these outcome comparisons. Both matrix arms have the same initial alias behavior and real NumPy/SciPy versions. The candidate's optional Markdown parser failure remains visible and is not attributed to the skill. Observation main's first eight operations use standard-library work under logger v1; its dependency-sensitive verification uses v2, as does candidate throughout. Both later use the same restored dependency environment. The distinct outer heredoc marker is applied equally to the unstarted 03–06 pairs. None of these repairs alters a game task, acceptance criterion, or product source.

Recorded native metadata exposes 21 enabled local skills and the same 18 ambient skills in both matrix workspaces, with no skill-load errors. The CLI invocation records and empty model-event streams establish a pre-turn execution failure, not bad task performance. The native retry is also retained. Metadata discovery and an explicit instruction to discover/read the local source are different invocation routes. This experiment demonstrates the latter's actual task behavior; native installed-client automatic selection and native model quality remain unverified.

The trace boundary is correctly disclosed. Commands and critical executable paths show local task/source/library use, not reading evaluator keys, other task workspaces, credentials or outside source repositories. The context scan found no foreign workspace literal path. There is no observed global installation, messaging, publication, or game-engine mutation. Candidate observation creates the disclosed local Python bytecode cache. Final byte equality cannot rule out transient edits, and an instructional shared-filesystem boundary plus subprocess logger cannot rule out an unlogged outer command or inaccessible conversation event. The matrix delimiter incident is retained as an example of this limit.

These records support no full-cost or speed ranking. Counts are 11/11, 9/9, 14/14, 8/10, 7/7 and 5/7 logged operations across the six pairs; batching and setup pauses make them unsuitable proxies for model labor or quality. One run per condition, purposive task selection, non-blinded grading and unavailable effective-model/billing receipts preclude a general effect estimate. No post-hoc fresh subject replacement is present in the retained run index, and no new model rerun was performed for this audit.

## Reporting, preservation and next decision

The report accurately keeps four distinct observations separate: native operations were exercised; both arms delivered strong usable outcomes; candidate retained the added importer context and avoided one observed compiler setup error; the main historical no-help sentence needs a qualifier. It does not transform these into a general causal skill improvement. Its correction history retains the original observation judgment, arithmetic calibration and erroneous initial `--report` description. All result artifact hashes reconcile with the actual delivered files.

The raw evidence includes complete runtime skill text and portions of third-party library documentation/code in command output and compiler error captures. It should remain described as source-containing evidence. Archive redistribution/provenance handling belongs to the publication owner; this audit does not certify that package's licensing completeness or authorize distribution. Preservation must retain the failed attempts and adverse result rather than clean them into a uniformly successful story.

No new experiment/report defect requiring correction was found. The evidence is sufficient for the diagnostic claim being made, so another unchanged subject run is unnecessary. A future stronger claim should target a newly identified risk or the missing native model-selection route, with a new appropriately frozen measurement. The current tasks remain diagnostic/regression evidence if their feedback informs later changes.

### Review receipts

- [checks.json](checks.json): source, input, config and trace identity; exact matrix algebra; glTF preservation; word counts.
- [context-and-provenance-checks.json](context-and-provenance-checks.json): all raw observation notes and session rows, actual importer context, native catalog equality and path-inventory limits.
- [native-artifact-replay.json](native-artifact-replay.json): independent source compilation, native save/restore/continuation and glTF resource validation on the final artifact identities.
- [file-hash-scope.json](file-hash-scope.json): exact frozen per-file review scope, with declared exclusions.
- [final-drift-check.json](final-drift-check.json): reconciliation of the final experiment manifest and unchanged reviewed subject.
- [verify_frozen_evidence.py](verify_frozen_evidence.py) and [replay_native_artifacts.cjs](replay_native_artifacts.cjs): reproducible independent checks; writes remain confined to this review directory.
