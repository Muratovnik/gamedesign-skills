'use strict';
// Independent native replay. It reads frozen delivered artifacts and writes only
// the review receipt. It never invokes a model or the candidate adapters.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const base = path.resolve(__dirname, '../behavior-comparison');
const modules = path.join(base, 'shared/node_modules');
const { Compiler, Story } = require(path.join(modules, 'inkjs/dist/ink-full.js'));
const { CompilerOptions } = require(path.join(modules, 'inkjs/compiler/CompilerOptions.js'));
const validator = require(path.join(modules, 'gltf-validator'));
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const read = p => fs.readFileSync(p, 'utf8');
const parse = p => JSON.parse(read(p));
const receipt = { checked_at_utc: new Date().toISOString(), node: process.version,
  inkjs: parse(path.join(modules,'inkjs/package.json')).version,
  validator: validator.version(), ink: {}, gltf: {} };

function advance(story) {
  let text = '';
  let steps = 0;
  while (story.canContinue) {
    assert.ok(++steps < 1000);
    text += story.Continue();
  }
  assert.ok(!story.hasError);
  return text;
}
function choices(story) { return story.currentChoices.map(c => c.text); }
function choose(story, pattern) {
  const c = story.currentChoices.filter(x => pattern.test(x.text));
  assert.equal(c.length,1);
  story.ChooseChoiceIndex(c[0].index);
}
function vars(story, token) {
  return { token: story.variablesState[token], given: story.variablesState.token_given,
    permit: story.variablesState.has_permit, action: story.variablesState.chair_action };
}
for (const arm of ['a','b']) {
  const out = path.join(base,'workspaces',`03-${arm}`,'out');
  const sourcePath = path.join(out,'north-quay.ink');
  const compiledPath = path.join(out,arm === 'a' ? 'north-quay.story.json' : 'compiled/story.json');
  const savePath = path.join(out,arm === 'a' ? 'north-quay.save.json' : 'paid-save/state.json');
  const source = read(sourcePath), compiled = read(compiledPath);
  const compiler = new Compiler(source, new CompilerOptions(null, [], arm === 'a'));
  const newlyCompiled = compiler.Compile().ToJson();
  assert.deepEqual(compiler.errors,[]);
  assert.deepEqual(JSON.parse(newlyCompiled),JSON.parse(compiled));
  const token = arm === 'a' ? 'brass_tokens' : 'token_count';
  const rawSave = arm === 'a' ? read(savePath) : parse(savePath).native_state_json;
  if (arm === 'b') {
    assert.equal(hash(rawSave),parse(savePath).native_state_sha256);
    assert.equal(hash(compiled),parse(savePath).compiled_sha256);
    assert.equal(rawSave,read(path.join(out,'paid-save/native-state.json')));
  }
  const freshPayment = new Story(compiled);
  const entryText = advance(freshPayment);
  assert.equal(vars(freshPayment,token).token,1);
  assert.equal(vars(freshPayment,token).permit,false);
  choose(freshPayment,/^Hand over/);
  const paymentText = advance(freshPayment);
  const paidVars=vars(freshPayment,token), paidChoices=choices(freshPayment);
  assert.equal(paidVars.token,0); assert.equal(paidVars.given,true); assert.equal(paidVars.permit,true);
  assert.equal(paidChoices.length,2);
  assert.ok(paidChoices.some(x=>/^Ask/.test(x)) && paidChoices.some(x=>/^Leave quietly/.test(x)));
  const resumed = new Story(compiled);
  assert.notEqual(resumed,freshPayment);
  assert.equal(vars(resumed,token).token,1);
  resumed.state.LoadJson(rawSave);
  assert.equal(resumed.canContinue,false);
  assert.deepEqual(vars(resumed,token),paidVars);
  assert.deepEqual(choices(resumed),paidChoices);
  choose(resumed,/^Ask/);
  const askText=advance(resumed);
  assert.deepEqual(vars(resumed,token),{...paidVars,action:'asked'});
  assert.equal(resumed.canContinue,false); assert.deepEqual(choices(resumed),[]);
  assert.ok(/ferry/i.test(askText) && /permit/i.test(askText));
  assert.ok(!askText.includes(paymentText.trim()));
  assert.ok(!askText.includes('One brass token for'));
  const keep=new Story(compiled); advance(keep); choose(keep,/^Keep/);
  const keepText=advance(keep), keepVars=vars(keep,token);
  assert.equal(keepVars.token,1);assert.equal(keepVars.given,false);assert.equal(keepVars.permit,false);
  assert.equal(keep.canContinue,false);assert.deepEqual(choices(keep),[]);
  assert.ok(/without a permit|no permit/i.test(keepText));
  const quiet=new Story(compiled);quiet.state.LoadJson(rawSave);choose(quiet,/^Leave quietly/);
  const quietText=advance(quiet);
  assert.deepEqual(vars(quiet,token),{...paidVars,action:'quiet'});
  assert.ok(/ferry/i.test(quietText) && /nod|silence/i.test(quietText));
  receipt.ink[arm]={source_path:sourcePath,source_sha256:hash(source),compiled_path:compiledPath,
    compiled_sha256:hash(compiled),recompiled_same_native_json:true,save_path:savePath,
    save_file_sha256:hash(fs.readFileSync(savePath)),native_save_sha256:hash(rawSave),
    pending_choices:paidChoices,saved_and_restored_variables:paidVars,
    independent_fresh_runtime_load:true,ask_result:vars(resumed,token),ask_transcript:askText,
    keep_result:keepVars,keep_transcript:keepText,quiet_result:vars(quiet,token),quiet_transcript:quietText,
    input_story_format:JSON.parse(compiled).inkVersion,input_save_format:JSON.parse(rawSave).inkSaveVersion,
    status:'passed'};
}

(async()=>{
  for (const [label,asset] of [
    ['original',path.join(base,'packets/04_gltf/moorlight-marker.gltf')],
    ['main',path.join(base,'workspaces/04-a/out/moorlight-marker.gltf')],
    ['candidate',path.join(base,'workspaces/04-b/out/moorlight-marker.gltf')],
  ]) {
    const data=fs.readFileSync(asset), resources=[];
    const report=await validator.validateBytes(new Uint8Array(data),{
      uri:path.basename(asset),format:'gltf',maxIssues:0,writeTimestamp:false,
      externalResourceFunction:async uri=>{
        const f=path.resolve(path.dirname(asset),decodeURIComponent(uri));
        const bytes=fs.readFileSync(f);
        resources.push({uri,path:f,bytes:bytes.length,sha256:hash(bytes)});
        return new Uint8Array(bytes);
      },
    });
    assert.equal(resources.length,1);assert.equal(resources[0].bytes,42);
    assert.equal(report.issues.numErrors,label==='original'?1:0);
    if(label==='original') assert.equal(report.issues.messages[0].code,'ACCESSOR_TOO_LONG');
    else {
      assert.equal(report.issues.numWarnings,0);assert.equal(report.info.totalVertexCount,3);
      assert.equal(report.info.totalTriangleCount,1);
    }
    receipt.gltf[label]={path:asset,sha256:hash(data),resources,report,status:'passed'};
  }
  fs.writeFileSync(path.join(__dirname,'native-artifact-replay.json'),JSON.stringify(receipt,null,2)+'\n');
  console.log(JSON.stringify({ink:Object.fromEntries(Object.entries(receipt.ink).map(([k,v])=>[k,{status:v.status,source:v.source_sha256,compiled:v.compiled_sha256,native_save:v.native_save_sha256}])),gltf:Object.fromEntries(Object.entries(receipt.gltf).map(([k,v])=>[k,{status:v.status,errors:v.report.issues.numErrors,resource_reads:v.resources.length}]))},null,2));
})().catch(error=>{console.error(error);process.exitCode=1;});
