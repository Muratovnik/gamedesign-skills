"""Read-only independent checks of the frozen diagnostic comparison.

Writes only this review's receipts, never subject workspaces or product source.
No subject model is rerun. Native artifact replay is performed separately.
"""
from pathlib import Path
from fractions import Fraction as F
import csv
import datetime
import hashlib
import json
import re
import subprocess

HERE = Path(__file__).resolve().parent
BASE = HERE.parent / "behavior-comparison"
WORK = BASE / "workspaces"

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

checks = {}
v1 = load(BASE / "task-rubric-freeze.json")
v2 = load(BASE / "task-rubric-freeze-v2.json")
checks["task_freeze_v2"] = {p: digest(BASE / p) == h for p, h in v2["files"].items()}
checks["historical_rubric_v1_preserved"] = digest(BASE / "evaluator/history/rubrics-v1.md") == v1["files"]["evaluator/rubrics.md"]
checks["original_freeze_preserved"] = digest(BASE / "task-rubric-freeze.json") == v2["prior_manifest_sha256"]
checks["task_bytes_unchanged_between_measurements"] = {
    p: h == v1["files"][p] for p, h in v2["files"].items() if p.startswith("packets/")
}
checks["rubric_change_only_counts"] = (BASE / "evaluator/history/rubrics-v1.md").read_text().replace("10 clears and 4 hits", "11 clears and 3 hits") == (BASE / "evaluator/rubrics.md").read_text()

manifests = {arm: load(BASE / "sources" / arm / "manifest.json") for arm in ("main", "candidate", "assay")}
source_freeze = load(BASE / "source-freeze.json")
checks["frozen_sources"] = {}
for arm, m in manifests.items():
    checks["frozen_sources"][arm] = {
        "manifest_hash_matches": digest(BASE / "sources" / arm / "manifest.json") == source_freeze[arm]["manifest_sha256"],
        "included_file_count": len(m["copied_skill_files"]),
        "mismatches": [p for p,h in m["copied_skill_files"].items() if digest(BASE / "sources" / arm / "skills" / p) != h],
    }

checks["git_runtime_identity"] = {}
repo = HERE.parents[1] / "gamedesign-skills"
for arm, commit in (("main", "a0db5af71146586cf861881670c991ad94d87e2b"), ("candidate", "1873993a6491b52fe8288c19837600a012e18d4d")):
    mismatch = []
    for p, h in manifests[arm]["copied_skill_files"].items():
        result = subprocess.run(["git", "-C", str(repo), "show", f"{commit}:skills/{p}"], capture_output=True)
        if result.returncode or hashlib.sha256(result.stdout).hexdigest() != h:
            mismatch.append({"path": p, "exit_code": result.returncode})
    checks["git_runtime_identity"][arm] = {"commit": commit, "file_count": len(manifests[arm]["copied_skill_files"]), "mismatches": mismatch}

checks["node_dependency_identity"] = {
    "file_count": len(source_freeze["dependencies"]["node_modules"]),
    "mismatches": [p for p,h in source_freeze["dependencies"]["node_modules"].items() if digest(BASE / "shared/node_modules" / p) != h],
}

runs = load(BASE / "model-runs/run-index.json")
checks["runs"] = []
for entry in runs:
    w = WORK / entry["run_id"]
    packet = BASE / "packets" / entry["family"]
    expected = {p:h for p,h in manifests["assay"]["copied_skill_files"].items() if len(Path(p).parts) > 1}
    expected.update(manifests[entry["arm"]]["copied_skill_files"])
    actual = {str(p.relative_to(w / ".agents/skills")): digest(p) for p in (w / ".agents/skills").rglob("*") if p.is_file() and "__pycache__" not in p.parts}
    trace = [json.loads(line) for line in (w / ".trace/operations.jsonl").read_text().splitlines()]
    checks["runs"].append({
        "run_id": entry["run_id"], "arm": entry["arm"],
        "requested_model": entry["requested_model"], "requested_effort": entry["requested_reasoning_effort"],
        "fresh_context_declared": entry["fork_turns"] == "none",
        "launch_evidence_limit": entry["launch_metadata_source"],
        "task_input_identity": {p.name: digest(p) == digest(w / ("TASK.md" if p.name == "task.md" else p.name)) for p in packet.iterdir() if p.is_file()},
        "context_identity": {p: digest(w / p) == h for p,h in entry["common_context"].items()},
        "runtime_skill_file_count": len(actual),
        "runtime_mismatches": [p for p,h in expected.items() if actual.get(p) != h],
        "runtime_extra_files": sorted(set(actual) - set(expected)),
        "eval_paths_present": [p for p in actual if "evals" in Path(p).parts],
        "trace_identity": digest(w / ".trace/operations.jsonl") == entry["trace_sha256"],
        "operation_count": len(trace), "recorded_operation_count_matches": len(trace) == entry["operation_count"],
        "all_command_hashes_match": all(hashlib.sha256(r["stdin_script"].encode()).hexdigest() == r["stdin_sha256"] for r in trace),
        "all_cwd_match": all(r["cwd"] == str(w) for r in trace),
        "all_declared_node_paths_match": all(r["environment_overrides"]["NODE_PATH"] == str(w / ".runtime/node_modules") for r in trace),
        "logger_hashes_match_index": [r["logger_sha256"] for r in trace] == entry["logger_hashes_by_operation"],
        "logger_versions": sorted(set(r["logger_sha256"] for r in trace)),
        "sum_logged_subprocess_seconds": sum(r["wall_seconds"] for r in trace),
        "nonzero_operation_indices": [n for n,r in enumerate(trace,1) if r["exit_code"]],
        "stderr_operation_indices": [n for n,r in enumerate(trace,1) if r["stderr"]],
    })

def solve_exact(a, transpose=False):
    if transpose:
        a = [list(x) for x in zip(*a)]
    equations = [[F(a[i][j] - a[2][j]) for j in range(3)] + [F(0)] for i in range(2)]
    equations.append([F(1),F(1),F(1),F(1)])
    determinant = F(1)
    for col in range(3):
        p = next(i for i in range(col,3) if equations[i][col])
        if p != col:
            equations[p], equations[col] = equations[col], equations[p]
            determinant *= -1
        pivot = equations[col][col]
        determinant *= pivot
        equations[col] = [x / pivot for x in equations[col]]
        for i in range(3):
            if i != col:
                c = equations[i][col]
                equations[i] = [x - c*y for x,y in zip(equations[i], equations[col])]
    return [equations[i][3] for i in range(3)], determinant

rows = list(csv.reader((BASE / "packets/01_matrix/payoffs.csv").open()))
a0 = [[int(x) for x in r[1:]] for r in rows[1:]]
a1 = [r[:] for r in a0]
a1[2][0] = 2
checks["independent_exact_math"] = {}
for name,a in (("current",a0),("patch",a1)):
    p,det_p = solve_exact(a,True)
    q,det_q = solve_exact(a,False)
    row = [sum(a[i][j]*q[j] for j in range(3)) for i in range(3)]
    col = [sum(p[i]*a[i][j] for i in range(3)) for j in range(3)]
    assert sum(p) == sum(q) == 1 and min(p+q) > 0 and min(col) == max(row)
    checks["independent_exact_math"][name] = {
        "attacker": list(map(str,p)), "defender": list(map(str,q)),
        "attacker_payoffs_by_row": list(map(str,row)), "attacker_payoffs_by_column": list(map(str,col)),
        "value": str(min(col)), "saddle_gap": str(max(row)-min(col)),
        "attacker_equalization_determinant": str(det_p), "defender_equalization_determinant": str(det_q),
    }
checks["independent_exact_math"]["value_increase"] = str(F(checks["independent_exact_math"]["patch"]["value"]) - F(checks["independent_exact_math"]["current"]["value"]))

checks["gltf_artifact_preservation"] = {}
for arm in ("a","b"):
    w=WORK/f"04-{arm}"
    original=(w/"moorlight-marker.gltf").read_bytes()
    corrected=(w/"out/moorlight-marker.gltf").read_bytes()
    expected=load(w/"moorlight-marker.gltf")
    expected["accessors"][0]["count"] = 3
    checks["gltf_artifact_preservation"][arm] = {
        "only_one_byte_changed": len(original)==len(corrected) and sum(x!=y for x,y in zip(original,corrected))==1,
        "only_accessor_count_changed": expected == load(w/"out/moorlight-marker.gltf"),
        "buffer_unchanged": (w/"moorlight-marker.bin").read_bytes() == (w/"out/moorlight-marker.bin").read_bytes(),
        "asset_sha256": digest(w/"out/moorlight-marker.gltf"),
        "buffer_sha256": digest(w/"out/moorlight-marker.bin"),
    }
checks["paper_and_scene_word_counts"] = {
    k: len(re.findall(r"\b[\w]+(?:['’—-][\w]+)*\b", (WORK/k/"out"/("rule-card.md" if k.startswith("05") else "scene.md")).read_text()))
    for k in ("05-a","05-b","06-a","06-b")
}

scope={}
for p in BASE.rglob("*"):
    if not p.is_file() or "__pycache__" in p.parts:
        continue
    rel=p.relative_to(BASE)
    if rel.parts[0]=="shared":
        continue
    if ".runtime" in rel.parts and p.name != "log-command.py":
        continue
    scope[str(p)]={"sha256":digest(p),"bytes":p.stat().st_size}
for k in ("gltf-validator/package.json","gltf-validator/index.js","gltf-validator/gltf_validator.dart.js","inkjs/package.json","inkjs/dist/ink-full.js"):
    p=BASE/"shared/node_modules"/k
    scope[str(p)]={"sha256":digest(p),"bytes":p.stat().st_size}
timestamp=datetime.datetime.now(datetime.timezone.utc).isoformat()
(HERE/"checks.json").write_text(json.dumps({"checked_at_utc":timestamp,"checks":checks},indent=2)+"\n")
(HERE/"file-hash-scope.json").write_text(json.dumps({
    "captured_at_utc":timestamp,
    "scope":"Frozen experiment packets, rubrics and histories, configs, sources, model-run records, raw operation traces, all delivered artifacts and subject runtime skill files; selected dependency entrypoints. Hash inventory is not a claim that every runtime method was substantively audited.",
    "exclusions":"Shared dependency tree is checked separately against source-freeze; Python site-packages, cache files, and runtime symlink payloads excluded from this per-file inventory.",
    "files":scope},indent=2)+"\n")
print(json.dumps({"receipt":str(HERE/"checks.json"),"hash_scope":str(HERE/"file-hash-scope.json"),"hashed_files":len(scope),"checks":checks},indent=2))
