"""Original research probe; scipy.optimize owns numerical optimization.
Not a product API. Inputs below are synthetic, explicit zero-sum utilities.
"""
import json
from pathlib import Path
import numpy as np
import scipy
from scipy.optimize import linprog

def solve(a):
    a=np.asarray(a,dtype=float)
    m,n=a.shape
    row=linprog(np.r_[np.zeros(m),-1.], A_ub=np.column_stack([-a.T,np.ones(n)]),b_ub=np.zeros(n),A_eq=[np.r_[np.ones(m),0.]],b_eq=[1.],bounds=[(0,None)]*m+[(None,None)],method='highs')
    col=linprog(np.r_[np.zeros(n),1.], A_ub=np.column_stack([a,-np.ones(m)]),b_ub=np.zeros(m),A_eq=[np.r_[np.ones(n),0.]],b_eq=[1.],bounds=[(0,None)]*n+[(None,None)],method='highs')
    if not row.success or not col.success:
        return {'status':'solver_failed','row_status':row.status,'column_status':col.status}
    p,q=row.x[:-1],col.x[:-1]
    low=float(np.min(p@a)); high=float(np.max(a@q))
    return {'row':p.tolist(),'column':q.tolist(),'row_value':float(row.x[-1]),'column_value':float(col.x[-1]),'guaranteed_lower':low,'best_response_upper':high,'certificate_gap':high-low,'row_sum':float(p.sum()),'column_sum':float(q.sum())}

base=np.array([[0,-1,2],[1,0,-3],[-2,3,0]])
cases={'unequal_stakes_cycle':base,'constant_shift_same_preferences':base+5,'negative_value':[[-3,-5]],'asymmetric_actions':[[1,-1,0],[-1,1,0]],'intentional_dominance':[[2,2],[1,0]]}
result={'scipy':scipy.__version__,'numpy':np.__version__,'results':{name:{'matrix':np.asarray(a).tolist(),'result':solve(a)} for name,a in cases.items()},'boundary':'Formal minimax of stated zero-sum utilities; no claim of player rates, learned behavior, fun, perceptual or cultural effects.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
