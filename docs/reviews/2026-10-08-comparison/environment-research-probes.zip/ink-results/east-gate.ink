VAR has_pass = false
VAR entered = false
-> gate
=== gate ===
The east gate is closed.
* {not has_pass} [Inspect the ledger]
    ~ has_pass = true
    You find your permit.
    -> gate
* {has_pass} [Enter the east gate]
    ~ entered = true
    -> yard
+ [Leave freely]
    -> ending
=== yard ===
You cross the gate.
-> END
=== ending ===
You leave for the shore.
-> END
