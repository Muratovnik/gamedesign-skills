VAR has_pass =
-> END