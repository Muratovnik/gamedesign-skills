// Original, isolated feasibility probe. It invokes the actual Khronos component.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const validator = require('gltf-validator');
const out = path.join(__dirname, 'gltf-results');
fs.mkdirSync(out, { recursive: true });
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
const positions = Buffer.alloc(36);
[0, 0, 0, 1, 0, 0, 0, 1, 0].forEach((v, i) => positions.writeFloatLE(v, i * 4));
const triangle = {
  asset: { version: '2.0', generator: 'Original Game Design research probe' },
  scene: 0, scenes: [{ nodes: [0] }], nodes: [{ name: 'EastGateMarker', mesh: 0 }],
  meshes: [{ primitives: [{ attributes: { POSITION: 0 } }] }],
  buffers: [{ byteLength: 36 }],
  bufferViews: [{ buffer: 0, byteOffset: 0, byteLength: 36, target: 34962 }],
  accessors: [{ bufferView: 0, componentType: 5126, count: 3, type: 'VEC3',
    min: [0, 0, 0], max: [1, 1, 0] }],
};
function makeGlb(json) {
  const j = Buffer.from(JSON.stringify(json));
  const padded = Buffer.concat([j, Buffer.alloc((4 - j.length % 4) % 4, 0x20)]);
  const b = Buffer.alloc(12 + 8 + padded.length + 8 + positions.length);
  b.writeUInt32LE(0x46546c67, 0); b.writeUInt32LE(2, 4); b.writeUInt32LE(b.length, 8);
  b.writeUInt32LE(padded.length, 12); b.writeUInt32LE(0x4e4f534a, 16); padded.copy(b, 20);
  const offset = 20 + padded.length;
  b.writeUInt32LE(positions.length, offset); b.writeUInt32LE(0x004e4942, offset + 4);
  positions.copy(b, offset + 8);
  return b;
}
const embedded = structuredClone(triangle);
embedded.buffers[0].uri = 'data:application/octet-stream;base64,' + positions.toString('base64');
const broken = structuredClone(triangle); broken.accessors[0].count = 4;
const missing = structuredClone(triangle); missing.buffers[0].uri = 'missing.bin';
const remote = structuredClone(triangle); remote.buffers[0].uri = 'https://example.invalid/positions.bin';
const cases = [
  ['valid-triangle.gltf', Buffer.from(JSON.stringify(embedded)), 'supported'],
  ['valid-triangle.glb', makeGlb(triangle), 'supported'],
  ['invalid-accessor.glb', makeGlb(broken), 'refuted'],
  ['empty.gltf', Buffer.from(JSON.stringify({ asset: { version: '2.0' } })), 'refuted'],
  ['missing-buffer.gltf', Buffer.from(JSON.stringify(missing)), 'unavailable'],
  ['remote-resource.gltf', Buffer.from(JSON.stringify(remote)), 'unavailable'],
];
(async () => {
  const summaries = [];
  for (const [name, bytes, expected] of cases) {
    const filename = path.join(out, name);
    fs.writeFileSync(filename, bytes);
    const reopened = fs.readFileSync(filename);
    const resourceFailures = [];
    const report = await validator.validateBytes(new Uint8Array(reopened), {
      uri: name, writeTimestamp: false, maxIssues: 0,
      externalResourceFunction: async uri => {
        // No network or uncontrolled reads. A missing dependency is unavailable evidence.
        if (/^[a-z][a-z0-9+.-]*:/i.test(uri)) {
          resourceFailures.push({ uri, reason: 'remote_resource_not_authorized' });
          throw new Error('Only local resources within the fixture directory are allowed');
        }
        const resource = path.resolve(out, decodeURIComponent(uri));
        if (!resource.startsWith(out + path.sep)) {
          resourceFailures.push({ uri, reason: 'outside_fixture_directory' });
          throw new Error('Resource path is outside the fixture directory');
        }
        try { return new Uint8Array(fs.readFileSync(resource)); }
        catch (e) { resourceFailures.push({ uri, reason: e.code }); throw e; }
      },
    });
    const nonemptyTriangleMesh = report.info?.totalTriangleCount > 0 && report.info?.totalVertexCount > 0;
    const outcome = resourceFailures.length ? 'unavailable'
      : report.issues.numErrors > 0 || !nonemptyTriangleMesh ? 'refuted' : 'supported';
    const receipt = {
      schema: 'environment-research-gltf-probe/1', node: process.version,
      component: { name: 'gltf-validator', version: validator.version(),
        npmGitHead: 'bcd52cc4ba5f333b2999a58f67cc05ddf28b4fb1' },
      artifact: { name, sha256: digest(reopened), bytes: reopened.length },
      claim: 'Khronos glTF conformance with a nonempty triangle mesh for this fixture',
      outcome, nonemptyTriangleMesh, resourceFailures, validatorReport: report,
      limitations: ['No target-engine import or re-export', 'No visual or perceptual observation',
        'No project-specific triangle, texture, scale or collision budget',
        'Empty glTF is legal format content; it fails only this mesh-delivery claim'],
    };
    fs.writeFileSync(path.join(out, name + '.receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
    assert.equal(outcome, expected, name);
    summaries.push({ name, outcome, errors: report.issues.numErrors,
      triangles: report.info?.totalTriangleCount ?? null,
      issueCodes: report.issues.messages.map(m => m.code) });
  }
  fs.writeFileSync(path.join(out, 'summary.json'), JSON.stringify(summaries, null, 2) + '\n');
  console.log(JSON.stringify(summaries, null, 2));
})().catch(e => { console.error(e); process.exitCode = 1; });
