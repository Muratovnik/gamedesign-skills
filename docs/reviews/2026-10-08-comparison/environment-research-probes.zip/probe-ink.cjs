// Original, isolated feasibility probe. Compilation and execution use actual inkjs.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { Compiler, Story } = require('inkjs/full');
const out = path.join(__dirname, 'ink-results');
fs.mkdirSync(out, { recursive: true });
const digest = b => crypto.createHash('sha256').update(b).digest('hex');
const source = `VAR has_pass = false
VAR entered = false
-> gate
=== gate ===
The east gate is closed.
* {not has_pass} [Inspect the ledger]
    ~ has_pass = true
    You find your permit.
    -> gate
* {has_pass} [Enter the east gate]
    ~ entered = true
    -> yard
+ [Leave freely]
    -> ending
=== yard ===
You cross the gate.
-> END
=== ending ===
You leave for the shore.
-> END
`;
function observe(story) {
  const text = [];
  for (let step = 0; story.canContinue; step++) {
    if (step >= 100) throw new Error('Continuation budget exhausted');
    text.push(story.Continue());
  }
  return { text, choices: story.currentChoices.map(c => c.text),
    variables: { has_pass: story.variablesState.has_pass, entered: story.variablesState.entered },
    terminal: !story.canContinue && story.currentChoices.length === 0 };
}
function choose(story, label) {
  const matches = story.currentChoices.filter(c => c.text === label);
  if (matches.length !== 1) throw new Error('Expected exactly one choice: ' + label);
  story.ChooseChoiceIndex(matches[0].index);
  return observe(story);
}
function compile(name, text) {
  fs.writeFileSync(path.join(out, name + '.ink'), text);
  const reopened = fs.readFileSync(path.join(out, name + '.ink'), 'utf8');
  const compiler = new Compiler(reopened);
  const compiled = compiler.Compile().ToJson();
  fs.writeFileSync(path.join(out, name + '.json'), compiled);
  return { sourceSha256: digest(reopened), compiledSha256: digest(compiled),
    json: fs.readFileSync(path.join(out, name + '.json'), 'utf8'),
    diagnostics: { errors: compiler.errors, warnings: compiler.warnings } };
}
const compiled = compile('east-gate', source);
const story = new Story(compiled.json);
const initial = observe(story);
assert(!initial.choices.includes('Enter the east gate'));
assert(initial.choices.includes('Leave freely'));
const afterLedger = choose(story, 'Inspect the ledger');
assert(afterLedger.choices.includes('Enter the east gate'));
assert.equal(afterLedger.variables.has_pass, true);
const save = { compiledSha256: compiled.compiledSha256, state: story.state.ToJson() };
fs.writeFileSync(path.join(out, 'east-gate.save.json'), JSON.stringify(save, null, 2));
const saved = JSON.parse(fs.readFileSync(path.join(out, 'east-gate.save.json'), 'utf8'));
assert.equal(saved.compiledSha256, digest(compiled.json));
const resumed = new Story(compiled.json);
resumed.state.LoadJson(saved.state);
const restored = observe(resumed);
assert.deepEqual(restored.choices, afterLedger.choices);
assert.deepEqual(restored.variables, afterLedger.variables);
const entered = choose(resumed, 'Enter the east gate');
assert.equal(entered.variables.entered, true);
assert(entered.text.join('').includes('You cross the gate.'));
assert(entered.terminal);
const departing = new Story(compiled.json);
observe(departing);
const leave = choose(departing, 'Leave freely');
assert(leave.terminal && !leave.variables.entered && !leave.variables.has_pass);
const defect = compile('gate-without-condition', source.replace('* {has_pass} [Enter', '* [Enter'));
const badInitial = observe(new Story(defect.json));
assert(badInitial.choices.includes('Enter the east gate'));
let invalidSourceRejected = false;
try { compile('invalid-source', 'VAR has_pass =\n-> END'); }
catch { invalidSourceRejected = true; }
assert(invalidSourceRejected);
const empty = compile('empty', '-> END');
const emptyObservation = observe(new Story(empty.json));
assert(emptyObservation.terminal && emptyObservation.text.join('').trim().length === 0);
const staleSaveRejected = saved.compiledSha256 !== defect.compiledSha256;
assert(staleSaveRejected);
const receipt = {
  schema: 'environment-research-ink-probe/1', node: process.version,
  component: { name: 'inkjs', version: '2.4.0', npmGitHead: 'edccead8700e9f21be9825d87d8645d8c82a9936',
    compiledInkFormat: JSON.parse(compiled.json).inkVersion },
  artifact: { sourceSha256: compiled.sourceSha256, compiledSha256: compiled.compiledSha256 },
  claim: 'Gate condition changes legal choices; save/reload preserves those choices and variables; departure stays possible',
  outcome: 'supported',
  trace: { initial, afterLedger, restored, entered, legitimateDeparture: leave },
  controls: { conditionRemoved: { outcome: 'refuted', observation: badInitial },
    invalidSource: { outcome: 'unavailable', compilerRejected: invalidSourceRejected },
    emptyNarrative: { outcome: 'refuted', reason: 'No player action or narrative relation executed', observation: emptyObservation },
    staleSave: { outcome: 'unavailable', rejectedByCompiledDigest: staleSaveRejected } },
  diagnostics: compiled.diagnostics,
  limitations: ['Single original synthetic story and selected paths', 'No human reading or dramatic-effect evidence',
    'No Unity/Godot integration or UI test', 'No arbitrary save migration',
    'No claim that all ink or inkjs versions are interchangeable',
    'INCLUDE and external functions need explicit project-bound resource/host handling'],
};
fs.writeFileSync(path.join(out, 'receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(JSON.stringify(receipt, null, 2));
