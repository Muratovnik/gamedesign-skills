"""Seal review scope without mutating the reviewed repository."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/e429285ef1e1/gamedesign-skills')
WORK = ROOT.parent
OUT = Path(__file__).resolve().parent
RUNTIME = '1873993a6491b52fe8288c19837600a012e18d4d'
BASE = 'a0db5af71146586cf861881670c991ad94d87e2b'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args]).decode()


def identity(path):
    raw = path.read_bytes()
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


direct = '''AGENTS.md
README.md
NOTICE.md
CHANGELOG.md
LICENSE
catalog.json
relkit.toml
.github/workflows/check.yml
docs/compatibility.md
docs/decisions.md
docs/examples.md
docs/installation.md
docs/late-comparison.md
docs/quickstart.ru.md
docs/traceability.md
docs/releases.md
tools/check.py
tools/package.py
tools/qualify_native_clients.py
tests/test_native_qualification.py
skills/game-design/references/consumer-and-assay-contract.md
skills/game-design/references/gltf-artifacts.md
skills/game-design/scripts/validate_gltf.cjs
skills/game-systems-design/scripts/solve_zero_sum.py
skills/game-systems-design/references/zero-sum-analysis.md
skills/game-world-narrative-design/references/ink-artifacts.md
examples/strategy-matrix/README.md
examples/ink-episode/README.md
examples/gltf-artifacts/README.md
docs/research/2026-10-08/comparison.md
docs/research/2026-10-08/requirements-and-plan.md
docs/research/2026-10-08/domain-landscape.md
docs/research/2026-10-08/environment-components.md
docs/research/2026-10-08/simulation-environments.md
docs/reviews/2026-10-08-comparison/README.md
docs/reviews/2026-10-08-comparison/integration-review.md
docs/reviews/2026-10-08-comparison/numeric-narrative-review.md
docs/reviews/2026-10-08-comparison/model-comparison.md'''.splitlines()
selected = {
    'tools/smoke.py': 'Read relevant packaging and release-consumer sections.',
    'tests/test_distribution.py': 'Read packaging selection tests and final added real-archive regression.',
    'skills/game-design/SKILL.md': 'Read changed routing in base-to-candidate diff and owner context.',
    'skills/game-systems-design/SKILL.md': 'Read changed routing in base-to-candidate diff and owner context.',
    'skills/game-world-narrative-design/SKILL.md': 'Read changed routing in base-to-candidate diff and owner context.',
    'skills/game-design/references/environment-contracts.md': 'Read changed contract and dependent boundary context.',
    'skills/game-design/scripts/observe_evidence.py': 'Read changed propagation and its existing output context.',
    'examples/analysis-lab/test_semantics.py': 'Read changed observation regression and relevant semantic controls.',
}
instruction_names = '''AGENTS.md
skills/independent-audit/SKILL.md
skills/independent-audit/references/repository-and-release.md
skills/independent-audit/references/evidence-and-probes.md
skills/independent-audit/references/solution-choices-and-reuse.md
skills/independent-audit/references/bounded-review.md
skills/skill-evaluation/SKILL.md
skills/skill-evaluation/references/paired-pilot.md
skills/implementation-planning/references/review-and-replan.md
skills/code-change/references/reuse-and-migration.md
skills/evidence-research/references/component-evidence.md
tools/command_receipt.py'''.splitlines()
input_scopes = {
    'upload/game-design-project-brief(3).md': 'Read complete brief, including baseline/comparison and full-scope constraints.',
    'upload/game-design-operational-requirements(5).md': 'Read relevant operational requirements, notably OR-11/15/16; heading and scope cross-check.',
    'upload/game-design-domain-requirements(2).md': 'Read GDE-01/02 and GDE-04 through GDE-09 plus selected design requirements cited by addendum; heading/scope cross-check.',
    'upload/game-design-assay-mapping(2).md': 'Read ownership mapping and relevant responsibility boundaries.',
    'research/baseline/game-design-project-plan.md': 'Normalized recovered plan; read dependent C3/C4 and sections 4.2/4.3, not a byte-identical attachment claim.',
    'research/baseline/requirement-map.md': 'Cross-reference aid, subordinate to supplied requirements.',
    'research/behavior-comparison/prompt-protocol.md': 'Read evaluation route, isolation and limits; no independent grading claim.',
    'research/behavior-comparison/fallback-logging-protocol-v2.md': 'Read bounded alternate operation logging contract.',
    'research/behavior-comparison/log_command.py': 'Read complete experiment-local helper and compare to Assay command receipt.',
}

candidate_names = set(git('ls-files', '-z').rstrip('\0').split('\0'))
for directory in ['docs/research', 'docs/reviews/2026-10-08-comparison']:
    candidate_names.update(p.relative_to(ROOT).as_posix() for p in (ROOT / directory).rglob('*') if p.is_file())
candidate_names.discard('')
snapshot = {name: identity(ROOT / name) for name in sorted(candidate_names) if (ROOT / name).is_file()}
runtime_names = git('ls-tree', '-r', '--name-only', RUNTIME, '--', 'skills').splitlines()
result = {
    'sealed_at_utc': datetime.now(timezone.utc).isoformat(),
    'reviewer': '/root/final_product_review',
    'repository': str(ROOT),
    'branch': git('branch', '--show-current').strip(),
    'working_head': git('rev-parse', 'HEAD').strip(),
    'review_baseline': BASE,
    'qualified_runtime_commit': RUNTIME,
    'qualified_runtime_tree': git('rev-parse', RUNTIME + '^{tree}').strip(),
    'status_at_seal': git('status', '--short').splitlines(),
    'base_to_committed_candidate_diff': git('diff', '--name-status', BASE, RUNTIME).splitlines(),
    'head_to_materialized_tracked_diff': git('diff', '--name-status', 'HEAD').splitlines(),
    'reading_scope_note': 'Direct reading below is a semantic review; the wider snapshot is identity bookkeeping, not a claim that every file was independently audited line by line. Detailed runtime execution reviews were reused only after exact-byte checks in input-verification.json. No later root-added review reports/receipts or final publication are covered by this seal.',
    'directly_read_product_files': {name: identity(ROOT / name) for name in direct},
    'selected_sections_or_diffs': {name: {'reading_scope': scope, **identity(ROOT / name)} for name, scope in selected.items()},
    'assay_instructions_and_reuse_candidate': {name: identity(WORK / 'assay' / name) for name in instruction_names},
    'supplied_inputs_and_experiment_protocols': {name: {'reading_scope': scope, **identity(WORK / name)} for name, scope in input_scopes.items()},
    'runtime_identity_closure': {name: identity(ROOT / name) for name in runtime_names},
    'candidate_source_snapshot': snapshot,
}
(OUT / 'inspected-files.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'sealed_at_utc': result['sealed_at_utc'], 'working_head': result['working_head'],
                  'direct_files': len(direct), 'selected_files': len(selected),
                  'runtime_files': len(runtime_names), 'snapshot_files': len(snapshot)}, indent=2))
