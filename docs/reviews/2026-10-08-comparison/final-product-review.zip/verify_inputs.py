"""Read-only verification of this review's retained inputs and source identities."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/e429285ef1e1/gamedesign-skills')
OUT = Path(__file__).resolve().parent
EVIDENCE = ROOT / 'docs/reviews/2026-10-08-comparison'
RUNTIME = '1873993a6491b52fe8288c19837600a012e18d4d'
BASE = 'a0db5af71146586cf861881670c991ad94d87e2b'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def check(name, value, details=None):
    checks.append({'check': name, 'passed': bool(value), 'details': details})


checks = []
runtime_paths = git('ls-tree', '-r', '--name-only', RUNTIME, '--', 'skills').decode().splitlines()
runtime_drift = [name for name in runtime_paths
                 if not (ROOT / name).is_file()
                 or (ROOT / name).read_bytes() != git('show', f'{RUNTIME}:{name}')]
current_runtime = sorted(path.relative_to(ROOT).as_posix()
                         for path in (ROOT / 'skills').rglob('*') if path.is_file()
                         and not any(part in {'node_modules', '__pycache__'} for part in path.parts))
check('all_59_runtime_files_equal_qualified_candidate',
      len(runtime_paths) == 59 and not runtime_drift and sorted(runtime_paths) == current_runtime,
      {'files': len(runtime_paths), 'drift': runtime_drift})
check('initial_to_updated_main_preserves_runtime_and_examples',
      not git('diff', '--name-only', '4fc654c2cb92989582c30bc048742f2cce7659ba', BASE,
              '--', 'skills', 'examples').strip())

review_sets = {}
for archive, member in [('numeric-narrative-evidence.zip', 'source-identity-final.json'),
                        ('integration-evidence.zip', 'correction-identity.json')]:
    with zipfile.ZipFile(EVIDENCE / archive) as zipped:
        identity = json.loads(zipped.read(member))
    drift = [name for name, item in identity['files'].items()
             if digest((ROOT / name).read_bytes()) != item['sha256']]
    check(f'unchanged_prior_review_scope:{archive}', not drift,
          {'files': len(identity['files']), 'drift': drift})
    review_sets[archive] = identity['files']

archive_results = []
for manifest_path in sorted(EVIDENCE.glob('*-manifest.json')):
    manifest = json.loads(manifest_path.read_text())
    if 'archive' not in manifest or 'files' not in manifest:
        continue
    archive_path = EVIDENCE / manifest['archive']
    expected = manifest['files']
    if isinstance(expected, list):
        expected = {item['path']: item['sha256'] for item in expected}
    with zipfile.ZipFile(archive_path) as zipped:
        actual = {name: digest(zipped.read(name)) for name in zipped.namelist()}
        duplicates = len(zipped.namelist()) != len(actual)
    good = (not duplicates and actual == expected
            and digest(archive_path.read_bytes()) == manifest['archive_sha256'])
    check(f'archive_bytes_and_every_entry:{archive_path.name}', good,
          {'entries': len(actual), 'duplicate_names': duplicates})
    archive_results.append({'archive': archive_path.name, 'entries': len(actual),
                            'sha256': digest(archive_path.read_bytes()), 'passed': good})

with zipfile.ZipFile(EVIDENCE / 'behavior-evidence.zip') as zipped:
    original = json.loads(zipped.read('evidence-manifest.json'))
    original_root = Path('/workspace/scratch/e429285ef1e1/research/behavior-comparison')
    changed = [name for name, sha in original['files'].items()
               if digest(zipped.read(name)) != sha
               or digest((original_root / name).read_bytes()) != sha]
    check('all_235_original_model_evidence_files_unchanged',
          len(original['files']) == 235 and not changed, {'changed': changed})
    license_sources = {
        'COPYING/Assay-MIT.txt': Path('/workspace/scratch/e429285ef1e1/assay/LICENSE'),
        'COPYING/Game-Design-MIT.txt': ROOT / 'LICENSE',
        'COPYING/inkjs-MIT.txt': Path('/workspace/scratch/e429285ef1e1/research/environment/probes/node_modules/inkjs/LICENSE.md'),
        'COPYING/glTF-Validator-Apache-2.0.txt': Path('/workspace/scratch/e429285ef1e1/research/environment/probes/node_modules/gltf-validator/LICENSE'),
        'COPYING/glTF-Validator-NOTICES.txt': Path('/workspace/scratch/e429285ef1e1/research/environment/probes/node_modules/gltf-validator/NOTICES'),
    }
    for name, source in license_sources.items():
        check(f'license_bytes:{name}', zipped.read(name) == source.read_bytes())
    authors = subprocess.check_output(['git', '-C', '/workspace/scratch/e429285ef1e1/research/environment/repos/inkjs',
                                      'show', 'edccead8700e9f21be9825d87d8645d8c82a9936:AUTHORS.md'])
    check('inkjs_authors_at_published_source', zipped.read('COPYING/inkjs-AUTHORS.md') == authors)

receipt = json.loads((EVIDENCE / 'native-lifecycle-qualified.json').read_text())
for stem in ['native-lifecycle-first', 'native-lifecycle-qualified']:
    with zipfile.ZipFile(EVIDENCE / f'{stem}.zip') as zipped:
        names = zipped.namelist()
        receipt_names = [n for n in names if n.endswith('native-client-receipt.json')]
        check(f'native_archive_materialized_receipt:{stem}',
              len(receipt_names) == 1 and zipped.read(receipt_names[0]) == (EVIDENCE / f'{stem}.json').read_bytes(),
              {'members': names})
check('native_receipt_72_completed_commands_24_observations',
      receipt['status'] == 'supported' and not receipt['errors']
      and len(receipt['commands']) == 72 and len(receipt['observations']) == 24
      and all(c['status'] == 'completed' for c in receipt['commands']))
resource_records = [r for r in receipt['observations'] if 'verified_skill_files' in r]
check('eight_resource_actions_synthetic_and_bounded', len(resource_records) == 8 and
      all(r['operation_report']['record_kind'] == 'synthetic'
          and r['operation_report']['human_claim'] == 'not_established'
          for r in resource_records))
for record in resource_records:
    revision = RUNTIME if record['stage'] == 'candidate' else BASE
    actual = record['verified_skill_files']
    names = git('ls-tree', '-r', '--name-only', revision, '--', 'skills').decode().splitlines()
    expected = {name: digest(git('show', f'{revision}:{name}')) for name in names}
    check(f"native_resource_source:{record['client']}:{record['stage']}", actual == expected,
          {'file_count': len(actual)})

merge = json.loads((EVIDENCE / 'ci-runtime-merge-identity.json').read_text())
check('retained_merge_tree_equals_candidate', merge['sha'] == 'a06f5336e5805c0cd84c924ca3aefdc658dc8401'
      and merge['tree']['sha'] == git('rev-parse', f'{RUNTIME}^{{tree}}').decode().strip()
      and merge['parents'] == [BASE, RUNTIME])
expected_suites = [26, 11, 30, 13, 2]
for job in ['113456576647', '113456576901']:
    text = (EVIDENCE / f'ci-runtime-{job}.log').read_text()
    counts = [int(n) for n in re.findall(r'Ran (\d+) tests', text)]
    check(f'base_suite_counts:{job}', counts == expected_suites and merge['sha'] in text, counts)
text = (EVIDENCE / 'ci-runtime-113456576836.log').read_text()
check('optional_suite_counts_18_19_8', re.findall(r'Ran (\d+) tests', text) == ['18']
      and re.findall(r'# tests (\d+)', text) == ['19', '8']
      and re.findall(r'# fail (\d+)', text) == ['0', '0'])
check('127_distinct_tests', sum(expected_suites) + 18 + 19 + 8 == 127)

result = {'scope': 'Read-only source/receipt/archive verification; no runtime suites or native clients rerun',
          'git_root': git('rev-parse', '--show-toplevel').decode().strip(),
          'working_head': git('rev-parse', 'HEAD').decode().strip(),
          'qualified_runtime': RUNTIME, 'base': BASE,
          'status': 'pass' if all(c['passed'] for c in checks) else 'fail',
          'checks': checks, 'archives': archive_results}
(OUT / 'input-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'checks': len(checks),
                  'failed': [c for c in checks if not c['passed']],
                  'archives': archive_results}, indent=2))
