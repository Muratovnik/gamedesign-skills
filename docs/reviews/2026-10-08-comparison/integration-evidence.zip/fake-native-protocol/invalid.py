#!/usr/bin/env python3
import json, sys
MODE='invalid'
print("synthetic protocol diagnostic", file=sys.stderr, flush=True)
for line in sys.stdin:
    request=json.loads(line)
    if request.get("method")=="initialize":
        if MODE=="invalid":
            print("not valid json from synthetic server", flush=True)
        else:
            print(json.dumps({"id":request["id"],"result":{}}), flush=True)
    elif request.get("method")=="skills/list":
        print(json.dumps({"id":request["id"],"result":{"data":[{"cwd":request["params"]["cwds"][0],"skills":[],"errors":[]}]}}), flush=True)
