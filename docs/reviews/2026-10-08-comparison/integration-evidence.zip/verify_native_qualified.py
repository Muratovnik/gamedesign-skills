import csv
import hashlib
import io
import json
import pathlib
import re
import subprocess
import tarfile
import zipfile

ROOT = pathlib.Path('/workspace/scratch/e429285ef1e1')
REPO = ROOT / 'gamedesign-skills'
OUT = ROOT / 'research/review-integration'
BASE = 'a0db5af71146586cf861881670c991ad94d87e2b'
CANDIDATE = '1873993a6491b52fe8288c19837600a012e18d4d'
EXPECTED_TREE = '237e2892adefbf170c149ac644b0c4a18b31ba76'
ZIP = ROOT / 'research/native/native-client-qualified.zip'
RECEIPT = ROOT / 'research/native/native-client-qualified-receipt.json'
EXPECTED_ZIP = 'f78b01ed5ec0bab19c9a7a6b26e678aacbee6027b3d47c4d50f3fe058391a24f'
TARGET = 'game-design@game-design-source'
SENTINEL = 'qualification-sentinel@qualification-sentinel-source'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def archive(commit):
    data = git('archive', commit, 'skills', 'examples/analysis-lab/fixtures')
    with tarfile.open(fileobj=io.BytesIO(data)) as tar:
        return {m.name: tar.extractfile(m).read() for m in tar if m.isfile()}

files = {BASE: archive(BASE), CANDIDATE: archive(CANDIDATE)}
names = {path.split('/')[1] for path in files[CANDIDATE] if re.fullmatch(r'skills/[^/]+/SKILL.md', path)}
checks = {}

def check(name, result):
    checks[name] = bool(result)

receipt_bytes = RECEIPT.read_bytes()
d = json.loads(receipt_bytes)
with zipfile.ZipFile(ZIP) as z:
    check('archive_receipt_equals_materialized_bytes', z.read('native-client-receipt.json') == receipt_bytes)
    lock = json.loads(z.read('native-client-tools/package-lock.json'))
check('archive_sha256_matches_supplied_artifact', sha(ZIP.read_bytes()) == EXPECTED_ZIP)
check('local_head_matches_candidate', git('rev-parse', 'HEAD').decode().strip() == CANDIDATE)
check('candidate_tree_matches_supplied_tree', git('rev-parse', CANDIDATE + '^{tree}').decode().strip() == EXPECTED_TREE)
ident = json.loads((OUT / 'correction-identity.json').read_text())
drift = {p: {'expected': meta['sha256'], 'actual': sha((REPO / p).read_bytes())} for p, meta in ident['files'].items() if sha((REPO / p).read_bytes()) != meta['sha256']}
check('all_twelve_scoped_corrected_file_identities_unchanged', not drift and len(ident['files']) == 12)
check('candidate_verifier_matches_corrected_review', sha(git('show', CANDIDATE + ':tools/qualify_native_clients.py')) == ident['files']['tools/qualify_native_clients.py']['sha256'])
check('receipt_reports_supported_no_errors', d['status'] == 'supported' and d['errors'] == [])
check('all_72_commands_completed', len(d['commands']) == 72 and all(c['status'] == 'completed' for c in d['commands']))
nonzero = [{'index': i, 'argv': c['argv'], 'exit_code': c['exit_code']} for i, c in enumerate(d['commands']) if c['exit_code']]
check('only_expected_absent_claude_details_exit_one', len(nonzero) == 1 and nonzero[0]['index'] == 68 and nonzero[0]['exit_code'] == 1 and nonzero[0]['argv'][1:] == ['plugin', 'details', 'game-design'])
versions = {('codex' if 'codex' in c['argv'][0] else 'claude'): c['stdout'].strip() for c in d['commands'] if c['argv'][-1] == '--version'}
check('pinned_versions_observed', versions == {'codex': 'codex-cli 0.159.2', 'claude': '2.1.289 (Claude Code)'})
check('native_lock_versions_match', lock['packages']['node_modules/@openai/codex']['version'] == '0.159.2' and lock['packages']['node_modules/@anthropic-ai/claude-code']['version'] == '2.1.289')

codex_stages = ['baseline', 'disabled', 'reenabled', 'candidate', 'rollback', 'removed']
codex = []
protocol = [o for o in d['observations'] if o.get('operation') == 'app-server']
skill_lists = [o for o in d['observations'] if o.get('operation') == 'skills/list']
check('six_completed_codex_protocol_processes', len(protocol) == 6 and all(o['status'] == 'completed' and o['exit_code'] == 0 for o in protocol))
for i, (stage, obs) in enumerate(zip(codex_stages, skill_lists)):
    rows = obs['result']['data']
    check(f'codex_{stage}_one_error_free_workspace', len(rows) == 1 and rows[0]['errors'] == [])
    target = [s for s in rows[0]['skills'] if s.get('pluginId') == TARGET]
    sentinel = [s for s in rows[0]['skills'] if s.get('pluginId') == SENTINEL]
    expected = set() if stage in ('disabled', 'removed') else {'game-design:' + n for n in names}
    check(f'codex_{stage}_exact_target_inventory', len(target) == len(expected) and {s['name'] for s in target} == expected and all(s['enabled'] for s in target))
    check(f'codex_{stage}_sentinel_present_enabled', len(sentinel) == 1 and sentinel[0]['enabled'] and sentinel[0]['name'] == 'qualification-sentinel:qualification-sentinel')
    check(f'codex_{stage}_protocol_response_matches_observation', protocol[i]['requests'][1]['method'] == 'skills/list' and protocol[i]['requests'][1]['response']['result'] == obs['result'])
    codex.append({'stage': stage, 'target_names': sorted(s['name'] for s in target), 'sentinel_names': [s['name'] for s in sentinel], 'process_exit': protocol[i]['exit_code']})
check('six_codex_inventory_stages', len(skill_lists) == 6)

native_lists = {}
for client, indices in [('codex', [2, 7, 9, 10, 16, 22, 26, 29]), ('claude', [32, 39, 43, 46, 54, 62, 67, 71])]:
    entries = []
    sentinels = []
    for i, stage in zip(indices, ['empty', *codex_stages, 'empty_after_sentinel_removal']):
        c = d['commands'][i]
        check(f'{client}_{stage}_list_command_identity', c['argv'][1:3] == ['plugin', 'list'])
        listed = json.loads(c['stdout'])
        if client == 'codex':
            listed = listed['installed']
        id_key = 'pluginId' if client == 'codex' else 'id'
        byid = {q[id_key]: q for q in listed}
        if stage.startswith('empty'):
            expected_ids = set()
        elif stage == 'removed':
            expected_ids = {SENTINEL}
        else:
            expected_ids = {TARGET, SENTINEL}
        check(f'{client}_{stage}_exact_registration_inventory', len(byid) == len(listed) and set(byid) == expected_ids)
        if TARGET in byid:
            check(f'{client}_{stage}_enabled_setting', byid[TARGET]['enabled'] == (stage != 'disabled'))
        if SENTINEL in byid:
            check(f'{client}_{stage}_sentinel_enabled', byid[SENTINEL]['enabled'] is True)
            sentinels.append(byid[SENTINEL])
        entries.append({'stage': stage, 'command_index': i, 'target_enabled': byid.get(TARGET, {}).get('enabled'), 'plugin_ids': sorted(byid)})
    check(f'{client}_sentinel_registration_full_record_unchanged', len(sentinels) == 6 and all(s == sentinels[0] for s in sentinels))
    native_lists[client] = entries

claude_details = []
for i, stage in zip([40, 44, 47, 55, 63], codex_stages[:5]):
    c = d['commands'][i]
    matches = re.findall(r'^\s*Skills \((\d+)\)\s+([^\n]+)$', c['stdout'], re.MULTILINE)
    count, raw = matches[0] if len(matches) == 1 else ('-1', '')
    parsed = [x.strip() for x in raw.split(',')]
    check(f'claude_{stage}_exact_details_inventory', c['exit_code'] == 0 and int(count) == len(parsed) == len(names) and set(parsed) == names)
    claude_details.append({'stage': stage, 'command_index': i, 'exit_code': c['exit_code'], 'names': parsed})
check('claude_disabled_details_same_as_baseline', d['commands'][44]['stdout'] == d['commands'][40]['stdout'])

operations = []
for o in d['observations']:
    if 'verified_skill_files' not in o:
        continue
    commit = CANDIDATE if o['stage'] == 'candidate' else BASE
    source = files[commit]
    hashes = {p: sha(b) for p, b in source.items() if p.startswith('skills/') and 'node_modules' not in pathlib.PurePosixPath(p).parts and '__pycache__' not in pathlib.PurePosixPath(p).parts}
    prefix = f'{o["client"]}_{o["stage"]}'
    check(prefix + '_all_recorded_source_files_match_git_revision', o['verified_skill_files'] == hashes)
    report = o['operation_report']
    fixture_root = 'examples/analysis-lab/fixtures/'
    csv_bytes = source[fixture_root + 'observations.csv']
    manifest_bytes = source[fixture_root + 'observation-manifest.json']
    manifest = json.loads(manifest_bytes)
    rows = list(csv.DictReader(io.StringIO(csv_bytes.decode())))
    check(prefix + '_report_preserves_exact_fixture_rows', report['rows'] == rows)
    check(prefix + '_fixture_hashes_match_revision', report['source_sha256'] == {'csv': sha(csv_bytes), 'manifest': sha(manifest_bytes)})
    check(prefix + '_expected_synthetic_claim_and_counts', report['status'] == 'synthetic_format_demonstration' and report['record_kind'] == 'synthetic' and report['human_claim'] == 'not_established' and report['counts'] == {'all': 4, 'known_attempt_outcomes': 2, 'unknown_outcomes': 1, 'unaided_known_attempts': 1, 'unaided_completed': 1})
    if o['stage'] == 'candidate':
        check(prefix + '_all_added_metadata_preserved', all(report[k] == manifest[k] for k in ['conditions', 'collection_method', 'units']))
    else:
        check(prefix + '_baseline_report_shape_restored', all(k not in report for k in ['conditions', 'collection_method', 'units']))
    if o['client'] == 'claude':
        native = next(q for q in d['observations'] if q.get('client') == 'claude' and q.get('stage') == o['stage'] and 'native_plugin' in q)
        check(prefix + '_effective_resource_root_matches_read_from_folder', native['effective_source'] == native['native_plugin']['readFromFolder'] == o['installed_root'])
    operations.append({'client': o['client'], 'stage': o['stage'], 'git_revision': commit, 'files': len(hashes), 'installed_root': o['installed_root'], 'report_status': report['status'], 'human_claim': report['human_claim'], 'exact_fixture_rows': len(rows), 'metadata_fields': [k for k in ['conditions', 'collection_method', 'units'] if k in report]})
check('eight_resource_operations_four_per_client', len(operations) == 8 and all([o['stage'] for o in operations if o['client'] == client] == ['baseline', 'reenabled', 'candidate', 'rollback'] for client in ['codex', 'claude']))

result = {
    'reviewer_verdict': 'PASS' if all(checks.values()) else 'FAIL',
    'artifact_provenance': 'Caller supplied hosted artifact and run IDs; archive identity, local revision and contents independently checked. Reviewer did not rerun native clients or authenticate the GitHub server download.',
    'github_identifiers_supplied_by_caller': {'run': 37819498740, 'native_job': 113456576892, 'artifact': 11568218182},
    'candidate_commit': CANDIDATE, 'candidate_tree': EXPECTED_TREE, 'baseline_commit': BASE,
    'archive_sha256': sha(ZIP.read_bytes()), 'receipt_sha256': sha(receipt_bytes),
    'native_verifier_sha256': ident['files']['tools/qualify_native_clients.py']['sha256'],
    'platform': d['platform'], 'python': d['python'], 'versions': versions,
    'commands': len(d['commands']), 'observations': len(d['observations']), 'nonzero_commands': nonzero,
    'checks': checks, 'failed_checks': [k for k, v in checks.items() if not v], 'scoped_identity_drift': drift,
    'codex_inventory_stages': codex, 'native_registration_stages': native_lists,
    'claude_details_stages': claude_details, 'resource_operations': operations,
    'scope_limits': [
        'Linux disposable-user local-source registration lifecycle on exact pinned client versions only.',
        'Codex skills/list absence supports disabled native inventory; Claude merged enabled setting false and details inventory do not establish model-session deactivation.',
        'Candidate replacement and rollback are uninstall/marketplace-replace/reinstall at the same plugin version 0.1.1, not automatic marketplace upgrade or a version migration.',
        'Resources run by external verifier with fresh app-server processes, not a model selecting and using methods.',
        'Sentinel registration remains unchanged and final registered-plugin lists are empty. User work/config directories are intentionally retained; arbitrary game saves or plugin persistent-data restoration was not tested.',
        'Synthetic observation output establishes parsing/persistence mechanics, not authentic human, game quality, usability or accessibility evidence.',
        'No general-document, Ink implementation, matrix implementation, archive/release, other OS or remaining repository behavior review.'
    ]
}
(OUT / 'native-qualified-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['reviewer_verdict', 'candidate_commit', 'archive_sha256', 'receipt_sha256', 'platform', 'python', 'versions', 'commands', 'observations', 'failed_checks', 'scoped_identity_drift']}, indent=2))
print('Independent assertions:', len(checks))
print('Operations:', [(o['client'], o['stage'], o['files']) for o in operations])
