// INCLUDE not-selected.ink
A sentence mentions INCLUDE in ordinary text.
-> END
