EXTERNAL host_read()
{host_read()}
-> END
=== function host_read() ===
~ return "fallback"
