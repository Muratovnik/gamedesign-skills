LIST possessions = pebble, ribbon
VAR inventory = (pebble)
Inventory: {inventory}.
-> END
