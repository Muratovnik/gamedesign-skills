VAR count = 0
VAR note = "untouched"
-> room
=== room ===
+ [Advance]
    ~ count += 1
    ~ note = "changed"
    Updated.
    -> room
+ [Finish]
    Completed.
    -> END
