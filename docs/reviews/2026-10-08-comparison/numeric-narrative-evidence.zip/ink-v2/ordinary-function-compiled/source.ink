{local_read()}
-> END
=== function local_read() ===
~ return "local function result"
