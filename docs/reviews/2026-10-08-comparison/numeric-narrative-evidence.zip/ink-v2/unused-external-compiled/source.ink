EXTERNAL unused_host()
Available.
-> END
