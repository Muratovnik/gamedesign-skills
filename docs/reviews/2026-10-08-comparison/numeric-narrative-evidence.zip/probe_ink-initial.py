"""Additional native review probes, executed through the delivered adapter."""
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e429285ef1e1/gamedesign-skills')
ADAPTER = REPO / 'skills/game-world-narrative-design/scripts/ink_artifact.cjs'
NODE = os.environ['CODEX_PRIMARY_RUNTIME_NODE']
INK = Path('/workspace/scratch/e429285ef1e1/research/environment/ink-i1-deps-l4jwg44g/node_modules/inkjs')
WORK = HERE / 'ink'
WORK.mkdir(exist_ok=True)
RESULTS = []


def write(name, value):
    selected = WORK / name
    selected.write_text(value if isinstance(value,str) else json.dumps(value,indent=2)+'\n')
    return selected


def scenario(name, **overrides):
    return write(name+'.json',dict(schema='ink-scenario/1', id=name,
                 observe_variables=[], actions=[], checks=[], **overrides))


def cli(name, operation, args, expected=0, code=None):
    command = [NODE,str(ADAPTER),operation,*map(str,args)]
    result = subprocess.run(command,cwd=WORK,capture_output=True,text=True,timeout=15)
    receipt = dict(command=command,cwd=str(WORK),returncode=result.returncode,
                   stdout=result.stdout,stderr=result.stderr)
    write(name+'-command.json',receipt)
    assert result.returncode == expected, (name,result.returncode,result.stdout,result.stderr)
    assert result.stderr == '', (name,result.stderr)
    report = json.loads(result.stdout)
    if code:
        assert report['failure']['code'] == code, (name,report)
    RESULTS.append(dict(name=name,returncode=result.returncode,status=report['status'],
                        outcome=report.get('outcome'),failure=report.get('failure')))
    return report


def compile_story(name, source, expected=0, code=None):
    selected = write(name+'.ink',source)
    out = WORK/(name+'-compiled')
    report = cli(name+'-compile','compile',['--source',selected,'--inkjs-root',INK,'--out',out],expected,code)
    return out/'story.json',report


def run_story(name, compiled, plan, state=None, expected=0, code=None):
    out = WORK/name
    args = ['--compiled',compiled,'--scenario',plan,'--inkjs-root',INK,'--out',out]
    if state:
        args += ['--state',state]
    report = cli(name,'resume' if state else 'run',args,expected,code)
    if expected != 0:
        assert not (out/'state.json').exists(), name
    return out,report


def assess(name, compiled, plan, report_file, expected=0, code=None):
    return cli(name,'assess',['--compiled',compiled,'--scenario',plan,'--report',report_file],expected,code)


# Native sticky choices and all-global state persistence: first scenario observes
# count only; the second asks for another global that changed before the save.
story, _ = compile_story('native-state-variant','''VAR count = 0
VAR note = "untouched"
-> room
=== room ===
+ [Advance]
    ~ count += 1
    ~ note = "changed"
    Updated.
    -> room
+ [Finish]
    Completed.
    -> END
''')
first = write('first.json',{'schema':'ink-scenario/1','id':'first','observe_variables':['count'],
    'actions':[{'choice':'Advance'}],'checks':[{'kind':'variable','at':1,'name':'count','equals':1}]})
first_out,first_report = run_story('first-run',story,first)
assert first_report['observations'][1]['variables'] == {'count':1}
assess('first-assess',story,first,first_out/'report.json')
second = write('second.json',{'schema':'ink-scenario/1','id':'second','observe_variables':['note','count'],
    'actions':[{'choice':'Finish'}],'checks':[{'kind':'variable','at':0,'name':'note','equals':'changed'},
        {'kind':'variable','at':0,'name':'count','equals':1},{'kind':'terminal','at':1,'equals':True},
        {'kind':'text','at':1,'includes':'Completed.'}]})
second_out,second_report = run_story('second-run',story,second,state=first_out/'state.json')
assert second_report['observations'][0]['output'] == []
assert second_report['observations'][0]['variables'] == {'note':'changed','count':1}
assess('second-assess',story,second,second_out/'report.json')

# A truly silent END is a valid native transcript and cannot satisfy an action.
silent,_ = compile_story('silent-ending','-> END\n')
silent_plan = write('silent-plan.json',{'schema':'ink-scenario/1','id':'silent','observe_variables':[],
    'actions':[],'checks':[{'kind':'terminal','at':0,'equals':True},{'kind':'action_count','at_least':1}]})
silent_out,silent_report = run_story('silent-run',silent,silent_plan)
assert silent_report['observations'][0]['output'] == []
silent_assessment = assess('silent-assess',silent,silent_plan,silent_out/'report.json',1)
assert [check['outcome'] for check in silent_assessment['checks']] == ['supported','refuted']

# Native library boundaries have valid neighbors: uncalled host declaration and
# an ordinary Ink function are supported; a host call with a fallback remains out
# of this explicitly binding-free route.
empty = write('capture-only.json',{'schema':'ink-scenario/1','id':'capture','observe_variables':[],'actions':[],'checks':[]})
unused,_ = compile_story('unused-external','EXTERNAL unused_host()\nAvailable.\n-> END\n')
run_story('unused-external-run',unused,empty)
fallback,_ = compile_story('external-fallback','EXTERNAL host_read()\n{host_read()}\n-> END\n=== function host_read() ===\n~ return "fallback"\n')
run_story('external-fallback-run',fallback,empty,expected=2,code='external_functions_unavailable')
local,_ = compile_story('ordinary-function','{local_read()}\n-> END\n=== function local_read() ===\n~ return "local function result"\n')
_,local_report = run_story('ordinary-function-run',local,empty)
assert ''.join(x['text'] for x in local_report['observations'][0]['output']) == 'local function result\n'
comment,_ = compile_story('commented-include','// INCLUDE not-selected.ink\nA sentence mentions INCLUDE in ordinary text.\n-> END\n')
run_story('commented-include-run',comment,empty)

# The native list remains usable in the scene; selecting it as an invented
# scalar is correctly unavailable.
listed,_ = compile_story('native-list','LIST possessions = pebble, ribbon\nVAR inventory = (pebble)\nInventory: {inventory}.\n-> END\n')
list_out,list_report = run_story('native-list-text',listed,empty)
assert ''.join(x['text'] for x in list_report['observations'][0]['output']) == 'Inventory: pebble.\n'
list_plan = write('list-observation.json',{'schema':'ink-scenario/1','id':'complex-selection',
    'observe_variables':['inventory'],'actions':[],'checks':[]})
run_story('native-list-scalar',listed,list_plan,expected=2,code='variable_unavailable')
missing_plan = write('missing-observation.json',{'schema':'ink-scenario/1','id':'missing-selection',
    'observe_variables':['not_declared'],'actions':[],'checks':[]})
run_story('missing-global-run',listed,missing_plan,expected=2,code='variable_unavailable')

# Exact output bound: seven printed digits plus the native newline is 8 chars.
bounded,_ = compile_story('output-boundary','1234567\n-> END\n')
for limit,expected in [(8,0),(7,2)]:
    plan = write(f'output-{limit}.json',{'schema':'ink-scenario/1','id':f'output-{limit}',
        'observe_variables':[],'actions':[],'checks':[],
        'limits':{'max_continue':1,'max_output_chars':limit}})
    _,report = run_story(f'output-{limit}-run',bounded,plan,expected=expected,
                        code='output_limit' if expected else None)
    if not expected:
        assert report['continuation_count'] == 1 and report['output_chars'] == 8

# Challenge usable evidence versus unavailable/malformed evidence through the
# real assessor; do not claim checksum authentication or branch enumeration.
mutations = [
    ('missing-variable',lambda r:r['observations'][0]['variables'].pop('count'),'invalid_report'),
    ('missing-action',lambda r:r['actions'].clear(),'incomplete_run'),
    ('bad-choice-index',lambda r:r['observations'][0]['choices'][0].update(index=9),'invalid_report'),
    ('bad-step',lambda r:r['observations'][1].update(step=0),'invalid_report'),
    ('false-terminal-shape',lambda r:r['observations'][0].update(terminal=True),'invalid_report'),
    ('runtime-error-record',lambda r:r['diagnostics'].append({'severity':'error','message':'failed'}),'incomplete_run'),
    ('changed-adapter',lambda r:r.update(adapter_sha256='0'*64),'report_identity_mismatch'),
]
for name,change,code in mutations:
    altered = deepcopy(first_report)
    change(altered)
    selected = write(name+'-report.json',altered)
    assess(name+'-assess',story,first,selected,2,code)
changed_story = write('reformatted-story.json',story.read_text()+'\n')
assess('changed-story-assess',changed_story,first,first_out/'report.json',2,'report_identity_mismatch')

# Direct collision paths cannot truncate an ordinary file or follow a symlink.
sentinel = write('output-file-sentinel','retain these exact bytes\n')
sentinel_dir = WORK/'output-directory-sentinel'
sentinel_dir.mkdir()
inside = sentinel_dir/'keep'
inside.write_text('retained target content\n')
link = WORK/'output-symlink'
link.symlink_to(sentinel_dir,target_is_directory=True)
dangling = WORK/'output-dangling-symlink'
dangling.symlink_to(WORK/'missing-directory',target_is_directory=True)
for name,out in [('file',sentinel),('symlink',link),('dangling',dangling)]:
    cli('collision-'+name,'compile',['--source',WORK/'silent-ending.ink','--inkjs-root',INK,'--out',out],2,'EEXIST')
assert sentinel.read_text() == 'retain these exact bytes\n'
assert inside.read_text() == 'retained target content\n'
assert link.is_symlink() and dangling.is_symlink() and not (WORK/'missing-directory').exists()

summary = dict(adapter_sha256=hashlib.sha256(ADAPTER.read_bytes()).hexdigest(),
    ink_bundle_sha256=hashlib.sha256((INK/'dist/ink-full.js').read_bytes()).hexdigest(),
    commands=RESULTS)
(HERE/'ink-probes-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'commands':len(RESULTS),'all_expected_results':True,
                  'native_state_added_variable':'restored','silent_terminal':'supported; required action refuted'}))
