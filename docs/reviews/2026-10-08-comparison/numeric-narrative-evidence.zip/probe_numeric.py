"""Read-only review probes; all generated files stay in this review directory."""
from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import random
import subprocess
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e429285ef1e1/gamedesign-skills')
SCRIPT = REPO / 'skills/game-systems-design/scripts/solve_zero_sum.py'
PYTHON = os.environ['CODEX_PRIMARY_RUNTIME_PYTHON']
WORK = HERE / 'numeric'
WORK.mkdir(exist_ok=True)
BASE = json.loads((REPO / 'examples/strategy-matrix/fixtures/channel-signals.json').read_text())
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')


def exact_two_row_value(matrix):
    """Maximize the lower envelope of lines on [0,1], with exact arithmetic."""
    a = [[Fraction(float(value)) for value in row] for row in matrix]
    candidates = {Fraction(0), Fraction(1)}
    for j in range(len(a[0])):
        for k in range(j):
            slope = (a[0][j] - a[1][j]) - (a[0][k] - a[1][k])
            if slope:
                p = (a[1][k] - a[1][j]) / slope
                if 0 <= p <= 1:
                    candidates.add(p)
    return max(min(p * a[0][j] + (1-p) * a[1][j] for j in range(len(a[0])))
               for p in candidates)


def make_model(name, matrix):
    model = deepcopy(BASE)
    model['model_id'] = 'independent-' + name
    model['payoffs'] = matrix
    model['row_player']['actions'] = [f'r{i}' for i in range(len(matrix))]
    model['column_player']['actions'] = [f'c{j}' for j in range(len(matrix[0]))]
    return model


def invoke(name, matrix, output=None, extra=()):
    input_path = WORK / (name + '.json')
    output_path = output or WORK / (name + '-report.json')
    input_path.write_text(json.dumps(make_model(name, matrix)) + '\n')
    command = [PYTHON, '-B', str(SCRIPT), '--model', str(input_path), '--output', str(output_path), *extra]
    run = subprocess.run(command, cwd=WORK, env=ENV, capture_output=True, text=True, timeout=30)
    receipt = {'command': command, 'cwd': str(WORK), 'returncode': run.returncode,
               'stdout': run.stdout, 'stderr': run.stderr}
    (WORK / (name + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    return run, output_path, input_path


def check_case(item):
    name, matrix = item
    run, output, input_path = invoke(name, matrix)
    assert run.returncode == 0, (name, run.stdout, run.stderr)
    report = json.loads(output.read_text())
    assert report == json.loads(run.stdout)
    assert report['input']['sha256'] == hashlib.sha256(input_path.read_bytes()).hexdigest()
    p = [Fraction(x['probability']) for x in report['strategies']['row']]
    q = [Fraction(x['probability']) for x in report['strategies']['column']]
    a = [[Fraction(float(x)) for x in row] for row in matrix]
    lower = min(sum(p[i] * a[i][j] for i in range(len(p))) for j in range(len(q)))
    upper = max(sum(a[i][j] * q[j] for j in range(len(q))) for i in range(len(p)))
    value = exact_two_row_value(matrix)
    scale = Fraction(report['numerics']['payoff_scale'])
    offset = Fraction(report['numerics']['payoff_offset'])
    tolerance = report['numerics']['normalized_utility_tolerance']
    # This uses the original binary64 inputs and emitted probabilities, without
    # the adapter's LP construction, certificate helper or normalization array.
    gap = float((upper - lower) / scale)
    true_normalized_value = float((value-offset)/scale)
    norm = report['certificate']['normalized']
    assert abs(gap) <= tolerance + 1e-14, (name, gap)
    assert float((lower-value)/scale) <= tolerance, name
    assert float((value-upper)/scale) <= tolerance, name
    assert abs(norm['expected_row_utility'] - true_normalized_value) <= tolerance, name
    assert abs(norm['row_guarantee'] - float((lower-offset)/scale)) <= 1e-14, name
    assert abs(norm['column_cap'] - float((upper-offset)/scale)) <= 1e-14, name
    return {'name': name, 'status': report['status'], 'exact_value': str(value),
            'normalized_gap_from_original_inputs': gap,
            'normalized_expected_error': abs(norm['expected_row_utility'] - true_normalized_value)}


rng = random.Random(20261008)
cases = [(f'rational-{k:02}', [[rng.randrange(-17,18) for _ in range(2+k%4)] for _ in range(2)])
         for k in range(12)]
maximum = sys.float_info.max
unit = math.ulp(maximum)
tiny = math.ulp(0.0)
cases += [
    ('maximum-constant', [[maximum,maximum],[maximum,maximum]]),
    ('maximum-symmetric', [[maximum,-maximum],[-maximum,maximum]]),
    ('maximum-asymmetric', [[maximum,-maximum],[-maximum/2,maximum/2]]),
    ('maximum-offset', [[maximum-8*unit,maximum],[maximum,maximum-8*unit]]),
    ('minimum-subnormal', [[0,tiny],[tiny,0]]),
    ('subnormal-asymmetric', [[2*tiny,5*tiny],[7*tiny,tiny]]),
]
with ThreadPoolExecutor(max_workers=2) as executor:
    results = list(executor.map(check_case, cases))

# Preserve ordinary, dangling-symlink and directory output targets, plus their
# valid new-file counterpart. These exercise the delivered CLI filesystem path.
sentinel = WORK / 'sentinel'
sentinel.write_bytes(b'preexisting review sentinel\n')
link = WORK / 'existing-symlink'
link.symlink_to(sentinel)
dangling = WORK / 'dangling-symlink'
dangling.symlink_to(WORK / 'absent-target')
directory = WORK / 'existing-directory'
directory.mkdir()
collisions = []
for name, output in [('file',sentinel),('symlink',link),('dangling',dangling),('directory',directory)]:
    run, _, _ = invoke('collision-'+name, [[1,-1],[-1,1]], output=output)
    assert run.returncode == 2 and json.loads(run.stderr)['status'] == 'output_unavailable'
    collisions.append(name)
assert sentinel.read_bytes() == b'preexisting review sentinel\n'
assert link.is_symlink() and dangling.is_symlink() and directory.is_dir()
assert not (WORK / 'absent-target').exists()
valid = check_case(('new-output-control', [[1,-1],[-1,1]]))
summary = {'source_sha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
           'cases': results + [valid], 'preserved_collisions': collisions}
(HERE / 'numeric-probes-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'passed_numeric_cases': len(results)+1, 'preserved_collisions': collisions,
                  'largest_independent_normalized_gap': max(x['normalized_gap_from_original_inputs'] for x in results)}))
