"""Read-only publication-evidence review; probes write only below this directory."""
from __future__ import annotations

import collections
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/e429285ef1e1/gamedesign-skills')
SCANNER = REPO / '.cache/release-kit/betterleaks/1.8.1/betterleaks'
COMPARISON = REPO / 'docs/reviews/2026-10-08-comparison'


def save(name: str, value: object) -> None:
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


def scan(label: str, config: Path, target: Path) -> list[dict]:
    report = OUT / f'{label}.redacted.json'
    argv = [str(SCANNER), '--no-banner', '--no-color', '--redact',
            '--report-format', 'json', '--report-path', str(report),
            '--config', str(config), 'dir', str(target)]
    run = subprocess.run(argv, cwd=REPO, capture_output=True, text=True)
    (OUT / f'{label}.stdout').write_text(run.stdout)
    (OUT / f'{label}.stderr').write_text(run.stderr)
    save(f'{label}-run.json', {'argv': argv, 'cwd': str(REPO),
                             'exit_code': run.returncode,
                             'credential_validation': False})
    assert run.returncode in (0, 1), f'{label}: scanner execution failed'
    return json.loads(report.read_text()) or []


findings = json.loads((OUT / 'betterleaks-expanded-before.redacted.json').read_text())
sources = json.loads((OUT / 'hash-adjudication.json').read_text())['recomputed_sources']
known = {x['sha256']: x['meaning'] for x in sources}
groups: dict[str, set[str]] = collections.defaultdict(set)
adjudications = []
for finding in findings:
    paths = finding['File'].split('!')
    payload = Path(paths[0]).read_bytes()
    for member in paths[1:]:
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            payload = archive.read(member)
    lines = payload.decode('utf-8').splitlines()
    matched = '\n'.join(lines[finding['StartLine']-1:finding['EndLine']])
    hashes = re.findall(r'(?<![0-9a-f])[0-9a-f]{64}(?![0-9a-f])', matched)
    assert len(hashes) == 1 and hashes[0] in known
    digest = hashes[0]
    assert finding['RuleID'] == 'generic-api-key'
    relative = finding['File'].removeprefix(str(REPO) + '/')
    groups[digest].add(relative)
    adjudications.append({'file': relative, 'line': finding['StartLine'],
                          'rule': finding['RuleID'], 'sha256': digest,
                          'content_identity': known[digest]})

base = (REPO / '.betterleaks.toml').read_text()
addition = '\n# Exact public evidence content identities, independently recomputed.\n'
addition += '# All conditions apply together; default detection rules remain enabled.\n'
for digest, paths in sorted(groups.items()):
    addition += '\n[[allowlists]]\n'
    addition += 'description = ' + json.dumps('Verified SHA256 of ' + known[digest] + ' in exact raw evidence records') + '\n'
    addition += 'targetRules = ["generic-api-key"]\ncondition = "AND"\nregexTarget = "secret"\n'
    addition += "regexes = ['''^" + digest + "$''']\npaths = [\n"
    for relative in sorted(paths):
        addition += "  '''(?:^|/)" + re.escape(relative) + "$''',\n"
    addition += ']\n'
candidate = OUT / 'proposed-betterleaks.toml'
candidate.write_text(base + addition)
save('expanded-hash-adjudication.json', {'findings': adjudications,
                                      'count': len(adjudications),
                                      'recomputed_sources': sources})

run = subprocess.run([str(SCANNER), '--config', str(candidate), 'config', 'check'],
                     cwd=REPO, capture_output=True, text=True)
(OUT / 'candidate-config-check.stdout').write_text(run.stdout)
(OUT / 'candidate-config-check.stderr').write_text(run.stderr)
assert run.returncode == 0, 'Candidate config rejected'
current = scan('candidate-config-evidence-scan', candidate, COMPARISON)

# These records are synthetic controls. They are never sent to a provider or used
# as credentials. Only scanner reports redacted by Betterleaks are retained.
controls = OUT / 'controls'
control_rel = Path('docs/reviews/2026-10-08-comparison')
keep = next(h for h, meaning in known.items() if meaning == 'Ink keep-token scenario')
access = next(h for h, meaning in known.items() if meaning == 'access-and-return source')
altered = hashlib.sha256(b'release evidence audit synthetic changed digest').hexdigest()
unrelated = hashlib.sha256(b'release evidence audit synthetic unrelated credential value').hexdigest()
cases = {
    'exact-path-and-hash': (control_rel / 'behavior-evidence-manifest.json',
                           {'keep-token.json': keep}, 0),
    'same-path-changed-hash': (control_rel / 'behavior-evidence-manifest.json',
                              {'keep-token.json': altered}, 1),
    'same-path-unrelated-credential': (control_rel / 'behavior-evidence-manifest.json',
                                      {'api_key': unrelated}, 1),
    'same-hash-other-path': (control_rel / 'unlisted-evidence.json',
                            {'access-and-return.md': access}, 1),
    'path-suffix-must-not-match': (control_rel / 'behavior-evidence-manifest.json.copy',
                                 {'keep-token.json': keep}, 1),
}
control_results = []
for label, (relative, document, expected) in cases.items():
    target = controls / label / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(document, indent=2) + '\n')
    baseline = scan(label + '-baseline', REPO / '.betterleaks.toml', target)
    checked = scan(label + '-candidate', candidate, target)
    before_count = sum(x['RuleID'] == 'generic-api-key' for x in baseline)
    after_count = sum(x['RuleID'] == 'generic-api-key' for x in checked)
    control_results.append({'case': label, 'baseline_generic_findings': before_count,
                            'candidate_generic_findings': after_count,
                            'expected_candidate_generic_findings': expected,
                            'status': 'pass' if before_count == 1 and after_count == expected else 'fail'})

for label, member, expected in [
    ('exact-archive-member-and-hash', 'evidence-manifest.json', 0),
    ('same-archive-other-member', 'not-allowlisted-evidence.json', 1),
]:
    target = controls / label / control_rel / 'behavior-evidence.zip'
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, 'w') as archive:
        archive.writestr(member, json.dumps({'keep-token.json': keep}) + '\n')
    baseline = scan(label + '-baseline', REPO / '.betterleaks.toml', target)
    checked = scan(label + '-candidate', candidate, target)
    before_count = sum(x['RuleID'] == 'generic-api-key' for x in baseline)
    after_count = sum(x['RuleID'] == 'generic-api-key' for x in checked)
    control_results.append({'case': label, 'baseline_generic_findings': before_count,
                            'candidate_generic_findings': after_count,
                            'expected_candidate_generic_findings': expected,
                            'status': 'pass' if before_count == 1 and after_count == expected else 'fail'})

# A test-only second detection rule confirms that targetRules is not interpreted
# as a global finding allowlist. It is absent from the proposed repo config.
sentinel_config = OUT / 'control-only-target-rule.toml'
sentinel_config.write_text(candidate.read_text() + '\n[[rules]]\nid = "audit-second-rule-control"\n'
                          'description = "Synthetic rule-scope control"\n'
                          "regex = '''(" + keep + ")'''\nsecretGroup = 1\n")
target = controls / 'exact-path-and-hash' / cases['exact-path-and-hash'][0]
checked = scan('other-rule-same-path-and-hash', sentinel_config, target)
other_count = sum(x['RuleID'] == 'audit-second-rule-control' for x in checked)
generic_count = sum(x['RuleID'] == 'generic-api-key' for x in checked)
control_results.append({'case': 'other-rule-same-path-and-hash',
                        'candidate_second_rule_findings': other_count,
                        'candidate_generic_findings': generic_count,
                        'status': 'pass' if other_count == 1 and generic_count == 0 else 'fail'})

result = {'scanner': str(SCANNER), 'candidate_config': str(candidate),
          'candidate_config_sha256': hashlib.sha256(candidate.read_bytes()).hexdigest(),
          'current_evidence_findings_after': len(current),
          'controls': control_results,
          'status': 'pass' if not current and all(x['status'] == 'pass' for x in control_results) else 'fail',
          'scope': 'Independent scratch config only. The repository config and original receipts were not modified.'}
save('scanner-boundary-probes.json', result)
print(json.dumps(result, indent=2))
