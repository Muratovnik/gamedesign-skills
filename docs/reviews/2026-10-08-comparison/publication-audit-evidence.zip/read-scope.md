# Read scope and independence

This reviewer received a bounded assignment from the primary: adjudicate publication scanner findings, verify flagged content identities, inspect exact evidence exceptions and preserve original receipts. The supplied brief explicitly requests public raw evidence. Product review belongs to a different reviewer.

## Criteria and tool implementation read

- Repository `AGENTS.md`, `relkit.toml` and `.betterleaks.toml`.
- Assay `AGENTS.md`, `skills/independent-audit/SKILL.md`, and the bounded-review, evidence-and-probes, and repository-and-release references.
- The pinned `.github/relkit.pyz` member inventory; relevant sections of `releasekit/config.py`, `releasekit/exposure/rules.py`, `releasekit/exposure/audit.py` and `releasekit/engines.py`.
- Betterleaks 1.8.1 CLI help and config validation; the pinned upstream README, config documentation, `config/config.go` and `config/allowlist.go` through the GitHub connector.

## Artifact content inspected

- Comparison evidence inventory and manifests; the original reported digest receipt supplied by the primary.
- The complete access-and-return source reference, the synthetic keep-token scenario, and the redacted Claude status receipt.
- Every flagged line from all 26 redacted Betterleaks findings, reopened from its actual file or ZIP member and matched to independently recomputed source bytes.
- Every member of the five specifically proposed archives, 298 entries in total: reopened, hashed and passed through the pinned public structural rules. This is complete byte/structural coverage, not a claim of full product-semantic review of every sentence.
- Cause and context of the flagged native logs, invocation and catalog metadata, home-like path inventory, replay script, and reviewer identifier. General product findings in the other review reports were not re-adjudicated.
- All four hosted CI logs: byte identity, secret scan, public structural scan, presence, tracking and ignore status.
- Eight synthetic allowlist controls and a direct excluded-payload private-marker control, using only reviewer-owned scratch data and no credential validation.

## Scope limits and effects

Git operations were read-only identity/status/ignore/index queries. The reviewer made no repository edits, staging, commits, publication, original evidence rewrites, credential reads, authentication changes or client-setting changes. Writes were limited to this review directory and ordinary scanner runtime/cache effects. No model executions were requested.

The real private owner policy and final staged publication gate were not independently run. The primary is applying the reviewed configuration and owns final staged acceptance. Local original source paths for the three digest inputs were supplied explicitly by the primary.

One preliminary metadata-only `AGENTS.md` discovery listed paths across `/workspace`, broader than needed for this assignment. Unrelated results were not opened or used in the adjudication. Subsequent content reads stayed within the subject repository, the named Assay method, the assigned research/evidence paths and pinned upstream scanner sources. This scope departure is recorded separately from the subject verdict.

Primary-authored configuration changes during the review are expected. `final-input-drift-check.json` distinguishes those from changes to the original evidence bytes or frozen runtime identity.
