#!/usr/bin/env python3
"""Make a task-owned integration fixture from the already extracted candidate."""
import json
from pathlib import Path
import shutil

BASE=Path(__file__).resolve().parent
original=BASE/'extracted source/game-design'
copy=BASE/'binding update copy'
shutil.copytree(original,copy)
print(json.dumps({'copied_candidate':str(copy), 'purpose':'Exercise maintainer binding regeneration only; no compatibility adoption or source edit'}))
