#!/usr/bin/env python3
"""Create ordinary exported-owner controls under the review directory only."""
import json
from pathlib import Path
import shutil

BASE=Path(__file__).resolve().parent
SOURCE=BASE.parents[1]/'assay-current'
binding=json.loads((BASE/'binding update copy/skills/game-design/assets/assay-binding.json').read_text())
root=BASE/'current owner export'
root.mkdir(exist_ok=False)
for relative in list(binding['identity_files'])+list(binding['owners']['evidence-research']):
    target=root/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(SOURCE/relative,target)
for kind in ['missing-resource','changed-resource','symlink-loop','missing-peer']:
    destination=BASE/kind
    shutil.copytree(root,destination)
    target=destination/'skills/evidence-research/SKILL.md'
    if kind=='missing-resource':
        target.unlink()
    elif kind=='changed-resource':
        target.write_text(target.read_text()+'\nChanged diagnostic fixture.\n')
    elif kind=='symlink-loop':
        target.unlink()
        target.symlink_to('SKILL.md')
    elif kind=='missing-peer':
        shutil.rmtree(destination/'skills/evidence-research')
print(json.dumps({'fixture_root':str(root),'files':len(list(root.rglob('*'))),'intent':'Known current owner export and defective siblings, no native installation'}))
