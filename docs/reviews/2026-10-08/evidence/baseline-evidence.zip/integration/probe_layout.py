#!/usr/bin/env python3
"""Review-only extraction and load-path probe; never registers a native client."""
import hashlib
import json
from pathlib import Path
import shutil
import stat
import subprocess
import sys
from urllib.parse import unquote, urlsplit
import zipfile

BASE = Path(__file__).resolve().parent
SOURCE = BASE.parents[1] / 'gamedesign-skills'
ARCHIVE = BASE / 'release one/gamedesign-skills-0.1.0-source.zip'
EXTRACTED = BASE / 'extracted source/game-design'
TARGET = BASE / 'disposable project/.agents/skills'

tracked = subprocess.check_output(['git', '-C', str(SOURCE), 'ls-files', '-z']).decode().split('\0')
tracked = [x for x in tracked if x]
inventory = {}
with zipfile.ZipFile(ARCHIVE) as z:
    names = z.namelist()
    assert len(names) == len(set(names))
    for info in z.infolist():
        parts = Path(info.filename).parts
        assert parts[0] == 'game-design' and '..' not in parts and not Path(info.filename).is_absolute()
        assert not stat.S_ISLNK(info.external_attr >> 16)
        relative = '/'.join(parts[1:])
        data = z.read(info)
        inventory[relative] = {'sha256': hashlib.sha256(data).hexdigest(), 'mode': oct(info.external_attr >> 16), 'bytes': len(data)}
        assert data == (SOURCE / relative).read_bytes(), relative
    assert set(inventory) == set(tracked), (set(inventory) - set(tracked), set(tracked) - set(inventory))
    assert not EXTRACTED.exists()
    z.extractall(EXTRACTED.parent)
(BASE / 'archive-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')

TARGET.mkdir(parents=True, exist_ok=False)
for skill in sorted((EXTRACTED / 'skills').iterdir()):
    shutil.copytree(skill, TARGET / skill.name)

# Reuse the shipped CommonMark parser, while resolving links from a real installed
# layout that contains no repository-root docs/examples/tools/catalog.
sys.path.insert(0, str(EXTRACTED / 'tools'))
import check
documents = {p.resolve(): check.document(p.read_text()) for p in TARGET.rglob('*.md')}
links = []
errors = []
for path, (destinations, _) in documents.items():
    for destination in destinations:
        parsed = urlsplit(destination)
        if parsed.scheme or parsed.netloc or not (parsed.path or parsed.fragment):
            continue
        target = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
        row = {'source': str(path.relative_to(TARGET)), 'link': destination, 'target': str(target.relative_to(TARGET)) if target.is_relative_to(TARGET) else str(target)}
        links.append(row)
        if not target.is_relative_to(TARGET) or not target.exists():
            errors.append(row)
        elif parsed.fragment and target in documents and unquote(parsed.fragment) not in documents[target][1]:
            errors.append(row)
assert documents and links
report = {'archive_sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
          'archive_files': len(inventory), 'source_tracked_files': len(tracked),
          'all_archived_bytes_match_source': True,
          'installed_skills': sorted(p.name for p in TARGET.iterdir()),
          'runtime_markdown_count': len(documents), 'local_resource_links': len(links),
          'resource_errors': errors, 'links': links,
          'scope': 'manual disposable full-bundle copy and explicit local link reads; not a native installer or discovery run'}
(BASE / 'layout-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k != 'links'}, indent=2))
raise SystemExit(bool(errors))
