"""Review-only command capture. Every produced file is owned by this review."""
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
name, *argv = sys.argv[1:]
if not name or not argv or Path(name).name != name:
    raise SystemExit("Need one simple receipt name and a command argv")
env = os.environ.copy()
env.update(PYTHONDONTWRITEBYTECODE="1", TMPDIR=str(ROOT / "tmp"))
started = time.time()
meta = {"argv": argv, "cwd": os.getcwd(), "environment_overrides": {
    "PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(ROOT / "tmp")},
    "note": "Instruction-scoped isolation; no OS sandbox is imposed by this capture script."}
try:
    result = subprocess.run(argv, capture_output=True, env=env, timeout=55, check=False)
    out, err, code = result.stdout, result.stderr, result.returncode
except subprocess.TimeoutExpired as exc:
    out, err, code = exc.stdout or b"", exc.stderr or b"", None
    meta["timeout_seconds"] = 55
meta.update(exit_code=code, elapsed_seconds=time.time() - started)
for suffix, data in (("stdout", out), ("stderr", err)):
    (ROOT / "logs" / (name + "." + suffix)).write_bytes(data)
(ROOT / "logs" / (name + ".json")).write_text(json.dumps(meta, indent=2) + "\n")
print(json.dumps({"receipt": name, "exit_code": code, "stdout_bytes": len(out), "stderr_bytes": len(err)}))
sys.stdout.flush()
