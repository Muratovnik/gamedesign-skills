"""Prepare review-owned inputs without modifying the frozen subject."""
from copy import deepcopy
import json
from pathlib import Path
import sys

REVIEW = Path(__file__).resolve().parent
SUBJECT = REVIEW.parents[1] / "gamedesign-skills"
sys.path.insert(0, str(SUBJECT / "examples/analysis-lab"))
from state import migrate
from consumer import observer_view


def read(path):
    return json.loads(path.read_text())


def save(name, value):
    target = REVIEW / "fixtures" / name
    target.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n")
    return target


dictionary = read(SUBJECT / "examples/analysis-lab/fixtures/event-dictionary.json")
bad_dictionary = deepcopy(dictionary)
bad_dictionary["builds"]["gate-episode-2"]["outcome_event"] = "gate_crosssed"
save("dictionary-unknown-outcome.json", bad_dictionary)

old = read(SUBJECT / "examples/analysis-lab/fixtures/save-v1.json")
current = migrate(old)
save("save-v2-valid.json", current)
save("view-bo-valid.json", observer_view(current, "bo"))
bad = deepcopy(current)
next(a for a in bad["actors"] if a["id"] == "bo")["known_fact_ids"] = []
save("save-v2-no-winch-knowledge.json", bad)
save("view-bo-no-winch-knowledge.json", observer_view(bad, "bo"))

candidate = read(SUBJECT / "examples/godot-episode/fixtures/candidate.json")
candidate["threats"][0]["warning_tick"] = 0
save("godot-warning-at-zero.json", candidate)

report = read(SUBJECT / "examples/godot-episode/fixtures/test_recorded_candidate_report.json")
bad_report = deepcopy(report)
bad_report["events"] = [e for e in bad_report["events"]
    if e["kind"] not in {"state_saved", "state_reset", "state_restored", "npc_reply"}
    and not (e["kind"] in {"input_injected", "input_received"}
             and e["detail"]["action"] in {"save", "reset", "load", "interact"})]
for i, event in enumerate(bad_report["events"]):
    event["sequence"] = i
bad_report["input_received_count"] = sum(e["kind"] == "input_received" for e in bad_report["events"])
save("godot-report-no-state-inputs.json", bad_report)

source = read(SUBJECT / "examples/adaptation/fixtures/east-gate-ru.json")
source.pop("aid")
save("adaptation-without-pins.json", source)
print(json.dumps({"prepared": sorted(p.name for p in (REVIEW / "fixtures").iterdir())}))
