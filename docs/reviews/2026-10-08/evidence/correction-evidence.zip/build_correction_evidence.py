"""Package selected raw correction evidence and verify each reopened member."""
import hashlib
import json
from pathlib import Path
import zipfile

WORK = Path(__file__).resolve().parent
OUTPUT = WORK / "correction-delivery"
OUTPUT.mkdir(exist_ok=False)
selected = set()

def add(path):
    path = Path(path)
    if path.is_symlink():
        raise ValueError("Evidence selection must not dereference a symlink: " + str(path))
    if not path.is_file():
        raise ValueError("Missing evidence: " + str(path))
    if path.stat().st_size > 4_000_000:
        raise ValueError("Unexpected large selected file: " + str(path))
    selected.add(path.relative_to(WORK).as_posix())

for root in ("technical/correction", "integration/correction", "integrated-checks", "final-checks"):
    for path in (WORK / root).rglob("*"):
        relative = path.relative_to(WORK / root)
        if any(part in {"tmp", "__pycache__", ".cache", ".godot"} for part in relative.parts):
            continue
        if path.is_file():
            add(path)

for name in ("technical/correction.md", "domain/correction.md", "run_integrated_checks.py", "capture_final.py",
             "build_correction_evidence.py", "review-exposure-audit.json", "review-exposure-audit.stderr"):
    add(WORK / name)

client = WORK / "native-client-isolation"
for name in (client / "evidence-allowlist.txt").read_text().splitlines():
    add(client / name)

for root in ("native-baseline", "native-baseline-55", "native-candidate-55", "native-first-tick"):
    for path in (WORK / root).rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(WORK / root)
        # Raw reports, real save JSON and logs; all four actual game files.
        if "host-state" in relative.parts or ".godot" in relative.parts:
            continue
        if path.suffix in {".json", ".log"} or path.name in {"project.godot", "episode.tscn", "episode.gd", "player.gd"}:
            add(path)

for root in ("native-diagnostic-minimal", "native-diagnostic-episode"):
    for path in (WORK / root).iterdir():
        if path.is_file():
            add(path)
    for path in (WORK / root / "project").iterdir():
        if path.name in {"project.godot", "episode.tscn", "episode.gd", "player.gd"}:
            add(path)

for path in (WORK / "native-runtime").iterdir():
    if path.is_file() and path.suffix in {".json", ".stdout", ".stderr"}:
        add(path)
add(WORK / "native-baseline-harness/examples/godot-episode/qualify.py")

archive = OUTPUT / "correction-evidence.zip"
entries = []
with zipfile.ZipFile(archive, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name in sorted(selected):
        assert not name.startswith("/") and ".." not in Path(name).parts
        data = (WORK / name).read_bytes()
        info = zipfile.ZipInfo(name, date_time=(2026, 10, 8, 0, 0, 0))
        info.create_system = 3
        info.external_attr = 0o100644 << 16
        z.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
        entries.append({"path": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

with zipfile.ZipFile(archive) as z:
    assert z.namelist() == [item["path"] for item in entries]
    for item in entries:
        data = z.read(item["path"])
        assert len(data) == item["bytes"] and hashlib.sha256(data).hexdigest() == item["sha256"]

manifest = {
    "schema_version": 1,
    "archive": archive.name,
    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "bytes": archive.stat().st_size,
    "files": entries,
    "reopened_all_files_verified": True,
    "model_trials": 0,
    "selection": "Raw correction probes and controls, actual outputs and errors, native game reports/save JSON/logs, isolated CLI attempt receipts, code gates, exact Assay delta; source game files accompany native reports.",
    "not_included": [
        "Downloaded engine archive/binary; official asset identity and digests retained instead.",
        "Copied Codex binary and closed-root profiles/cache/source copy; per-file source identity and all attempted-command receipts retained.",
        "Reproducible native editor/import caches and empty temporary directories.",
        "Whole original requirements attachments; their exact identities remain in baseline-identity.json.",
        "Future delivery/CI results, which do not yet exist at this evidence freeze.",
    ],
}
(OUTPUT / "correction-evidence-manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(json.dumps({k: v for k, v in manifest.items() if k != "files"}, indent=2))
print("Verified files:", len(entries))
