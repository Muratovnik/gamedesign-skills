"""Retain one final verification command and its raw outputs without retries."""
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument("name")
parser.add_argument("command", nargs=argparse.REMAINDER)
args = parser.parse_args()
work = Path(__file__).resolve().parent
root = work.parent / "gamedesign-skills"
out = work / "final-checks"
out.mkdir(exist_ok=True)
if not args.name.replace("-", "").replace("_", "").isalnum():
    parser.error("invalid record name")
record_path = out / (args.name + ".json")
if record_path.exists():
    parser.error("preserve the prior record; use a new name")
argv = args.command[1:] if args.command[:1] == ["--"] else args.command
start = time.monotonic()
record = {"argv": argv, "cwd": str(root), "started_utc": datetime.now(timezone.utc).isoformat(), "model_trials": 0}
with (out / (args.name + ".stdout")).open("wb") as stdout, (out / (args.name + ".stderr")).open("wb") as stderr:
    result = subprocess.run(argv, cwd=root, stdout=stdout, stderr=stderr, check=False)
record.update(exit_code=result.returncode, elapsed_seconds=round(time.monotonic()-start, 3))
record_path.write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record))
raise SystemExit(result.returncode)
