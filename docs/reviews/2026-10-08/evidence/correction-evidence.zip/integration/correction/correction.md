# Integration correction — Game Design

Date: 2026-10-08. Parent-authorized correction after the frozen shared review,
not a second independent review.

Frozen review: `docs/reviews/2026-10-08/review-game-design-project.md`,
SHA256 `3a83585a31bf5ea3839e7b9edb45f146e0ecd13a2eea0d7938d8b519b1219a10`.
Code baseline: `f9f6bac0ee767597692d5c17d1eecc90f6788aa8`.
Shared branch: `review/game-design-correction-2026-10-08`.
Expected effect: **change_required**.

## Result and acceptance boundary

| Subject | Correction | Current evidence |
| --- | --- | --- |
| GD-I01 | Concrete native lifecycle instructions, generated local marketplaces, and exact archive inclusion added | Local metadata and packaging controls pass. Native client qualification remains open until actual receipts establish its respective stages. |
| GD-I02 | A required-resource symlink loop now produces unavailable JSON/exit 2 | The CLI regression failed before the fix with the reviewed traceback and passes afterward. Valid, changed, missing, disabled and missing-owner results remain distinct. |
| Assay current source | Binding advanced to reviewed Assay 0.17.2, commit `94c517b0aac9ba2575086bf9aead1cc828aadb0d` | Historical seven-file delta checked; current changed owners and a conditional reference verified and read through the shipped CLI. |

The old 0.17.1 pin was a deliberate compatibility condition, not a defect merely
because a newer release exists. No broad model-quality or native-discovery claim
follows from this update. The complete U18 lifecycle obligation has not been
waived. The separately authorized closed-root native Codex probe ended at a
runtime setup blocker before registry or package metadata handling. Its final
receipt is recorded below; it does not qualify the package's native lifecycle.

## GD-I01: selected mechanisms and ownership

`tools/render.py` now derives two local marketplaces in addition to the existing
portable and Claude manifests. Both identify `game-design@game-design-source`.
The Codex entry uses `source: {source: "local", path: "./"}`, explicit
`AVAILABLE`/ `ON_INSTALL` policy and a category; the Claude entry uses
`source: "./"` and required marketplace ownership metadata. The source is the
package root, preserving the complete seven-skill install unit. The original two
plugin manifests remain byte-identical.

The native managers own registration, configuration and cache lifecycle. The
package does not add an installer, hook, MCP service, global registration script
or model invocation. Documentation gives path setup, listing before changes,
exact identities, conflict handling, explicit Claude local scope, Codex project
enable control, removal and retained-copy update/rollback. It addresses existing
disabled state, partial failures, other consumers of the same native identity,
and rollback to an older source that predates native packaging.

`tools/check.py` uses the existing JSON Schema library to enforce this chosen
one-bundle local route, including its exact source, identity and explicit install
policy. This is a project delivery contract, not a replacement for every client
schema or a claim of native acceptance.

`tools/package.py` admits only the exact
`.agents/plugins/marketplace.json` exception. It checks all of that file's path
components for symlinks/reparse points and keeps sibling client state and skills
excluded. Output validation also refuses that newly public path as an archive or
receipt destination. The existing archive test now asserts both marketplace
files are actually delivered; the parent owns the final full archive/gate run.

Reuse: native Codex and Claude plugin managers; standard-library path/JSON/hash
operations; existing `jsonschema` for the narrow generated-route contract.
No new dependency or independent install-state mechanism was added.

### Primary interface basis

- [Codex plugin packaging and local marketplaces](https://developers.openai.com/plugins/build/plugins):
  portable `plugin.json`, conventional root `skills/`, marketplace-root relative
  source paths and project enable configuration. Existing manifests do not need
  a duplicate `skills` field.
- Actual `/opt/codex/bin/codex` **0.159.2** help: plugin add/list/remove and
  marketplace add/list/upgrade/remove. Correction logs include the additional
  exact help invocations; the review logs retain the earlier version and command
  inventory. The CLI's `--disable` switches features, not a plugin.
- [Claude local marketplace source](https://code.claude.com/docs/en/plugin-marketplaces):
  local relative plugin source and marketplace-root resolution.
- [Claude installation scopes](https://code.claude.com/docs/en/discover-plugins):
  local/project/user effects and shared-state considerations.
- [Claude CLI reference](https://code.claude.com/docs/en/plugins/cli-reference):
  explicit scope arguments, lifecycle commands and v2.1.289 support for validating
  a root with both marketplace and plugin manifests.
- [Claude marketplace fields](https://code.claude.com/docs/en/plugins/marketplace-reference):
  ownership, source and version metadata.

These first-party documents were read on 2026-10-08. The Claude version is a
documented interface baseline, not an observed installed binary. No third-party
game-design pack was consulted or used as a reference.

## GD-I02: failure classification

The repair stays inside `checked_bytes`: `RuntimeError` from strict path
resolution joins the unavailable-resource exception conversion. It does not
relax hashes, revision checks, enabled-state handling or the path boundary.

`tests/test_assay_binding.py` runs a copied, unchanged CLI implementation against
synthetic disposable owner resources and a valid fixture binding. The symlink
case asserts the public exit status, JSON state/reason and empty stderr. Its
normal/error sequence also confirms that an unused owner's absent resources are
not made mandatory. Existing distribution tests retain checks for relocated
method/reference reads, changed bytes, missing/extra resources, disabled sources,
unrelated work and path escape.

The first CLI regression run failed only the cyclic-resource case; the
valid/changed/missing/disabled/missing-owner sequence passed. Both tests passed
after the fix and after the fixture's unused digest was made syntactically valid.
There were no skips on the observed Linux/Python 3.12.14 environment.

## Reviewed Assay update

The GitHub compare response establishes the exact 0.17.1→0.17.2 commit relation.
Only metadata for evaluator paths was returned; evaluator contents were not
read. The seven changed runtime files were fetched at the old immutable commit
through the GitHub connector. Their decoded SHA256 values match the shipped old
binding, and their Git blob SHAs were independently checked.

The delta concerns selecting relevant content/depth and keeping content review
within its scope. It does not change owner names, resource paths or the
composition interface. Copyedit and preserve-all authority remain bounded.
Twelve other owners and the identity catalog/license were unchanged in the
frozen review's byte comparison. This supports adopting the current source for
this consumer contract; it does not establish a behavioral improvement.

The existing updater was run with the exact clean current checkout and revision.
Current README, compatibility, Russian quick start and consumer contract now
agree with the regenerated binding. No active old-pin reference remains in the
searched current documentation/runtime Markdown; historical review/release records
were not rewritten by this worker.

## Executed verification

Raw command metadata, stdout and stderr are under `logs/`. Key observations:

| Evidence | Result |
| --- | --- |
| Frozen review SHA and original source HEAD preflight | Match |
| Historical writing-file decode, SHA256 and blob SHA comparison | 7/7 match old pin |
| `binder-regression-before` | Expected failure: symlink loop exits 1 with traceback |
| `binder-regression-after`, `binder-final-fixture` | 2 tests pass, no skips |
| `targeted-distribution` | 14 tests pass, including metadata negative controls and exact public-file/private-state pair |
| `generated-projection-check` | Current; no stale projections |
| Current technical-writing method and conditional document-design read | Exit 0, exact source text; 19 files checked per selected owner |
| Current text-writing method read | Exit 0, exact source text; 12 files checked |
| Edited-document links and example syntax | 5 documents, 42 local links, 12 Bash blocks, 1 TOML block; no errors |
| Changed source preflight and scoped whitespace check | AST parsing and `git diff --check` pass |
| Current Assay HEAD and worktree | Exact `94c517b…`, clean |

The documentation check parses Bash with `bash -n` and TOML with `tomllib`; it
does not execute installation examples. The actual source read matches are
recorded in `current-assay-reading.json`.
`assay-writing-delta.json` and `assay-writing-delta.diff` retain the bounded
historical comparison. The helper reads the old binding via `git show` of the
frozen baseline so it remains reproducible after the binding update.

## Final native receipt boundary

The parent-authorized `/root/domain_review` qualification packet is preserved in
`review-work/native-client-isolation/native-outcome.md`, with raw JSON, stdout
and stderr. This worker read the outcome and these actual receipts:

| Receipt label | Observed result | Acceptance boundary |
| --- | --- | --- |
| `native-version-v2` | Copied Codex reports `codex-cli 0.159.2`, exit 0, after closed-root guards | Binary execution only |
| `native-marketplace-list-initial` | `plugin marketplace list --json` exits 1 during bootstrap: missing `/proc/self/exe` | No registry result; Game Design metadata was not reached |
| `native-version-v3-proc` | A fresh namespace-local procfs mount returns `EPERM`; launcher exits 125 with child 1 before client execution | Final authorized setup blocker; no procfs isolation claim and no further attempt |

The copied source snapshot contains 151 files with tree SHA256
`8432c26c6e764fd5a78404f5c7ad2a217217abf5e57d870405044a591e825335`;
per-file identity is retained in `native-source-identity.json`. No registration,
install, effective enable/disable, update, remove or rollback ran. The result
neither accepts nor rejects marketplace metadata. The colleague's evidence
allowlist excludes copied binaries, source snapshots, profiles and caches.
Product documentation now records this exact boundary without claiming native
support. No model run or working-client configuration access occurred.

Final documentation freeze followed `final-native-documentation-check` and
`final-native-doc-whitespace`, both exit 0. The former covered five documents,
42 local links, 12 Bash blocks and one TOML block. These final checks did not run
the installation commands or repeat the shared full gate. No further source
edits are planned by this worker.

## Remaining work and handoff

The parent owns final combined static/release/archive gates after the shared
candidate settles, including the updated archive test. The complete archive
suite was not repeated here while other workers were changing its input set.

Native qualification still needs actual stages and preserved outputs for the
selected client/build, including effective disable, installed resources, update
and restoration. Model selection, model-quality trials and human experience are
separate, unrun boundaries. Windows is not qualified by these Linux checks.
The completed closed-root diagnostic above establishes the binary version and
the setup blocker; those lifecycle gaps remain open. Further native acceptance
needs an authorized environment that can meet the client's runtime needs and
preserve the complete isolation boundary.

No working client installation or settings were inspected or modified by this
worker. No model runs, new agents, commits, pushes, publication, VERSION edits or
historical CHANGELOG edits were performed. Other workers' source/report changes
were left in place. The independent review remains frozen.

Task-owned source paths: README; installation/compatibility/Russian quick-start
docs; consumer contract; binder and binding; render/check/package tools;
test_assay_binding and the indicated distribution tests; the two generated
marketplace files. Source changes are ready for the parent's combined gate and
integration.

