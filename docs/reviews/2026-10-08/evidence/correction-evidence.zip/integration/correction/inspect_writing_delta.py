"""Compare only the seven changed runtime resources with the shipped old pin."""
import base64
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parents[2] / 'gamedesign-skills'
CURRENT = ROOT.parents[2] / 'assay-current'
baseline = 'f9f6bac0ee767597692d5c17d1eecc90f6788aa8'
binding = json.loads(subprocess.check_output(
    ['git', '-C', str(SOURCE), 'show', baseline + ':skills/game-design/assets/assay-binding.json'],
    text=True,
))
records = json.loads((ROOT / 'historical-assay-fetch.json').read_text())
report, diffs = [], []
for record in records:
    path = record['path']
    result = record['result']
    assert not result.get('isError'), path
    content = result['structuredContent']
    before = base64.b64decode(content['content'])
    old_hash = hashlib.sha256(before).hexdigest()
    expected = binding['owners'][path.split('/')[1]][path]
    assert old_hash == expected, (path, old_hash, expected)
    git_hash = hashlib.sha1(b'blob ' + str(len(before)).encode() + b'\0' + before).hexdigest()
    assert git_hash == content['sha'], path
    after = (CURRENT / path).read_bytes()
    report.append({'path': path, 'historical_url': content['display_url'],
                   'historical_sha256': old_hash, 'historical_binding_match': True,
                   'current_sha256': hashlib.sha256(after).hexdigest()})
    diffs.extend(difflib.unified_diff(before.decode().splitlines(keepends=True),
                                    after.decode().splitlines(keepends=True),
                                    fromfile='Assay-0.17.1/' + path,
                                    tofile='Assay-0.17.2/' + path))
(ROOT / 'assay-writing-delta.json').write_text(json.dumps(report, indent=2) + '\n')
(ROOT / 'assay-writing-delta.diff').write_text(''.join(diffs))
print(json.dumps({'verified_historical_resources': len(report), 'current_root': str(CURRENT)}))
print(''.join(diffs))
