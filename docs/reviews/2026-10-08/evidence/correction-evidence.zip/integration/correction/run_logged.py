#!/usr/bin/env python3
"""Review-only command recorder. No implicit environment or target mutation."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--cwd', required=True)
p.add_argument('label')
p.add_argument('command', nargs=argparse.REMAINDER)
a = p.parse_args()
command = a.command[1:] if a.command[:1] == ['--'] else a.command
outdir = Path(__file__).resolve().parent / 'logs'
outdir.mkdir(parents=True, exist_ok=True)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
result = subprocess.run(command, cwd=a.cwd, capture_output=True)
(outdir / (a.label + '.stdout')).write_bytes(result.stdout)
(outdir / (a.label + '.stderr')).write_bytes(result.stderr)
record = {'label': a.label, 'started_utc': started, 'cwd': a.cwd,
          'argv': command, 'exit_code': result.returncode,
          'stdout': str(outdir / (a.label + '.stdout')),
          'stderr': str(outdir / (a.label + '.stderr'))}
(outdir / (a.label + '.json')).write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
sys.stdout.buffer.write(result.stdout)
sys.stderr.buffer.write(result.stderr)
sys.exit(result.returncode)
