"""Validate edited documentation links and syntax without running its commands."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tomllib
from urllib.parse import unquote, urlsplit

WORK = Path(__file__).resolve().parent
ROOT = WORK.parents[2] / 'gamedesign-skills'
sys.path.insert(0, str(ROOT / 'tools'))
import check

paths = ['README.md', 'docs/installation.md', 'docs/compatibility.md',
         'docs/quickstart.ru.md', 'skills/game-design/references/consumer-and-assay-contract.md']
documents, errors = [], []
for relative in paths:
    path = ROOT / relative
    content = path.read_text()
    links, _ = check.document(content)
    local_links, bash_blocks, toml_blocks = 0, 0, 0
    for link in links:
        parsed = urlsplit(link)
        if parsed.scheme or parsed.netloc:
            continue
        target = (path.parent / unquote(parsed.path)).resolve() if parsed.path else path
        local_links += 1
        if not target.is_relative_to(ROOT) or not target.exists():
            errors.append(f'{relative}: missing/outside {link}')
        elif parsed.fragment and target.suffix == '.md':
            if unquote(parsed.fragment) not in check.document(target.read_text())[1]:
                errors.append(f'{relative}: missing anchor {link}')
    for token in check.MARKDOWN.parse(content):
        if token.type != 'fence':
            continue
        if token.info in {'bash', 'sh'}:
            result = subprocess.run(['bash', '-n'], input=token.content, text=True,
                                    capture_output=True, check=False)
            bash_blocks += 1
            if result.returncode:
                errors.append(f'{relative}: Bash syntax: {result.stderr}')
        elif token.info == 'toml':
            tomllib.loads(token.content)
            toml_blocks += 1
    documents.append({'path': relative, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                      'local_links': local_links, 'bash_syntax_blocks': bash_blocks,
                      'toml_syntax_blocks': toml_blocks})
report = {'documents': documents, 'errors': errors, 'commands_executed': False}
(WORK / 'documentation-check.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
raise SystemExit(bool(errors))
