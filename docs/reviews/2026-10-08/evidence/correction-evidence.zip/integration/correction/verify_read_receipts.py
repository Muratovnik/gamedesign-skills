"""Match the actual binder CLI content to the authorized current Assay files."""
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parent
SOURCE = WORK.parents[2] / 'gamedesign-skills'
ASSAY = WORK.parents[2] / 'assay-current'
binding = json.loads((SOURCE / 'skills/game-design/assets/assay-binding.json').read_text())
cases = [('read-current-writing', 'technical-writing', 'SKILL.md'),
         ('read-current-writing-reference', 'technical-writing', 'references/document-design.md'),
         ('read-current-text', 'text-writing', 'SKILL.md')]
rows = []
for label, method, resource in cases:
    output = json.loads((WORK / 'logs' / f'{label}.stdout').read_text())
    command = json.loads((WORK / 'logs' / f'{label}.json').read_text())
    path = ASSAY / 'skills' / method / resource
    assert command['exit_code'] == 0
    assert output['status'] == 'verified'
    assert output['content'] == path.read_text()
    assert output['sha256'] == hashlib.sha256(path.read_bytes()).hexdigest()
    assert output['assay'] == binding['assay']
    assert output['checked_files'] == len(binding['identity_files']) + len(binding['owners'][method])
    rows.append({'method': method, 'resource': resource, 'exit_code': command['exit_code'],
                 'sha256': output['sha256'], 'checked_files': output['checked_files'],
                 'content_matches_current_source': True})
head = subprocess.check_output(['git', '-C', str(ASSAY), 'rev-parse', 'HEAD'], text=True).strip()
status = subprocess.check_output(['git', '-C', str(ASSAY), 'status', '--porcelain'], text=True)
assert head == '94c517b0aac9ba2575086bf9aead1cc828aadb0d' and not status
report = {'assay': binding['assay'], 'assay_tree_clean': True, 'reads': rows,
          'native_loading': 'not_observed_by_these_commands'}
(WORK / 'current-assay-reading.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
