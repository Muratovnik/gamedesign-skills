# OUTCOME

`complete` — ограниченная advisory-проверка для остатка GD-I01 закончена.
**Поддержанный путь для дальнейшей локальной проверки есть: `unshare` с новым
user/mount/PID/network namespace, затем закрытый task-owned root и сброс
capabilities.** Конкретный fixture подтвердил недоступность внешнего пути и
работоспособность внутренней записи. Это ещё не подтверждение lifecycle Codex.

# EXPECTED EFFECT

`read_only_finding` — исходники, review, Git и рабочие настройки не менялись.
Единственные записанные файлы находятся в
`/workspace/scratch/c4106697b2e8/review-work/native-client-isolation`: receipts,
эта записка и два task-owned контрольных положения файла.

# DELIVERY

## Рекомендуемый ограниченный путь

Использовать фактически прошедшее сочетание:

```text
/usr/bin/unshare --user --mount --pid --fork --net --keep-caps -- <trusted-bootstrap>
```

Успешная проба не применяла UID mapping. Bootstrap запускался с отдельным
окружением, содержащим только `PATH` и `LANG`, из task-owned каталога. Его
стандартные зависимости были загружены до перехода в закрытый root; никакой
Codex или пользовательский plugin-код на этом этапе не запускался.

Дальнейшая последовательность, непосредственно выполненная в fixture:

1. Прочитать внешний **task-owned** marker как положительный контроль исходной видимости.
2. Выполнить `chroot(fixture-root)` и `chdir('/')`. В root присутствуют только marker и рабочий подкаталог.
3. Закрыть дескрипторы 3–255; запуск через `Popen` также использовал стандартное закрытие унаследованных дескрипторов. Для будущего отдельного launcher сохранить явное `close_fds=True`, без передачи host directory descriptors.
4. Установить effective/permitted/inheritable capabilities в ноль, проверить результат через `capget`, установить `no_new_privs`.
5. Проверить видимость внутреннего marker, отсутствие внешнего абсолютного пути, `/proc`, `/root` и `/etc` **внутри fixture root**, отказ записи по внешнему пути и успешную запись `/work/inside-write`.
6. Во внешнем процессе проверить, что внешний marker не изменился, а разрешённая запись появилась внутри task-owned root.

Точный исполненный argv и полный bootstrap сохранены в
`unshare-chroot-fixture.json`. Это воспроизводимый положительный контроль;
условия вывода не сводятся к тому, что `unshare` вернул ноль.

Для будущего запуска native lifecycle бинарный payload должен стартовать
**после** перехода и сброса capabilities. Его filesystem root нужно собирать
из task-owned копий только необходимых файлов. Не подключать host `/`, home,
working configuration или host procfs. Кэш, локальный marketplace и конфигурация
должны находиться внутри этого root. В предоставленном root receipt
`integration/logs/codex-known-path.stdout` известный `/opt/codex/bin/codex`
определён как static-PIE ELF; это уменьшает ожидаемую потребность в системных
библиотеках, но не устанавливает полный набор его runtime-зависимостей.

## Пути, которые не квалифицированы

- **Bubblewrap:** бинарный файл и нужные флаги есть, но выполненная проба не достигла payload. Нельзя рекомендовать эту конкретную конфигурацию как проверенную.
- **`unshare --map-current-user`:** запись `uid_map` запрещена. Положительный результат plain-user namespace не делает mapping работоспособным.
- **Один `CODEX_HOME`:** не является проверенной границей чтения/записи. В положительном fixture host-конфигурация исключена закрытым root и отдельным окружением, а не перенаправлением одной переменной.

# ORACLE

| Наблюдение / receipt | Фактический результат | Допустимый вывод |
| --- | --- | --- |
| `/usr/bin/bwrap --version`, `--help` | bubblewrap 0.9.0; help показывает namespace, mount, `--clearenv`, `--die-with-parent`, `--new-session` | Инструмент и описанный интерфейс доступны; это не доказывает исполнение sandbox. |
| `/usr/bin/unshare --version`, `--help` | util-linux 2.39.3; перечислены `--user`, `--mount`, `--pid`, `--fork`, `--net`, `--keep-caps`, `--root` | Применённые namespace/capability флаги поддержаны интерфейсом. |
| Kernel/process metadata | `max_user_namespaces=2147483647`; два запрошенных optional sysctl пути unavailable. UID/EUID 0, CapEff=0, NoNewPrivs=1, Seccomp=2, один filter | Нельзя заключить доступность namespace по одному лимиту. Конкретное правило seccomp или причина ограничения по этим данным не установлены. |
| `unshare-user.json` | `--user --map-current-user`: exit 1; `unshare: write failed /proc/self/uid_map: Operation not permitted` | UID mapping этого вызова не работает; не общий отказ создания user namespace. |
| `bwrap-minimal.json` | `--unshare-all` с закрытой mount-композицией и printf payload: stdout пуст, `bwrap: open /proc/8/ns/ns failed: No such file or directory`, timeout 10 секунд | Payload не достигнут. Причину сообщения про `/proc` не приписываем kernel/seccomp без дополнительного основания. Этот bwrap-путь не квалифицирован. |
| `unshare-user-unmapped.json` | `--user` без mapping: exit 0, ожидаемый child marker | User namespace без mapping доступен в этой среде. |
| `unshare-required-namespaces.json` | `--user --mount --pid --fork --net`: exit 0, ожидаемый child marker | Совместное создание запрошенных namespaces и запуск child приняты. Само по себе это не демонстрация запрета файловых доступов. |
| `unshare-chroot-fixture.json` | exit 0, без timeout; capabilities=0; внешний marker не виден и не записывается; host `/proc`, `/root`, `/etc` не представлены; внутренний marker читается, запись успешна; внешний marker неизменён | Положительный bounded filesystem isolation control выполнен на конкретном fixture. Это основание для указанного пути, а не для заявления о проверенном Codex lifecycle. |
| `metadata-and-process-check.json` | При проверке не найден live process с точным argv предыдущей bwrap-пробы | Остаточный live процесс с этим argv в момент проверки не наблюдался. Это не полная атрибуция всех возможных потомков. |

Все namespace-пробы имели лимит 5 или 10 секунд. Не применялись установка
инструментов, host privilege escalation, изменение sysctl, профилей seccomp,
рабочего settings либо запрос `require_escalated`.

# SOURCE AND IDENTITY

- Worker: `/root/domain_review`; отдельный advisory packet по GD-I01, не новый общий review.
- Окружение: текущий task workspace `/workspace/scratch/c4106697b2e8`, Linux namespace interface из установленных known-path `unshare` и `bwrap`.
- Источники фактов о native client только ранее сохранённые root logs: `codex-known-path.stdout`, `codex-version.stdout`, `codex-plugin-help.stdout`, `codex-plugin-add-help.stdout`, `codex-plugin-list-help.stdout`, `codex-marketplace-help.stdout`. В них version — `codex-cli 0.159.2`, а marketplace help допускает локальный source.
- Native Codex и plugin commands в этом packet не исполнялись. Private configurations не исследовались; контроль использует собственные markers.
- Исходные репозитории и ранее сохранённые review/evidence артефакты этим worker не изменялись.

# UNRESOLVED

**GD-I01 нельзя закрыть этой запиской.** Не проверены native marketplace
registration, discovery/list, installation, removal, update и их фактическое
размещение в закрытом root. Следующий разрешённый native check потребует
подготовить payload внутри task-owned root и выполнить именно его consumer;
printf и Python fixture этого не заменяют.

Принятие `--net` не проверялось сетевым соединением или отдельным сетевым
fixture. Не проверены все возможные способы escape, поведение произвольного
враждебного кода, host namespace implementation или полный контракт очистки
всех процессов. Положительный вывод ограничен приведённой файловой границей
и конкретной операцией записи. Ни отсутствие model call, ни отсутствие
working-client writes не следует только из имени будущей команды: в native
проверке нужно сохранить закрытый root, ограниченный payload и тот же scope.
