# OUTCOME

`complete` — выполнена разрешённая ограниченная диагностика и достигнуто явное
условие остановки. **Native Codex lifecycle остаётся непроверенным.** Рабочий
бинарный файл запускается в закрытом root, но registry-команде нужен
`/proc/self/exe`; попытка предоставить настоящий изолированный procfs получила
`EPERM`. Это ограничение проверенного setup, не опровержение metadata Game Design.

# EXPECTED EFFECT

`no_change_acceptable` по исходному репозиторию. Изменений репозитория от этого
packet нет. Все записи сделаны в
`/workspace/scratch/c4106697b2e8/review-work/native-client-isolation`.

# DELIVERY

Сохранены source identity, исходные receipts/stdout/stderr, три версии launcher
и последний точный blocker. Перечень разрешённых для передачи evidence файлов —
`evidence-allowlist.txt`; пути в нём разрешаются относительно этой директории.
**Копированный binary, `native-root`, временные profiles/caches и fixture trees
в этот перечень не входят.**

## Подготовленный payload

- Из known path `/opt/codex/bin/codex` скопирован binary с SHA256 `1748767b230ebfc3d4ab7e4e254920d0c0ad9691fd8c11f190e7d44511a4a92e`; копия совпала с оригиналом.
- `readelf -l -d` завершился с exit 0: нет ELF interpreter и `NEEDED` libraries. Дополнительные динамические библиотеки не потребовались для фактически выполненного `--version`.
- Candidate A содержит все tracked и неигнорируемые untracked исходные файлы Game Design, включая семь skills и `.agents/plugins/marketplace.json`. Git-метаданные и игнорируемые временные outputs не копировались.
- Снимок из 151 файла совпал с source непосредственно до и после копирования. Tree SHA256: `8432c26c6e764fd5a78404f5c7ad2a217217abf5e57d870405044a591e825335`; точные per-file hashes находятся в `native-source-identity.json`.
- Внутренние user/config/cache директории созданы пустыми. Окружение native payload задано явно для внутренних путей; credentials, host home/settings и полное рабочее окружение не передавались.

# ORACLE

## Последовательность и достигнутые границы

| Receipt label | Фактический результат | Граница вывода |
| --- | --- | --- |
| `native-version` | Wrapper exit 125, child exit 1; необязательный `socket.if_nameindex()` получил `EPERM` до chroot/exec. `isolation_control_reached=false`. | Ошибка дополнительного preflight, Codex не запущен. Исходный launcher сохранён как `native_probe_v1.py`, receipt не переписан. |
| `native-version-v2` | Exit 0, `codex-cli 0.159.2`; обязательные isolation guards достигнуты. CLI предупреждает о недоступном `/proc/self/exe` для PATH aliases. | Копированный native binary реально исполняется в закрытом root. Это не registry discovery или model skill loading. |
| `native-marketplace-list-initial` | Exit 1 после успешных guards. Команда: `plugin marketplace list --json`. Ошибка: `failed to load bootstrap configuration`; причина: `no /proc/self/exe available. Is /proc mounted?` | CLI достигнут, но native registry результат отсутствует. Candidate marketplace ещё не регистрировался, metadata не была проверена этим consumer. |
| `native-version-v3-proc` | Wrapper exit 125, child exit 1; `PermissionError: [Errno 1] mounting own procfs failed`. Payload не запущен. | Настоящий procfs mount недоступен в разрешённом setup. Это окончательное условие остановки root; иных обходов и escalation не было. |

V2 исправил только обработку необязательного перечисления интерфейсов: `EPERM`
сохраняется как unavailable. `--net` и все обязательные guards остались. V2
сохранён отдельно как `native_probe_v2.py` до последнего разрешённого setup.
Текущий `native_probe.py` содержит V3 с настоящим mount и обязательными proc
guards; он не подменяет procfs файлом или symlink.

## Изоляция и остановка

Каждый native payload был зафиксирован как запуск через
`unshare --user --mount --pid --fork --net --kill-child --keep-caps`.
До `execve` bootstrap переходил в task-owned root, закрывал дополнительные
дескрипторы, сбрасывал effective/permitted/inheritable capabilities в ноль,
проверял это через `capget` и устанавливал `no_new_privs`. Подтверждались
внутренний marker, недоступность внешнего абсолютного пути и отказ записи
по нему. Host `/root`, host settings и host procfs не подключались.

V3 пытался смонтировать `proc` на новый пустой внутренний `/proc` уже после
создания собственных user/mount/PID namespaces и до capability drop. Flags —
`MS_NOSUID | MS_NODEV | MS_NOEXEC`. После mount предполагалось обязательное
подтверждение PID 1, единственного видимого payload PID и закрытого
`/proc/1/root` по внутреннему/внешнему marker. **Эти post-mount guards не
достигнуты: сам mount вернул EPERM.** Изоляция procfs не объявляется доказанной.

При финальном вызове оба внешних task-owned контроля остались неизменными;
внешний каталог `native-root/proc` остался пустым. Timeout не наступал ни в одном
native payload вызове. Настроенные deadlines были 30 или 40 секунд; каждый
launcher имел отдельную session/process group и bounded cleanup. Исходная
advisory bwrap-проба с timeout сохранена отдельно, она не является успешным
native launcher.

# SOURCE AND IDENTITY

- Worker: `/root/domain_review`; source writer отсутствует, роль — scoped native qualification для GD-I01.
- Source root: `/workspace/scratch/c4106697b2e8/gamedesign-skills`; snapshot HEAD `f252043c28fb13905b456a9d7ab9bb7ab7d0f740` плюс указанный в identity фактический candidate tree. HEAD не выдается за идентификатор dirty snapshot.
- Marketplace в snapshot: `game-design-source`; plugin selector `game-design@game-design-source`; source `{ "source": "local", "path": "./" }` сохранён относительно полного candidate root.
- Установленные isolation tools: unshare util-linux 2.39.3 и bubblewrap 0.9.0. Bwrap не прошёл собственную advisory-пробу и в native попытках не использовался.
- Подготовительная feasibility-записка — `advisory.md`; она квалифицирует только её filesystem fixture. Более поздний native blocker имеет отдельные receipts и не стирает прежний результат.
- Передача product facts выполнена `/root/integration_review`; изменения metadata/docs принадлежат этому owner, не этому worker.

# UNRESOLVED

Не исполнены marketplace registration, local plugin install, installed listing,
config-controlled enable/disable, update, remove или rollback. Native методы не
установлены ни в рабочий клиент, ни через plugin install во временный клиент.
**Native lifecycle часть GD-I01 остаётся непроверенной; этот probe не даёт
нового FAIL для marketplace metadata.** Статическую correction принимает
владелец общего review по её собственным свидетельствам.

Обычные Codex/exec/chat/model команды и API generation не запускались: **0
модельных запусков**. Не проверялись automatic skill selection, фактическая
загрузка reference моделью или польза метода. Команды remote marketplace/auth
и обходы сетевой изоляции не выполнялись. `EPERM` при mount не
приписывается конкретному kernel/seccomp правилу без дополнительного основания.

Дальнейшей диагностики этим worker не требуется и не выполняется: root принял
окончательный blocker. Рабочие profiles/settings, исходный review, Git и
репозиторий остаются вне write scope этого packet.
