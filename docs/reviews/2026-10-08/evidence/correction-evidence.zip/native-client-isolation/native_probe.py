"""Task-owned launcher for the authorized non-model native plugin probe."""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys


BASE = Path('/workspace/scratch/c4106697b2e8/review-work/native-client-isolation')
ROOT = BASE / 'native-root'
CHILD = r'''
import ctypes
import json
import os
import socket
import sys

root, outside_marker, *command = sys.argv[1:]
libc = ctypes.CDLL(None, use_errno=True)
class Header(ctypes.Structure):
    _fields_ = [('version', ctypes.c_uint32), ('pid', ctypes.c_int)]
class Data(ctypes.Structure):
    _fields_ = [('effective', ctypes.c_uint32), ('permitted', ctypes.c_uint32), ('inheritable', ctypes.c_uint32)]

with open(outside_marker) as source:
    assert source.read() == 'native-outside-unchanged\n'
try:
    interfaces = socket.if_nameindex()
except OSError as error:
    interfaces = None
    interface_enumeration = {'status': 'unavailable', 'errno': error.errno, 'message': str(error)}
else:
    assert all(name == 'lo' for _, name in interfaces), ('unexpected network interface', interfaces)
    interface_enumeration = {'status': 'observed', 'interfaces': interfaces}
libc.mount.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_ulong, ctypes.c_void_p]
libc.mount.restype = ctypes.c_int
if libc.mount(b'proc', os.fsencode(root + '/proc'), b'proc', 2 | 4 | 8, None) != 0:
    raise OSError(ctypes.get_errno(), 'mounting own procfs failed')
os.chroot(root)
os.chdir('/work')
os.closerange(3, 256)
header = Header(0x20080522, 0)
zero_caps = (Data * 2)()
if libc.capset(ctypes.byref(header), ctypes.byref(zero_caps)) != 0:
    raise OSError(ctypes.get_errno(), 'capability drop failed')
if libc.prctl(38, 1, 0, 0, 0) != 0:
    raise OSError(ctypes.get_errno(), 'no-new-privileges failed')
observed = (Data * 2)()
if libc.capget(ctypes.byref(header), ctypes.byref(observed)) != 0:
    raise OSError(ctypes.get_errno(), 'capability observation failed')
assert all(item.effective == item.permitted == item.inheritable == 0 for item in observed)
with open('/probe-inside-marker') as source:
    assert source.read() == 'native-inside-fixture\n'
with open('/work/unrelated-marker') as source:
    assert source.read() == 'unrelated-work-unchanged\n'
assert not os.path.exists(outside_marker)
assert not os.path.exists('/root')
visible_pids = sorted(int(name) for name in os.listdir('/proc') if name.isdigit())
assert os.getpid() == 1 and visible_pids == [1], ('unexpected PID namespace view', os.getpid(), visible_pids)
with open('/proc/1/root/probe-inside-marker') as source:
    assert source.read() == 'native-inside-fixture\n'
assert not os.path.exists('/proc/1/root' + outside_marker)
try:
    with open('/proc/1/root' + outside_marker, 'x') as destination:
        destination.write('unexpected proc-root escape\n')
except FileNotFoundError:
    pass
else:
    raise AssertionError('outside path writable through proc root')
assert os.listdir('/etc') == []
try:
    with open(outside_marker, 'x') as destination:
        destination.write('unexpected escape\n')
except FileNotFoundError:
    pass
else:
    raise AssertionError('outside path writable')
print('ISOLATION_CONTROL ' + json.dumps({
    'closed_root': True, 'outside_marker_visible': False,
    'outside_write_blocked': True, 'capabilities': 0, 'no_new_privs': True,
    'network_interface_enumeration': interface_enumeration, 'host_proc_exposed': False,
    'fresh_proc_mounted': True, 'visible_pids': visible_pids,
    'proc_pid1_root_is_fixture': True, 'proc_root_outside_write_blocked': True,
    'host_home_exposed': False, 'host_etc_exposed': False,
}), file=sys.stderr, flush=True)
payload_environment = {
    'PATH': '/opt/codex/bin:/usr/bin:/bin',
    'HOME': '/home/probe',
    'CODEX_HOME': '/home/probe/.codex',
    'XDG_CONFIG_HOME': '/home/probe/.config',
    'XDG_CACHE_HOME': '/home/probe/.cache',
    'LANG': 'C', 'TERM': 'dumb',
}
os.execve('/opt/codex/bin/codex', ['/opt/codex/bin/codex', *command], payload_environment)
'''


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', required=True)
    parser.add_argument('--timeout', type=int, default=40)
    parser.add_argument('command', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ['--'] else args.command
    if not 1 <= args.timeout <= 50:
        parser.error('deadline must be between 1 and 50 seconds')
    if not args.name.replace('-', '').replace('_', '').isalnum():
        parser.error('invalid receipt name')
    allowed = command == ['--version'] or (
        command[:1] == ['plugin'] and len(command) > 1
        and command[1] in {'list', 'add', 'remove', 'marketplace'}
        and (command[1] != 'marketplace' or (len(command) > 2 and command[2] in {'add', 'list', 'remove'}))
    )
    if not allowed:
        parser.error('only the authorized non-model version/plugin operations are allowed')
    receipt_path = BASE / ('native-' + args.name + '.json')
    if receipt_path.exists():
        parser.error('receipt already exists; preserve original results')
    outside = BASE / 'native-outside-marker'
    unrelated = ROOT / 'work/unrelated-marker'
    assert outside.read_text() == 'native-outside-unchanged\n'
    assert unrelated.read_text() == 'unrelated-work-unchanged\n'
    assert list((ROOT / 'proc').iterdir()) == []
    argv = [
        '/usr/bin/unshare', '--user', '--mount', '--pid', '--fork', '--net',
        '--kill-child', '--keep-caps', '--', sys.executable, '-I', '-S', '-c',
        CHILD, str(ROOT), str(outside), *command,
    ]
    process = subprocess.Popen(
        argv, cwd=BASE, env={'PATH': '/usr/bin:/bin', 'LANG': 'C'},
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        start_new_session=True, close_fds=True,
    )
    timed_out = False
    try:
        stdout, stderr = process.communicate(timeout=args.timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGKILL)
        stdout, stderr = process.communicate(timeout=3)
    (BASE / ('native-' + args.name + '.stdout')).write_bytes(stdout)
    (BASE / ('native-' + args.name + '.stderr')).write_bytes(stderr)
    receipt = {
        'name': args.name, 'command': command, 'namespace_argv': argv,
        'outer_pid': process.pid, 'timeout_seconds': args.timeout,
        'returncode': process.returncode, 'timed_out': timed_out,
        'isolation_control_reached': b'ISOLATION_CONTROL ' in stderr,
        'outside_marker_unchanged': outside.read_text() == 'native-outside-unchanged\n',
        'unrelated_marker_unchanged': unrelated.read_text() == 'unrelated-work-unchanged\n',
        'outer_proc_directory_empty': list((ROOT / 'proc').iterdir()) == [],
        'stdout': stdout.decode('utf-8', errors='replace'),
        'stderr': stderr.decode('utf-8', errors='replace'),
    }
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({key: value for key, value in receipt.items() if key != 'namespace_argv'}))
    if not receipt['isolation_control_reached'] or not receipt['outside_marker_unchanged'] or not receipt['unrelated_marker_unchanged'] or not receipt['outer_proc_directory_empty']:
        return 125
    if timed_out:
        return 124
    return process.returncode if process.returncode >= 0 else 128 - process.returncode


if __name__ == '__main__':
    raise SystemExit(main())
