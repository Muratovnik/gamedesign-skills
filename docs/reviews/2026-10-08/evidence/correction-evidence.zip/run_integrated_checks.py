"""Capture the candidate's source and deterministic test gates; no model runner."""
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

WORK = Path(__file__).resolve().parent
ROOT = WORK.parent / "gamedesign-skills"
OUT = WORK / "integrated-checks"
PYTHON = WORK / "venv/bin/python"
OUT.mkdir(exist_ok=False)

groups = {
    "structure": ["tools/check.py"],
    "distribution": ["-m", "unittest", "discover", "-s", "tests", "-v"],
    "adaptation": ["-m", "unittest", "discover", "-s", "examples/adaptation", "-p", "test_*.py", "-v"],
    "analysis-lab": ["-m", "unittest", "discover", "-s", "examples/analysis-lab", "-p", "test_*.py", "-v"],
    "godot-report-contract": ["-m", "unittest", "discover", "-s", "examples/godot-episode", "-p", "test_*.py", "-v"],
    "loom": ["-m", "unittest", "discover", "-s", "examples/design-studies/harbour-of-echoes", "-p", "test_*.py", "-v"],
}
env = os.environ.copy()
env["PYTHONDONTWRITEBYTECODE"] = "1"

def run(item):
    name, arguments = item
    argv = [str(PYTHON), "-B", *arguments]
    start = time.monotonic()
    with (OUT / (name + ".stdout")).open("wb") as stdout, (OUT / (name + ".stderr")).open("wb") as stderr:
        result = subprocess.run(argv, cwd=ROOT, env=env, stdout=stdout, stderr=stderr, check=False)
    receipt = {"name": name, "argv": argv, "cwd": str(ROOT), "exit_code": result.returncode,
               "elapsed_seconds": round(time.monotonic() - start, 3), "model_trials": 0}
    (OUT / (name + ".json")).write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt), flush=True)
    return receipt

# The suites create separate temporary directories; modest parallelism keeps
# native engine timing and the host load interpretable.
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
    results = list(pool.map(run, groups.items()))
(OUT / "summary.json").write_text(json.dumps(results, indent=2) + "\n")
raise SystemExit(int(any(result["exit_code"] for result in results)))
