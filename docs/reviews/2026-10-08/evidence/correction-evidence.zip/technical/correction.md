# Технический correction packet: Game Design

Дата: 2026-10-08. Writer: `/root/technical_review`.

## Итог и граница решения

GD-T01, GD-T02, GD-T03, GD-T04 и GD-T05 исправлены в согласованной области владения. Выполнены 14 аналогов исходных технических проб, 55 тестов в шести целевых наборах и дополнительная различающая пара для владельцев/истории в GD-T03. Все ожидаемые коды и проверки артефактов совпали. `git diff --check` для области изменений завершился с кодом 0. Код стабилен для интеграции root; этот packet не является вторым общим review.

Основание — замороженный review `gamedesign-skills/docs/reviews/2026-10-08/review-game-design-project.md`, SHA-256 `3a83585a31bf5ea3839e7b9edb45f146e0ecd13a2eea0d7938d8b519b1219a10`, ожидаемый эффект `change_required`. Исходные игровые bytes относятся к `f9f6bac0ee767597692d5c17d1eecc90f6788aa8`. Новые коммиты root с review/evidence сами по себе не переопределяют эту идентичность.

Применены прочитанные критерии Assay `94c517b0aac9ba2575086bf9aead1cc828aadb0d`: `code-change/SKILL.md`, `test-writing/SKILL.md`, `test-audit/SKILL.md`; references `verification-scope`, `runtime-boundaries`, `diagnostic-reproducer`, `boundary-choices`, `suite-maintenance`, `discriminating-probes`. Решение опирается на установленные предметные требования знания/действия, фактический consumer, сохраняемую идентичность входов и различение поддержанного свойства, его опровержения и непригодных данных. План или прежний положительный отчёт не использовались как oracle.

Изоляция обеспечивалась **инструкцией**, отдельными owned scratch каталогами и `PYTHONDONTWRITEBYTECODE=1`; это **не технический OS sandbox**. Подагенты, модельные/поведенческие прогоны, установки и изменение системных настроек не выполнялись. Git не изменялся этим writer: root интегрирует и коммитит результат.

## Изменения по находкам

### GD-T01 — определение измерения до создания базы

`examples/analysis-lab/telemetry.py:25` теперь проверяет для каждого объявленного build, что outcome и используемые SQL события `action_accepted` / `episode_end` входят в `allowed_events`. Проверка выполняется до чтения строк и создания выходной SQLite базы. Общая JSON Schema остаётся проверкой формата; межполевая семантика принадлежит фактическому consumer.

Тот же замороженный `dictionary-unknown-outcome.json` больше не превращает два известных исхода в две неудачи: исходный код возврата 0 сменился на 2, база и отчёт отсутствуют. Корректный контроль сохраняет success=1, failure=1, unknown=2, not_attempted=1 и долю 0.5. Новый тест также допускает согласованное переименование outcome и отличает отсутствие наблюдённого, но корректно объявленного outcome: последнее даёт реальные failure=2, а не invalid.

Проверки: `test_measurement_and_eligibility.py:28,44`; сырые CLI пары `logs/replay-telemetry-{valid,invalid-definition}.*`.

### GD-T02 — общие условия выбора и изменения состояния

`examples/analysis-lab/content_rules.py:11,20` владеет проверкой репертуара и единым predicate причин отказа: активность, факты, разблокировки, права, история. Проекция наблюдателя перенесена без изменения её логики в `state.py:112`; `consumer.py:15` использует её и общие правила. Это устраняет цикл зависимостей между state и consumer.

`state.py:138` для новой recovery читает действительный content-файл, проверяет обе необходимые salvage-возможности — Bo/`operate-winch` и Cy/`chart-route` — и применяет те же условия. `lab.py:32` добавляет необязательный `--content` с явным default `fixtures/content.json` рядом с consumer. Интерпретация новой попытки записывает абсолютный путь и SHA-256 в `content_input`; финальный receipt отдельно сохраняет идентичность входного save. Документация описывает оба входа.

Bo без `winch-procedure` по-прежнему выбирает доступную `chart-route`, но recovery теперь возвращает 1 и не пишет новое сохранение. Корректная recovery возвращает 0 и производит **байт-в-байт прежнее игровое сохранение**: scrap `4 + 2 - 6 = 0`, генератор восстановлен. Публичная процедура является допустимым знанием. Явно переданный альтернативный репертуар может разрешить действие с помощью; его hash отражён в CLI. Новые требования права и истории одновременно влияют на choice и recovery. Отсутствующая в репертуаре необходимая action — непригодное свидетельство, код 2.

Подтверждённый историей повтор распознаётся **до чтения текущего репертуара**, возвращает `already_applied`, не меняет текущее состояние, не читает даже недоступный content-файл и не выдумывает hash такого чтения. Прежние проверки поздней потери генератора, нового treasurer, изменённого stock/yield и отсутствующего участника сохранились.

Проверки: `test_measurement_and_eligibility.py:81,98,112,129`, весь прежний `test_input_and_replay.py` и `test_semantics.py`; сырые пары `logs/replay-{choose,recover}-{valid,no-knowledge}.*`.

### GD-T03 — наблюдённые операции и сохранённые отношения

`examples/godot-episode/qualify.py:123` добавляет ограниченную проверку протокола отчёта. Она связывает event sequence, fixture-loaded identity и injected input с выполненной частью fixture schedule; сверяет счётчик received; требует соответствующие deliveries и outcomes для save/reset/load/interact; не принимает неподтверждённые или неоднозначные state outcomes. Top-level reload/NPC summaries должны совпадать с наблюдёнными событиями. Недоступный native save/load возвращает 2.

Escape опирается на наблюдённую последовательность save → reset → restore и соответствующую сохранённую snapshot. Для знания нужен последующий ответ keeper, в котором использован факт из сохранённого состояния. Сохраняемые owners/history/knowledge сверяются с downstream состоянием. Допускаются существующие эффекты сцены после load: новые `gate_crossed` и `knowledge_acquired` события могут дополнить историю и знания. Это локальная проверка отношений данного consumer, не полный replay-интерпретатор и не аутентификация отчёта.

Исходный report с удалёнными state-командами и outcomes при сохранённых положительных summaries сменил код 0 на 2. Byte-preserved корректный recorded report сохранил 0. Согласованные typed-negative restore и NPC observations дают 1. Неполные/противоречивые данные дают 2. Фикстура без расписанных действий остаётся допустимым опровержением escape с кодом 1.

Внутри correction root указал соседний случай того же GD-T03: `saved_state.right_owners` либо сохранённая история противоречат final state, несмотря на согласованные положительные reload flags. Перед дополнительной правкой сохранены три synthetic пробы `pre-relation-*`: изменённый owner, отсутствующий `archive-message`, дублированный `archive-message` — каждая давала 0. Тот же JSON после проверки отношений даёт 2 (`post-relation-*`). Контроль законных после-load добавлений остаётся валидным; новые знания не выдаются за восстановленные и дают 1 для соответствующего claim.

Проверки: `test_report_contract.py:37,51,66,85,99,116,132`; сырые `logs/replay-assess-*`, `logs/pre-relation-*`, `logs/post-relation-*`; дополнительные входы `fixtures/report-saved-*.json` явно помечены как synthetic, не native execution.

### Tick 0 — минимальный выполнимый контракт

`skills/game-design/assets/episode.schema.json:166` требует `warning_tick >= 1`: исходная native сцена начинает автоматическую обработку после увеличения clock. `qualify.py:35` одинаково для run/assess требует различные threat IDs и `warning_tick <= resolve_tick <= stop_tick`. Предупреждение и разрешение на одном tick допустимы: warning происходит перед player step, resolution после него.

Замороженная tick-0 проба меняет schema validation с 0 на 2. Отдельно проверены валидные `(warning, resolve)=(1,26)` и `(1,1)`, недопустимый обратный порядок и выход resolution за horizon. CLI отклоняет эти входы до обращения к отсутствующему engine и до создания output. Команды после `stop_tick` явно остаются вне выполненного input population.

Нативные source bytes ради этой границы не менялись. Свежий native receipt не подделывался и исторический отчёт не перезаписывался.

### GD-T04 — предъявленные и исполнимые pin-действия

`examples/adaptation/consumer.py:57` теперь добавляет pin-action в `permitted_actions` только при `aid: line-pins`. Оба layout поддержаны одним условием. Без aid carousel сохраняет navigation, оба layout сохраняют выбор направления. Pin по-прежнему отклоняется с кодом 2; обычный ход исполняется с кодом 0.

Корректные версии с постоянной помощью сохранены. Прежний no-aid view теперь возвращает `next-line`, `choose-direction` без недоступного pin. Проверки: `test_adaptation.py:53` и весь прежний набор; CLI `logs/replay-adaptation-without-pins-*`.

### GD-T05 — форма Loom до файловых эффектов

`examples/design-studies/harbour-of-echoes/render_loom.py:26` проверяет объект root, массивы объектов phrases/sections, непустую revision и числовой one-second beat до создания output directory. Boolean вместо числа отклоняется. Корректное `1.0` и дополнительные authored metadata допустимы.

Исходный `[]` теперь возвращает 2 без traceback и без output directory. Новый `test_render_loom.py:32,54` проверяет malformed containers/identity и открывает созданные WAV/CSV. Обе WAV остаются mono PCM16, 24 kHz, 288000 frames, 12 s; проверяются звучащие интервалы и явные паузы. Обе WAV и обе visual CSV в CLI replay **байт-в-байт совпали** с исходными корректными артефактами. Renderer hash в новом receipt закономерно изменился.

Новый test path передан root для включения в CI/CONTRIBUTING; эти общие файлы принадлежат root.

## Полный список изменённых файлов

- `examples/analysis-lab/README.md`, `content_rules.py` (новый), `consumer.py`, `lab.py`, `state.py`, `telemetry.py`, `test_measurement_and_eligibility.py` (новый).
- `examples/godot-episode/README.md`, `qualify.py`, `test_report_contract.py`.
- `examples/adaptation/README.md`, `consumer.py`, `test_adaptation.py`.
- `examples/design-studies/harbour-of-echoes/render_loom.py`, `test_render_loom.py` (новый).
- `skills/game-design/assets/episode.schema.json`.

Всего 16 файлов. Hash каждого candidate файла находится в `correction/evidence-summary.json` → `changed_files_sha256`. Другие docs/tests/distribution, binder, general runtime references и skill-creator work этим writer не менялись.

## Верификация и сырые результаты

Абсолютный корень результатов: `/workspace/scratch/c4106697b2e8/review-work/technical/correction`.

Использованный interpreter целевых наборов: `/workspace/scratch/c4106697b2e8/review-work/venv/bin/python`, `-B`; `TMPDIR` направлен в `correction/tmp`. Для повторов исходных stdlib adaptation/Loom CLI сохранён исходный argv с `python3`; те же реализации также прошли перечисленные ниже наборы через shared venv. Все командные argv, cwd, коды и elapsed записаны в `logs/<name>.json`, исходные stdout/stderr — в соседних файлах. Wrapper сохраняет child return code в metadata; собственный нулевой код capture не является кодом проверяемой команды.

Все команды таблицы выполнялись из `/workspace/scratch/c4106697b2e8/gamedesign-skills`. `$PY` ниже означает указанный абсолютный interpreter; это сокращение только для чтения записки, полный argv сохранён в logs.

| Набор / точная команда после `$PY` | Тестов | Код | Raw stem |
| --- | ---: | ---: | --- |
| `-B -m unittest discover -s examples/analysis-lab -p test_measurement_and_eligibility.py -v` | 6 | 0 | `analysis-new-first` |
| `-B -m unittest discover -s examples/analysis-lab -p test_semantics.py -v` | 17 | 0 | `analysis-existing-semantics` |
| `-B -m unittest discover -s examples/analysis-lab -p test_input_and_replay.py -v` | 6 | 0 | `analysis-existing-replay` |
| `-B -m unittest discover -s examples/godot-episode -p test_report_contract.py -v` | 13 | 0 | `godot-contract-final` |
| `-B -m unittest discover -s examples/adaptation -p test_adaptation.py -v` | 11 | 0 | `adaptation-first` |
| `-B -m unittest discover -s examples/design-studies/harbour-of-echoes -p test_render_loom.py -v` | 2 | 0 | `loom-first` |
| **Итого** | **55** | | |

Первый Godot contract run до дополнительной проверки отношений также завершился 0 (11 тестов, `godot-contract-first.*`); он сохранён отдельно и не прибавлен повторно к 55. У correction capture default bound 55 s; для последних трёх наборов явно использовался `REVIEW_CAPTURE_TIMEOUT_SECONDS=180`, с возвратом управления для progress сообщений. Это технический предел capture, не timeout нативного runner.

| Аналог исходной пробы | Код исходного review | Код candidate | Смысл |
| --- | ---: | ---: | --- |
| telemetry-valid | 0 | 0 | Прежние counts / denominator |
| telemetry-invalid-definition | 0 | 2 | Нет базы и отчёта |
| choose-valid | 0 | 0 | `operate-winch` |
| choose-no-knowledge | 0 | 0 | Доступен другой выбор `chart-route` |
| recover-valid | 0 | 0 | Идентичные игровые output bytes |
| recover-no-knowledge | 0 | 1 | Нет нового save |
| assess-recorded-valid | 0 | 0 | Поддержанное свойство |
| assess-missing-state-events | 0 | 2 | Непригодный неполный report |
| adaptation-without-pins-view | 0 | 0 | Не предъявляет pin |
| adaptation-without-pins-play | 2 | 2 | Pin недоступен |
| adaptation-without-pins-valid | 0 | 0 | Обычный выбор доступен |
| loom-valid | 0 | 0 | WAV/CSV идентичны |
| loom-wrong-root | 1 | 2 | Контролируемый invalid без traceback |
| godot-zero-warning-schema | 0 | 2 | Tick 0 вне выполнимого контракта |

Raw stem в этой таблице — `logs/replay-<название>.*`. `correction/probe-plan.json` хранит **полные 14 команд и cwd**; `replay_probes.py` исполнил их без изменения входов и перенаправил только результаты в новый owned каталог. Исходные probes, outputs, ошибки и timeout остались в родительском `technical/` без перезаписи. Supplemental отношения используют `pre-relation-{owner-conflict,history-missing,history-duplicate}` и `post-relation-{...}`.

`verify_evidence.py` проверил реальные коды, отсутствие файлов при отказе, исходные counts/decisions, идентичность корректного recovery save, WAV/CSV, native sources и historical report. Raw: `logs/verify-evidence.*`; итог: `correction/evidence-summary.json`. `logs/diff-check.*` хранит адресный `git diff --check`.

## Native runner: отдельное улучшение доступности

По запросу root после наблюдённого native-import timeout добавлен `--timeout-seconds` для run/suite, default 30 s сохранён. API: `run(godot, fixture, output, timeout_seconds=30)`, `suite(godot, output, timeout_seconds=30)`. Значение проверяется как конечное положительное число до файловых эффектов; фактическое значение записывается в `receipt.timeout_seconds`. Автоматических повторов и безлимитного ожидания нет. CLI и README отражают это условие; недопустимый bound проверен в обоих CLI пути.

Это узкое согласованное изменение runner на основании сведений root о cold startup, **не новая находка о дефекте native игровых исходников**. Исходный штатный 30 s timeout и его частичные logs сохраняет root. Native baseline/candidate проверки portable Godot принадлежат root и фиксируются отдельно; они не включены в 55 тестов этого packet. Этот writer не запускал Godot и не выдаёт protocol mutations за native execution.

## Сохранённая идентичность и ограничения

Четыре файла `project.godot`, `episode.tscn`, `episode.gd`, `player.gd` сверены с Git base и остались неизменными. Исторический `examples/godot-episode/fixtures/test_recorded_candidate_report.json` сохранил SHA-256 `9105bc41111a26df77a5ae2cf2a742a0d701b98bb4e6cff2b97ed201d0bb9b9d`. Исходный review сохранил свой frozen hash. Полные hashes и retained-input hashes есть в `evidence-summary.json`.

Модельных прогонов: **0**. Human/device/audio-listening/network/multiplayer испытаний: **0**. Loom проверен как сериализованный звук и временные visual данные; это не сравнение музыкального качества или наблюдение участника. Godot report checks оценивают полноту/согласованность предоставленных observations; они не подтверждают аутентичность произвольного JSON. Новые after-load test mutations явно synthetic. Полная distribution/lifecycle suite этим writer не выполнялась; интеграция, CI wiring, native evidence и commit принадлежат root.
