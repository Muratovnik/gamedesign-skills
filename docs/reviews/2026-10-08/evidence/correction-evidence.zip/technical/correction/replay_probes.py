"""Candidate equivalents: reuse frozen inputs, write only correction-owned outputs."""
import json
from pathlib import Path
import subprocess
import sys
root = Path(__file__).resolve().parent
for probe in json.loads((root / "probe-plan.json").read_text()):
    result = subprocess.run([sys.executable, "-B", str(root / "capture.py"), probe["name"], *probe["argv"]], cwd=probe["cwd"], check=False)
    if result.returncode:
        raise SystemExit(result.returncode)
