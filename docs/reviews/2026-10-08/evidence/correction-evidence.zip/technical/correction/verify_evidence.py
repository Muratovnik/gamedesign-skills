"""Inspect retained command results and unchanged inputs; never run a game or model."""
import hashlib
import json
from pathlib import Path
import re
import subprocess

WORK = Path(__file__).resolve().parent
OLD = WORK.parent
REPO = OLD.parents[1] / "gamedesign-skills"
BASE = "f9f6bac0ee767597692d5c17d1eecc90f6788aa8"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


expected = {
    "telemetry-valid": 0, "telemetry-invalid-definition": 2,
    "choose-valid": 0, "choose-no-knowledge": 0, "recover-valid": 0, "recover-no-knowledge": 1,
    "assess-recorded-valid": 0, "assess-missing-state-events": 2,
    "adaptation-without-pins-view": 0, "adaptation-without-pins-play": 2,
    "adaptation-without-pins-valid": 0, "loom-valid": 0, "loom-wrong-root": 2,
    "godot-zero-warning-schema": 2,
}
comparisons = []
for name, code in expected.items():
    before = json.loads((OLD / "logs" / (name + ".json")).read_text())
    after = json.loads((WORK / "logs" / ("replay-" + name + ".json")).read_text())
    assert after["exit_code"] == code, (name, after)
    comparisons.append({"probe": name, "review_exit": before["exit_code"], "candidate_exit": code})
for name in ("owner-conflict", "history-missing", "history-duplicate"):
    before = json.loads((WORK / "logs" / ("pre-relation-" + name + ".json")).read_text())
    after = json.loads((WORK / "logs" / ("post-relation-" + name + ".json")).read_text())
    assert (before["exit_code"], after["exit_code"]) == (0, 2)
for name in ("telemetry-invalid.sqlite", "telemetry-invalid.json", "recovered-no-knowledge.json",
             "adaptation-without-pins-play.json", "loom-wrong-root"):
    assert not (WORK / "results" / name).exists(), name
assert "Traceback" not in (WORK / "logs" / "replay-loom-wrong-root.stderr").read_text()
telemetry = json.loads((WORK / "results" / "telemetry-valid.json").read_text())
assert telemetry["counts"] == {"success": 1, "failure": 1, "unknown": 2, "not_attempted": 1}
assert telemetry["success_fraction_among_known_attempts"] == 0.5
assert (WORK / "results" / "recovered-valid.json").read_bytes() == (OLD / "results" / "recovered-valid.json").read_bytes()
for name, decision in (("choice-valid.json", "operate-winch"), ("choice-no-knowledge.json", "chart-route")):
    assert json.loads((WORK / "results" / name).read_text())["decision"] == decision
actions = json.loads((WORK / "results" / "adaptation-without-pins-view.json").read_text())["permitted_actions"]
assert actions == ["next-line", "choose-direction"]
media = {}
for name in ("phrase-a.wav", "phrase-b.wav", "phrase-a-visual-timeline.csv", "phrase-b-visual-timeline.csv"):
    current = sha(WORK / "results" / "loom-valid" / name)
    assert current == sha(OLD / "results" / "loom-valid" / name), name
    media[name] = current
native = {}
for name in ("project.godot", "episode.tscn", "episode.gd", "player.gd"):
    path = "examples/godot-episode/" + name
    result = subprocess.run(["git", "show", BASE + ":" + path], cwd=REPO, capture_output=True, check=True)
    baseline = hashlib.sha256(result.stdout).hexdigest()
    candidate = sha(REPO / path)
    assert baseline == candidate, path
    native[name] = {"baseline_sha256": baseline, "candidate_sha256": candidate, "unchanged": True}
recorded = sha(REPO / "examples/godot-episode/fixtures/test_recorded_candidate_report.json")
assert recorded == "9105bc41111a26df77a5ae2cf2a742a0d701b98bb4e6cff2b97ed201d0bb9b9d"
review = sha(REPO / "docs/reviews/2026-10-08/review-game-design-project.md")
assert review == "3a83585a31bf5ea3839e7b9edb45f146e0ecd13a2eea0d7938d8b519b1219a10"
files = [
    "examples/adaptation/README.md", "examples/adaptation/consumer.py", "examples/adaptation/test_adaptation.py",
    "examples/analysis-lab/README.md", "examples/analysis-lab/content_rules.py", "examples/analysis-lab/consumer.py",
    "examples/analysis-lab/lab.py", "examples/analysis-lab/state.py", "examples/analysis-lab/telemetry.py",
    "examples/analysis-lab/test_measurement_and_eligibility.py",
    "examples/design-studies/harbour-of-echoes/render_loom.py", "examples/design-studies/harbour-of-echoes/test_render_loom.py",
    "examples/godot-episode/README.md", "examples/godot-episode/qualify.py", "examples/godot-episode/test_report_contract.py",
    "skills/game-design/assets/episode.schema.json",
]
test_suites = {}
for name in ("analysis-new-first", "analysis-existing-semantics", "analysis-existing-replay", "godot-contract-final", "adaptation-first", "loom-first"):
    receipt = json.loads((WORK / "logs" / (name + ".json")).read_text())
    stderr = (WORK / "logs" / (name + ".stderr")).read_text()
    assert receipt["exit_code"] == 0 and stderr.rstrip().endswith("OK"), name
    count = int(re.search(r"Ran (\d+) tests", stderr)[1])
    test_suites[name] = {"tests": count, "exit_code": 0, "elapsed_seconds": receipt["elapsed_seconds"], "argv": receipt["argv"]}
result = {"status": "verified", "base": BASE, "frozen_review_sha256": review, "recorded_report_sha256": recorded,
          "native_source_identity": native, "changed_files_sha256": {path: sha(REPO / path) for path in files},
          "frozen_inputs_sha256": {str(path.relative_to(OLD)): sha(path) for path in sorted((OLD / "fixtures").glob("*")) if path.is_file()},
          "replay_comparisons": comparisons, "unchanged_loom_media_sha256": media, "test_suites": test_suites,
          "total_tests": sum(row["tests"] for row in test_suites.values()),
          "scope": "Deterministic CLI/unit/serialized-artifact checks; no native, model, human or device execution by this agent.",
          "isolation": "Instruction-scoped owned scratch and PYTHONDONTWRITEBYTECODE=1; not an OS sandbox."}
(WORK / "evidence-summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"status": "verified", "total_tests": result["total_tests"], "changed_files": len(files),
                  "replayed_probes": len(comparisons), "native_sources_unchanged": True, "historical_report_unchanged": True}))
